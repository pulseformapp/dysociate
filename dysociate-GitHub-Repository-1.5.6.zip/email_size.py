"""Bound the actual MIME message, not only the original image/HTML size.

Copyright (c) 2026 Luna Love ~ LunaSoft
SPDX-License-Identifier: GPL-3.0-or-later. See LICENSE.

The 8 MB budget is a conservative application setting, not a promise about
every mail provider. HTML data URLs already add base64 overhead; email adds
another base64 layer plus line wrapping. Only final MIME bytes decide fit.
Image changes apply to a temporary email copy, never the user's saved thread.
"""
from __future__ import annotations
import base64
import copy
import io
from PIL import Image, ImageOps

MAX_EMAIL_BYTES = 8_000_000
EMAIL_PROFILES = ((1600, 82), (1200, 72), (960, 62))


class EmailTooLargeError(ValueError):
    pass


def megabytes(size):
    return f'{size / 1_000_000:.2f} MB'


def smaller_email_page(page, edge, quality, *, cancelled=None, progress=None):
    """Resize each unique raster once; keep animation and unsupported data.

    Decode from the original for every profile, avoiding successive lossy
    re-encodes. EXIF orientation is applied before resizing. WebP preserves
    transparency; PNG is the lossless fallback if WebP is unavailable. Never
    flatten an animated GIF or drop a picture merely to meet the budget.
    """
    result = copy.deepcopy(page)
    cache = {}
    for index, post in enumerate(result.sections):
        if cancelled and cancelled.is_set():
            raise InterruptedError('Email preparation canceled.')
        original = post.image_data_url
        if not original:
            continue
        if original in cache:
            post.image_data_url = cache[original]
            continue
        if progress:
            progress(f'Preparing smaller email copy · image {index + 1} of {len(result.sections)}…')
        replacement = original
        try:
            mime, encoded = original.split(',', 1)
            payload = base64.b64decode(encoded, validate=True)
            if len(payload) > 30_000:
                with Image.open(io.BytesIO(payload)) as source:
                    if getattr(source, 'is_animated', False):
                        cache[original] = original
                        continue
                    photo = ImageOps.exif_transpose(source)
                    photo.thumbnail((edge, edge), Image.Resampling.LANCZOS)
                    output = io.BytesIO()
                    if mime.lower().startswith('data:image/jpeg'):
                        photo.convert('RGB').save(output, 'JPEG', quality=quality, optimize=True)
                        image_type = 'jpeg'
                    else:
                        try:
                            photo.convert('RGBA').save(output, 'WEBP', quality=quality, method=4)
                            image_type = 'webp'
                        except OSError:
                            output = io.BytesIO()
                            photo.save(output, 'PNG', optimize=True)
                            image_type = 'png'
                    candidate = f'data:image/{image_type};base64,' + base64.b64encode(output.getvalue()).decode('ascii')
                    if len(candidate) < len(original):
                        replacement = candidate
        except (ValueError, OSError, Image.DecompressionBombError):
            # A failed decoder does not authorize removing content. The caller
            # will reject the final email if preserving it exceeds the budget.
            pass
        cache[original] = replacement
        post.image_data_url = replacement
        post.image_path = ''
    return result
