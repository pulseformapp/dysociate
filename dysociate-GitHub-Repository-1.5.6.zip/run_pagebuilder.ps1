# LunaSoft webpage maker launcher
# Copyright (c) 2026 Luna Love ~ LunaSoft
# SPDX-License-Identifier: GPL-3.0-or-later. See LICENSE.

[CmdletBinding()]
param(
    [switch]$SelfTest
)

$ErrorActionPreference = "Stop"
# All paths are anchored to the launcher, not PowerShell's current directory.
# Both public launcher names enter the same GUI; the retained TUI modules are
# reference code and are never selected implicitly by this script.
$scriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$venvDir = Join-Path $scriptDir ".venv"
$venvPython = Join-Path $venvDir "Scripts\python.exe"

$pyLauncher = Get-Command py -ErrorAction SilentlyContinue
$pythonCommand = Get-Command python -ErrorAction SilentlyContinue
$pythonExe = $null
$pythonPrefix = @()

if ($null -ne $pyLauncher) {
    & $pyLauncher.Source -3 --version *> $null
    if ($LASTEXITCODE -eq 0) {
        $pythonExe = $pyLauncher.Source
        $pythonPrefix = @("-3")
    }
}

if ($null -eq $pythonExe -and $null -ne $pythonCommand) {
    $pythonExe = $pythonCommand.Source
}

if ($null -eq $pythonExe) {
    $candidatePythonPaths = @(
        (Join-Path $env:USERPROFILE "AppData\Local\Programs\Python\Python313\python.exe"),
        (Join-Path $env:USERPROFILE "AppData\Local\Programs\Python\Python312\python.exe"),
        (Join-Path $env:USERPROFILE "AppData\Local\Programs\Python\Python311\python.exe"),
        (Join-Path $env:LocalAppData "Programs\Python\Python313\python.exe"),
        (Join-Path $env:LocalAppData "Programs\Python\Python312\python.exe"),
        (Join-Path $env:LocalAppData "Programs\Python\Python311\python.exe"),
        (Join-Path $env:ProgramFiles "Python313\python.exe"),
        (Join-Path $env:ProgramFiles "Python312\python.exe"),
        (Join-Path $env:ProgramFiles "Python311\python.exe")
    )
    $pythonExe = $candidatePythonPaths | Where-Object { Test-Path -LiteralPath $_ } | Select-Object -First 1
}

if ($null -eq $pythonExe) {
    Write-Error "Python 3 was not found. Install Python 3.11+ from python.org and enable Add Python to PATH."
    exit 1
}

if (-not (Test-Path -LiteralPath $venvPython)) {
    & $pythonExe @pythonPrefix -m venv $venvDir
    if ($LASTEXITCODE -ne 0) {
        exit $LASTEXITCODE
    }
}

# Dependencies are probed before installation so subsequent launches can run
# offline. The private environment avoids modifying a user's global Python.
& $venvPython -c "import PIL" *> $null
if ($LASTEXITCODE -ne 0) {
    & $venvPython -m pip install --disable-pip-version-check -r (Join-Path $scriptDir "requirements.txt")
    if ($LASTEXITCODE -ne 0) {
        exit $LASTEXITCODE
    }
}

$appArgs = @((Join-Path $scriptDir "dysociate_gui.py"))
if ($SelfTest) {
    $appArgs += "--self-test"
}

& $venvPython @appArgs
exit $LASTEXITCODE
