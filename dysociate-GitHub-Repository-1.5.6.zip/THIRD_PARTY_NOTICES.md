# dysociate - third-party components

Copyright (c) 2026 Luna Love ~ LunaSoft. Product source for release 1.5.1 is
GPL-3.0-or-later. The original supplied artwork is included as `dysociate.png`;
the icon is a format conversion of that same image.

The frozen Windows application also bundles the CPython runtime, Tcl/Tk, and
Pillow. They retain their respective upstream terms;
dysociate's GPL notice does not replace their licenses. Windows curses remains
an optional dependency of the reference TUI. Runtime license text
is included in the `Licenses` directory and in bundled runtime resources.

Build tools include PyInstaller (GPL with its bootloader exception), Pillow,
pycdlib, and Inno Setup. They are build dependencies and are not relabeled as
LunaSoft code. Installers include the Inno Setup runtime under its upstream
terms. The build instructions name these tools so the release can be rebuilt.
