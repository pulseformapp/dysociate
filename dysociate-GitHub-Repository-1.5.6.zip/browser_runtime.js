/* dλsociate: the complete portable browser editor.
 * Copyright (c) 2026 Luna Love ~ LunaSoft
 * SPDX-License-Identifier: GPL-3.0-or-later
 * This readable source and the full license travel inside every HTML export.
 * Posts/images remain their author's content. No accounts or remote database.
 */
(function () {
    "use strict";
    const byId = id => document.getElementById(id);
    const dataNode = byId("luna-page-data"), thread = byId("thread");
    const form = byId("comment-form"), parent = byId("comment-parent");
    const title = byId("comment-title"), body = byId("comment-body");
    const image = byId("comment-image"), status = byId("comment-status");
    if (!dataNode || !thread || !form) return;
    let bridge = null;
    try { bridge = JSON.parse((byId("dysociate-bridge") || {}).textContent || "null"); } catch (_) {}
    let page, editing = "", imageData = "", imageAlt = "", imageBusy = false;
    let busy = false, changed = false, revision = 0, exportedRevision = 0;
    let fileHandle = null, filename = currentFilename(), downloadUrl = null;
    let imageGeneration = 0, pendingPost = null;
    const MAX_EMAIL_BYTES = 8000000;
    let emailJob = null;
    const isLoopback = host => ["localhost", "::1", "0.0.0.0"].includes(host.toLowerCase().replace(/[\[\]]/g, "")) || host.startsWith("127.");
    const localHost = isLoopback(location.hostname);
    const hostedEditorUrl = location.protocol === "https:" && !localHost ? location.origin + location.pathname : "";
    const raster = /^data:image\/(?:png|jpe?g|gif|webp|bmp|x-ms-bmp|x-icon|vnd\.microsoft\.icon);base64,[A-Za-z0-9+/]*={0,2}$/i;
    const fields = ["heading", "body", "button_label", "button_url", "image_alt", "label", "post_id", "parent_id", "image_data_url"];

    function text(value) {
        return String(value || "").replace(/[&<>"']/g, c => ({"&":"&amp;", "<":"&lt;", ">":"&gt;", '"':"&quot;", "'":"&#39;"}[c]));
    }
    function id() {
        return "p" + ((window.crypto && crypto.randomUUID) ? crypto.randomUUID().replace(/-/g, "") :
            Date.now().toString(36) + Math.random().toString(36).slice(2));
    }
    function message(value) { status.textContent = value; }
    function currentFilename() {
        try {
            const name = decodeURIComponent(location.pathname.split("/").pop());
            if (/\.html?$/i.test(name)) return name;
        } catch (_) {}
        return "index.html";
    }
    function safeFilename(value) { return value.replace(/[\\/\x00-\x1f]/g, "_") || "index.html"; }

    function validate(data) {
        // Import JSON only, never run a received file's scripts or copy its DOM.
        // Whitelist fields and raster images; image_path is never trusted.
        if (!data || typeof data !== "object" || !Array.isArray(data.sections)) throw Error("This file has no editable thread data.");
        if (data.sections.length > 10000) throw Error("This thread has too many posts for the browser editor.");
        for (const name of ["title", "terminal_banner", "browser_editor_url"]) {
            if (data[name] !== undefined && typeof data[name] !== "string") throw Error("Invalid thread details.");
        }
        const seen = new Map(), reserved = new Set(data.sections.map(p => p && p.post_id).filter(Boolean));
        const sections = data.sections.map((source, index) => {
            if (!source || typeof source !== "object" || Array.isArray(source)) throw Error("Invalid post data.");
            const post = {kind: source.kind || "Post", image_path: ""};
            if (!["Post", "Text", "Hero", "Image", "Button", "Divider"].includes(post.kind)) throw Error("Unsupported post type.");
            fields.forEach(name => {
                if (source[name] !== undefined && typeof source[name] !== "string") throw Error("Invalid post field.");
                post[name] = source[name] || "";
            });
            if (!post.post_id) {
                post.post_id = "legacy" + (index + 1);
                while (reserved.has(post.post_id) || seen.has(post.post_id)) post.post_id += "_";
            }
            if (seen.has(post.post_id)) throw Error("Duplicate post identifiers.");
            if (post.image_data_url) {
                if (!raster.test(post.image_data_url)) throw Error("Use embedded PNG, JPG, GIF, WEBP or BMP images.");
                try { atob(post.image_data_url.split(",")[1]); } catch (_) { throw Error("Invalid embedded image."); }
            }
            if (post.kind === "Button" && !/^(?:https?:|mailto:|[^:]*$)/i.test(post.button_url.trim())) throw Error("Unsupported link in this thread.");
            seen.set(post.post_id, post);
            return post;
        });
        // Iterative walks validate ALL components, including cycles disconnected
        // from the root. Map also treats IDs like __proto__ as ordinary strings.
        const checked = new Set();
        for (const post of sections) {
            let current = post.post_id;
            const trail = new Set();
            while (current && !checked.has(current)) {
                if (trail.has(current)) throw Error("Circular replies in this thread.");
                if (!seen.has(current)) throw Error("A reply's parent is missing.");
                trail.add(current); current = seen.get(current).parent_id;
            }
            trail.forEach(key => checked.add(key));
        }
        return {version: 1, title: data.title || "Untitled thread", terminal_banner: data.terminal_banner || "",
            browser_editor_url: editorUrl(data.browser_editor_url || hostedEditorUrl), sections};
    }
    function editorUrl(value) {
        if (!value) return "";
        let parsed;
        try { parsed = new URL(value); } catch (_) { throw Error("Use a full HTTPS browser editor address."); }
        if (parsed.protocol !== "https:" || !parsed.hostname || parsed.username || parsed.password) throw Error("Use an HTTPS browser editor address without login credentials.");
        if (isLoopback(parsed.hostname)) throw Error("A loopback address cannot be shared as the browser editor link.");
        return parsed.href;
    }
    try { page = validate(JSON.parse(dataNode.textContent)); }
    catch (error) { message(error.message + " Use Open HTML to choose another file."); page = validate({sections: []}); }

    function safeMetadata(snapshot = page) { return JSON.stringify(snapshot).replace(/<\//g, "<\\/"); }
    function hasDraft() { return !!(title.value.trim() || body.value.trim() || imageData || imageBusy); }
    function updateState() {
        byId("save-state").textContent = imageBusy ? "Preparing image…" :
            hasDraft() ? "Draft in this tab" : changed ? "Changes in this tab · save or email a copy" :
            exportedRevision ? "Copy prepared · check your downloads" : "Browser editor · no install needed";
        ["save-html", "share-page", "share-email", "share-download", "post-submit"].forEach(name => {
            byId(name).disabled = busy || imageBusy;
        });
        [title, body, image, byId("open-html"), byId("page-title"), byId("page-banner"), byId("page-editor-url")].forEach(node => { node.disabled = busy; });
        parent.disabled = busy || !!editing;
        ["new-post", "new-thread", "clear-draft", "delete-post", "continue-browser", "remove-image"].forEach(name => { byId(name).disabled = busy; });
        thread.querySelectorAll("button").forEach(node => { node.disabled = busy; });
    }
    function markChanged() { revision++; changed = true; updateState(); }
    function render() {
        const selected = parent.value;
        const children = new Map();
        page.sections.forEach(post => {
            const key = post.parent_id || "";
            if (!children.has(key)) children.set(key, []);
            children.get(key).push(post);
        });
        // Flat DOM, iterative depth-first traversal: a thousand replies must
        // neither overflow the JS call stack nor squeeze text off a phone.
        const stack = (children.get("") || []).slice().reverse().map(post => [post, 0]);
        const output = [];
        while (stack.length) {
            const [post, depth] = stack.pop();
            const nested = children.get(post.post_id) || [];
            for (let i = nested.length - 1; i >= 0; i--) stack.push([nested[i], depth + 1]);
            if (post.kind === "Divider") { output.push("<hr>"); continue; }
            output.push('<article class="thread-item ' + (post.parent_id ? "comment" : "post") + '" style="--depth:' + Math.min(depth, 3) + '" data-post-id="' + text(post.post_id) + '">' +
                '<h2>' + text(post.heading || (post.parent_id ? "Comment" : "Post")) + '</h2>' +
                (post.image_data_url ? '<div class="section-image"><img loading="lazy" src="' + text(post.image_data_url) + '" alt="' + text(post.image_alt || "Post image") + '"></div>' : "") +
                '<div class="post-body">' + text(post.body).replace(/\n/g, "<br>\n") + '</div>' +
                (post.kind === "Button" && post.button_url ? '<p><a href="' + text(post.button_url) + '" rel="noopener noreferrer">' + text(post.button_label || "Open link") + '</a></p>' : "") +
                '<div class="post-actions"><button class="reply-button" type="button" data-reply-to="' + text(post.post_id) + '">Reply</button>' +
                '<button class="reply-button secondary" type="button" data-edit-post="' + text(post.post_id) + '">Edit</button></div></article>');
        }
        thread.innerHTML = output.join("") || '<p class="empty-thread">Your thread starts here. Open an HTML thread or write your first post below.</p>';
        parent.innerHTML = '<option value="">New post</option>';
        page.sections.filter(post => post.kind !== "Divider").forEach((post, index) => {
            const option = document.createElement("option");
            option.value = post.post_id;
            option.textContent = (post.parent_id ? "↳ " : "") + (index + 1) + ". " + (post.heading || post.body.slice(0, 45) || "Image post");
            parent.appendChild(option);
        });
        if (page.sections.some(post => post.post_id === selected)) parent.value = selected;
        byId("thread-title").textContent = page.title;
        byId("page-title").value = page.title;
        byId("page-banner").value = page.terminal_banner;
        byId("page-editor-url").value = page.browser_editor_url;
        byId("reader-link").hidden = !page.browser_editor_url;
        byId("reader-url").href = page.browser_editor_url || "#";
        document.title = page.title;
        const banner = byId("terminal-banner");
        banner.textContent = page.terminal_banner; banner.hidden = !page.terminal_banner;
        byId("post-count").textContent = page.sections.filter(p => p.kind !== "Divider").length + " posts / replies";
        dataNode.textContent = safeMetadata();
        updateState();
    }
    function resetDraft() {
        imageGeneration++; editing = ""; imageData = ""; imageAlt = ""; imageBusy = false; pendingPost = null;
        form.reset(); parent.disabled = false;
        byId("image-preview").hidden = true; byId("image-preview-img").removeAttribute("src");
        byId("delete-post").hidden = true;
        byId("composer-heading").textContent = "ADD A POST";
        byId("post-submit").textContent = "Post to thread";
        updateState();
    }
    function focusComposer() {
        byId("comment-form-panel").scrollIntoView({block: "start", behavior: "auto"}); body.focus();
    }
    function detachBridge() {
        // Desktop preview accepts append operations, never arbitrary replacement
        // pages. Browser edits/imports become a portable copy, not a stale server
        // overwrite. The desktop's original stays intact until a chosen Save.
        if (bridge) { bridge = null; fileHandle = null; byId("continue-browser").hidden = true; message("Editing a browser copy. Save HTML to keep this version."); }
    }
    function makePost() {
        if (!body.value.trim() && !imageData) throw Error("Write some text or choose an image first.");
        const previous = page.sections.find(p => p.post_id === editing);
        return {kind: "Post", heading: title.value.trim() || (parent.value ? "Comment" : "Post"), body: body.value.trim(),
            post_id: editing || (pendingPost && pendingPost.post_id) || id(), parent_id: previous ? previous.parent_id : parent.value || "",
            image_data_url: imageData, image_alt: imageAlt, image_path: "", label: "", button_label: "", button_url: ""};
    }
    function commitLocal() {
        const post = makePost();
        const index = page.sections.findIndex(p => p.post_id === editing);
        if (index >= 0) page.sections[index] = post; else page.sections.push(post);
        resetDraft(); markChanged(); render();
        message("Added to this thread. Save HTML or Email to keep and share this version.");
    }
    function prepareExport() {
        if (busy || imageBusy) { message("Wait for the current post or image to finish."); return false; }
        if (hasDraft()) {
            if (bridge) { message("Post your draft first, then save or email the updated thread."); return false; }
            try { commitLocal(); } catch (error) { message(error.message); body.focus(); return false; }
        }
        return true;
    }
    form.addEventListener("submit", async event => {
        event.preventDefault();
        if (busy || imageBusy) return;
        try {
            if (!bridge) { commitLocal(); return; }
            const post = makePost();
            const signature = JSON.stringify({...post, post_id: ""});
            if (!pendingPost || pendingPost.signature !== signature) post.post_id = id();
            pendingPost = {...post, signature}; // Retry a lost response with the same ID.
            busy = true; updateState();
            const controller = new AbortController();
            const timeout = setTimeout(() => controller.abort(), 12000);
            try {
                const response = await fetch(bridge.comment_url, {method:"POST", headers:{"Content-Type":"application/json"},
                    credentials:"same-origin", body:JSON.stringify(post), signal:controller.signal});
                const result = await response.json();
                if (!response.ok) throw Error(result.error || "Could not save.");
                page = validate(result.page); resetDraft(); changed = false; render();
                message("Saved to " + bridge.filename + ".");
            } finally { clearTimeout(timeout); }
        } catch (error) {
            message(bridge ? "Could not save to the desktop app. Your draft is still here. Use Continue in browser to keep working without it." : error.message);
        } finally { busy = false; updateState(); }
    });

    function readFile(file, mode) {
        return new Promise((resolve, reject) => {
            const reader = new FileReader();
            reader.onload = () => resolve(String(reader.result || ""));
            reader.onerror = () => reject(Error("This file could not be read. Choose it again."));
            reader.onabort = () => reject(Error("File reading canceled."));
            if (mode === "image") reader.readAsDataURL(file); else reader.readAsText(file);
        });
    }
    function convertPhoto(url) {
        return new Promise((resolve, reject) => {
            const photo = new Image();
            photo.onload = () => {
                try {
                    const scale = Math.min(1, 1600 / Math.max(photo.naturalWidth, photo.naturalHeight));
                    const canvas = document.createElement("canvas");
                    canvas.width = Math.max(1, Math.round(photo.naturalWidth * scale));
                    canvas.height = Math.max(1, Math.round(photo.naturalHeight * scale));
                    const context = canvas.getContext("2d");
                    context.fillStyle = "#ffffff"; context.fillRect(0, 0, canvas.width, canvas.height);
                    context.drawImage(photo, 0, 0, canvas.width, canvas.height);
                    const result = canvas.toDataURL("image/jpeg", .85);
                    if (!raster.test(result)) throw Error("Photo conversion failed.");
                    resolve(result);
                } catch (_) { reject(Error("Choose a smaller JPG or PNG image.")); }
            };
            photo.onerror = () => reject(Error("This browser cannot read that photo format. Choose JPG or PNG."));
            photo.src = url;
        });
    }
    image.addEventListener("change", async () => {
        const generation = ++imageGeneration, file = image.files && image.files[0];
        if (!file) return;
        imageBusy = true; updateState();
        try {
            if (file.size > 20 * 1024 * 1024) throw Error("Choose an image smaller than 20 MB.");
            let value = await readFile(file, "image");
            if (!raster.test(value) || (/^data:image\/jpeg;/i.test(value) && file.size > 2 * 1024 * 1024)) value = await convertPhoto(value);
            if (generation !== imageGeneration) return;
            imageData = value; imageAlt = file.name || "Post image";
            byId("image-preview-img").src = value; byId("image-preview").hidden = false;
            message("Image ready. Add text if you like, then post or save.");
        } catch (error) { if (generation === imageGeneration) { image.value = ""; message(error.message); } }
        finally { if (generation === imageGeneration) { imageBusy = false; updateState(); } }
    });
    byId("remove-image").addEventListener("click", () => {
        imageGeneration++; imageBusy = false; imageData = ""; imageAlt = ""; image.value = "";
        byId("image-preview").hidden = true; byId("image-preview-img").removeAttribute("src"); updateState();
    });
    [title, body].forEach(node => node.addEventListener("input", updateState));
    byId("clear-draft").addEventListener("click", () => {
        if (hasDraft() && !confirm("Discard this draft?")) return;
        resetDraft(); message("Draft cleared.");
    });
    byId("new-post").addEventListener("click", () => {
        if (hasDraft() && !confirm("Discard this draft and start a new post?")) return;
        resetDraft(); focusComposer();
    });
    thread.addEventListener("click", event => {
        const reply = event.target.closest("[data-reply-to]"), edit = event.target.closest("[data-edit-post]");
        if (!reply && !edit) return;
        if (hasDraft() && !confirm("Discard your current draft?")) return;
        resetDraft();
        if (reply) {
            parent.value = reply.dataset.replyTo;
            byId("composer-heading").textContent = "WRITE A REPLY";
        } else {
            const post = page.sections.find(p => p.post_id === edit.dataset.editPost);
            if (!post) return;
            detachBridge(); editing = post.post_id;
            title.value = post.heading; body.value = post.body; parent.value = post.parent_id; parent.disabled = true;
            imageData = post.image_data_url; imageAlt = post.image_alt;
            if (imageData) { byId("image-preview-img").src = imageData; byId("image-preview").hidden = false; }
            byId("composer-heading").textContent = "EDIT THIS POST";
            byId("post-submit").textContent = "Keep changes"; byId("delete-post").hidden = false;
        }
        updateState(); focusComposer();
    });
    byId("delete-post").addEventListener("click", () => {
        if (!editing || !confirm("Delete this post and all its replies from this copy?")) return;
        const removed = new Set([editing]), children = new Map();
        page.sections.forEach(p => { if (!children.has(p.parent_id)) children.set(p.parent_id, []); children.get(p.parent_id).push(p.post_id); });
        const stack = [editing];
        while (stack.length) for (const child of children.get(stack.pop()) || []) { removed.add(child); stack.push(child); }
        page.sections = page.sections.filter(p => !removed.has(p.post_id));
        resetDraft(); markChanged(); render(); message("Removed from this copy. Save HTML to keep the change.");
    });
    byId("continue-browser").hidden = !bridge;
    byId("continue-browser").addEventListener("click", () => {
        detachBridge(); byId("continue-browser").hidden = true; updateState();
        message("Browser mode ready. Your draft is still here. Post, then save or email a copy.");
    });

    byId("open-html").addEventListener("change", async event => {
        const file = event.target.files && event.target.files[0];
        if (!file) return;
        if ((changed || hasDraft()) && !confirm("Open another thread? Save your current copy first if you want to keep it.")) { event.target.value = ""; return; }
        busy = true; updateState();
        try {
            if (file.size > 64 * 1024 * 1024) throw Error("Choose an HTML thread smaller than 64 MB.");
            const source = await readFile(file, "text");
            const match = /<script\b[^>]*\bid\s*=\s*["']luna-page-data["'][^>]*>([\s\S]*?)<\/script\s*>/i.exec(source);
            if (!match) throw Error("Choose an HTML thread created by dλsociate.");
            const imported = validate(JSON.parse(match[1]));
            page = imported; bridge = null; fileHandle = null; filename = safeFilename(file.name);
            resetDraft(); changed = false; revision = 0; exportedRevision = 0;
            byId("continue-browser").hidden = true; render();
            message("Thread opened on this device. Post, reply, save and email without the desktop app.");
        } catch (error) { message("Could not open this thread: " + error.message + " Your current thread was kept."); }
        finally { event.target.value = ""; busy = false; updateState(); }
    });
    byId("new-thread").addEventListener("click", () => {
        if ((changed || hasDraft()) && !confirm("Start a new thread? Save your current copy first if you want to keep it.")) return;
        page = validate({sections: []}); bridge = null; fileHandle = null; filename = "index.html";
        resetDraft(); changed = false; revision = 0; exportedRevision = 0;
        byId("continue-browser").hidden = true; render(); focusComposer();
    });
    [["page-title", "title"], ["page-banner", "terminal_banner"], ["page-editor-url", "browser_editor_url"]].forEach(([node, field]) => {
        byId(node).addEventListener("change", () => {
            let value = byId(node).value.trim() || (field === "title" ? "Untitled thread" : "");
            if (field === "browser_editor_url") {
                try { value = editorUrl(value); } catch (error) { message(error.message); byId(node).value = page[field]; return; }
            }
            detachBridge(); page[field] = value;
            markChanged(); render();
        });
    });

    function htmlForDownload(snapshot = page) {
        dataNode.textContent = safeMetadata();
        const root = document.documentElement.cloneNode(true);
        root.querySelector("#luna-page-data").textContent = safeMetadata(snapshot);
        // The editable JSON owns the only image bytes. The inline runtime
        // hydrates visible pictures on open; serializing live src again used
        // to double the attachment before MIME added another base64 layer.
        root.querySelectorAll(".section-image img").forEach(node => {
            node.removeAttribute("src"); node.setAttribute("data-thread-image", "embedded");
        });
        root.querySelectorAll("#dysociate-bridge").forEach(node => node.remove());
        root.querySelectorAll("button").forEach(node => { node.disabled = false; });
        root.querySelectorAll("input, textarea").forEach(node => { node.disabled = false; node.removeAttribute("value"); if (node.tagName === "TEXTAREA") node.textContent = ""; });
        const cleanParent = root.querySelector("#comment-parent"); cleanParent.disabled = false;
        cleanParent.querySelectorAll("option").forEach(node => node.removeAttribute("selected"));
        for (const name of ["share-options", "download-ready", "image-preview", "delete-post", "continue-browser"]) root.querySelector("#" + name).hidden = true;
        root.querySelector("#image-preview-img").removeAttribute("src");
        root.querySelector("#download-ready").removeAttribute("href");
        root.querySelector("#share-page").setAttribute("aria-expanded", "false");
        root.querySelector("#post-submit").textContent = "Post to thread";
        root.querySelector("#composer-heading").textContent = "ADD A POST";
        root.querySelector("#save-state").textContent = "Browser editor · no install needed";
        ["comment-status", "share-status", "share-size"].forEach(name => { root.querySelector("#" + name).textContent = ""; });
        root.querySelector("#cancel-email").disabled = true;
        // A shared thread carries the notice, with its dialog closed and only
        // one copy of the license. The next tab controls its own dismissal.
        root.querySelector("#terms-dialog").removeAttribute("open");
        root.querySelector("#terms-license").textContent = "";
        root.querySelectorAll("details").forEach(node => node.removeAttribute("open"));
        return "<!doctype html>\n" + root.outerHTML;
    }
    function offeredCopy() { changed = false; exportedRevision = revision || 1; updateState(); }
    function download(payload, name, type) {
        if (downloadUrl) URL.revokeObjectURL(downloadUrl);
        downloadUrl = URL.createObjectURL(new Blob([payload], {type}));
        const link = byId("download-ready"); link.href = downloadUrl; link.download = name;
        link.textContent = "Download " + name + " · tap here if it did not start"; link.hidden = false;
        // Keep the URL alive for a second, explicit tap on mobile. Revoking it
        // after one second can invalidate a phone's still-open download sheet.
        link.click(); offeredCopy();
    }
    async function saveHtml() {
        if (!prepareExport()) return;
        const snapshot = htmlForDownload(), savingRevision = revision;
        // The picker/permission request starts synchronously inside this click.
        // Mobile browsers without this API take the ordinary download path.
        let request;
        try {
            request = !bridge && window.showSaveFilePicker ? (fileHandle ?
                fileHandle.requestPermission({mode:"readwrite"}).then(value => { if (value !== "granted") throw new DOMException("Canceled", "AbortError"); return fileHandle; }) :
                window.showSaveFilePicker({suggestedName:filename, types:[{description:"HTML thread", accept:{"text/html":[".html", ".htm"]}}]})) : null;
            if (!request) { download(snapshot, filename, "text/html"); message("HTML copy ready. Check Downloads or Save to Files, then share that file."); return; }
            busy = true; updateState();
            const handle = await request, writer = await handle.createWritable();
            try { await writer.write(snapshot); await writer.close(); }
            catch (error) { if (writer.abort) await writer.abort().catch(() => {}); throw error; }
            fileHandle = handle;
            if (revision === savingRevision) offeredCopy();
            message("Saved to " + (handle.name || filename) + ".");
        } catch (error) {
            message(error.name === "AbortError" ? "Save canceled. Your changes are still in this tab." : "Could not write that file. Your changes are still here; use Download HTML in Share instead.");
        } finally { busy = false; updateState(); }
    }
    byId("save-html").addEventListener("click", saveHtml);
    byId("share-download").addEventListener("click", () => {
        if (!prepareExport()) return;
        download(htmlForDownload(), filename, "text/html");
        byId("share-status").textContent = "HTML copy ready. Attach it in your messaging app.";
    });
    function base64Utf8(value) {
        // TextEncoder is not present in some older phone WebViews. This fallback
        // uses UTF-8 percent bytes; neither path spreads a huge file on the stack.
        if (!window.TextEncoder) return btoa(encodeURIComponent(value).replace(/%([0-9A-F]{2})/g, (_, byte) => String.fromCharCode(parseInt(byte, 16))));
        const bytes = new TextEncoder().encode(value); let binary = "";
        for (let i = 0; i < bytes.length; i += 8192) binary += String.fromCharCode.apply(null, bytes.subarray(i, i + 8192));
        return btoa(binary);
    }
    function emailSubject(value) {
        let chunk = "", size = 0; const words = [];
        for (const character of value.replace(/[\r\n]+/g, " ")) {
            const length = encodeURIComponent(character).replace(/%[0-9A-F]{2}/g, "x").length;
            if (size + length > 42) { words.push("=?UTF-8?B?" + base64Utf8(chunk) + "?="); chunk = ""; size = 0; }
            chunk += character; size += length;
        }
        if (chunk) words.push("=?UTF-8?B?" + base64Utf8(chunk) + "?=");
        return words.join("\r\n ");
    }
    function mb(size) { return (size / 1000000).toFixed(2) + " MB"; }
    function estimatedEmailBytes(html) {
        const encoded = 4 * Math.ceil(new Blob([html]).size / 3);
        return encoded + 2 * Math.ceil(encoded / 76) + 4096;
    }
    function emailMime(html, snapshot) {
        const boundary = "dysociate-" + id();
        const encoded = base64Utf8(html).match(/.{1,76}/g).join("\r\n");
        const attachmentName = safeFilename(filename).replace(/[^A-Za-z0-9_.-]/g, "_");
        return ["Subject: " + emailSubject(snapshot.title), "Date: " + new Date().toUTCString(),
            "Message-ID: <" + id() + "@dysociate.local>", "X-Unsent: 1", "MIME-Version: 1.0",
            'Content-Type: multipart/mixed; boundary="' + boundary + '"', "", "--" + boundary,
            "Content-Type: text/plain; charset=UTF-8", "Content-Transfer-Encoding: 7bit", "",
            "Save the attached HTML thread. Open it in your browser to post and reply; no desktop app is required.",
            "If your phone shows a read-only attachment preview, open the browser edition and choose Open HTML.", "",
            ...(snapshot.browser_editor_url ? ["Browser editor: " + snapshot.browser_editor_url, ""] : []),
            "--" + boundary, 'Content-Type: text/html; name="' + attachmentName + '"',
            'Content-Disposition: attachment; filename="' + attachmentName + '"', "Content-Transfer-Encoding: base64", "",
            encoded, "--" + boundary + "--", ""].join("\r\n");
    }
    function checkEmailJob(job) {
        if (job.cancelled || emailJob !== job) throw Error("Email preparation canceled. Your original thread is unchanged.");
        if (Date.now() > job.deadline) throw Error("Email preparation took too long. Try fewer/smaller pictures or transfer the HTML another way.");
    }
    function smallerEmailImage(original, edge, quality, job) {
        // Preserve GIF animation. Failed/unsupported decoders retain the image,
        // never silently delete it. Every profile starts from original bytes.
        if (job.cancelled || !original || /^data:image\/gif;/i.test(original) || original.length < 40000) return Promise.resolve(original);
        return new Promise(resolve => {
            const photo = new Image();
            const timer = setTimeout(() => { job.cancelImage = null; photo.onload = photo.onerror = null; resolve(original); }, 10000);
            job.cancelImage = () => { clearTimeout(timer); photo.onload = photo.onerror = null; resolve(original); };
            photo.onerror = () => { clearTimeout(timer); job.cancelImage = null; resolve(original); };
            photo.onload = () => {
                clearTimeout(timer);
                job.cancelImage = null;
                if (job.cancelled) { resolve(original); return; }
                try {
                    const scale = Math.min(1, edge / Math.max(photo.naturalWidth, photo.naturalHeight));
                    const canvas = document.createElement("canvas");
                    canvas.width = Math.max(1, Math.round(photo.naturalWidth * scale));
                    canvas.height = Math.max(1, Math.round(photo.naturalHeight * scale));
                    canvas.getContext("2d").drawImage(photo, 0, 0, canvas.width, canvas.height);
                    // WebP keeps transparency. Browsers without WebP encoding
                    // return PNG; never replace transparent pictures with white.
                    const type = /^data:image\/jpe?g;/i.test(original) ? "image/jpeg" : "image/webp";
                    const candidate = canvas.toDataURL(type, quality);
                    resolve(raster.test(candidate) && candidate.length < original.length ? candidate : original);
                } catch (_) { resolve(original); }
            };
            photo.src = original;
        });
    }
    function cancelEmail() {
        if (!emailJob) return;
        emailJob.cancelled = true;
        if (emailJob.cancelImage) emailJob.cancelImage();
        emailJob = null; busy = false;
        byId("cancel-email").disabled = true;
        byId("share-status").textContent = "Email preparation canceled. Your original thread is unchanged.";
        updateState();
    }
    byId("cancel-email").addEventListener("click", cancelEmail);
    byId("share-email").addEventListener("click", async () => {
        if (!prepareExport()) return;
        const job = {cancelled:false, deadline:Date.now() + 45000};
        emailJob = job; busy = true; updateState(); byId("cancel-email").disabled = false;
        const original = {...page, sections:page.sections.map(post => ({...post}))};
        let snapshot = original, html = "", optimized = false;
        try {
            html = htmlForDownload(snapshot);
            const startingSize = estimatedEmailBytes(html);
            for (const [edge, quality] of [[1600,.82],[1200,.72],[960,.62]]) {
                if (estimatedEmailBytes(html) <= MAX_EMAIL_BYTES) break;
                if (!original.sections.some(post => post.image_data_url)) break;
                checkEmailJob(job);
                const candidate = {...original, sections:original.sections.map(post => ({...post}))};
                const cache = new Map();
                for (let i = 0; i < candidate.sections.length; i++) {
                    checkEmailJob(job);
                    const post = candidate.sections[i], image = post.image_data_url;
                    if (!image) continue;
                    byId("share-status").textContent = "Preparing smaller email copy · image " + (i + 1) + " of " + candidate.sections.length + "…";
                    // Yield between images so Cancel and browser paint can run.
                    await new Promise(resolve => setTimeout(resolve, 0));
                    checkEmailJob(job);
                    if (!cache.has(image)) cache.set(image, await smallerEmailImage(image, edge, quality, job));
                    checkEmailJob(job); post.image_data_url = cache.get(image);
                }
                const smaller = htmlForDownload(candidate);
                if (new Blob([smaller]).size < new Blob([html]).size) { snapshot = candidate; html = smaller; optimized = true; }
            }
            checkEmailJob(job);
            // The estimate avoids encoding huge candidates repeatedly. Final
            // MIME bytes are authoritative, including headers and CRLF wrapping.
            if (estimatedEmailBytes(html) > MAX_EMAIL_BYTES) throw Error("Email is about " + mb(estimatedEmailBytes(html)) + " after optimization; the app budget is 8 MB. No email was created. Use fewer/smaller pictures, split the thread, or transfer the HTML another way.");
            const mime = emailMime(html, snapshot), size = new Blob([mime]).size;
            if (size > MAX_EMAIL_BYTES) throw Error("Email still exceeds the 8 MB preparation budget. Save the HTML and transfer it another way.");
            checkEmailJob(job);
            download(mime, "dysociate-email.eml", "message/rfc822");
            byId("share-size").textContent = "Prepared email: " + mb(size) + " / 8 MB budget" +
                (optimized ? " · reduced from about " + mb(startingSize) : "") + ". Provider limits can be lower.";
            byId("share-status").textContent = (optimized ? "Images optimized in this email copy; your original thread is unchanged. " : "") +
                "Email file ready with HTML attached. Open it in your mail app; use Forward or Edit as new if needed, then choose a recipient and send.";
        } catch (error) {
            if (emailJob === job) byId("share-status").textContent = error.message;
        } finally {
            if (emailJob === job) { emailJob = null; busy = false; byId("cancel-email").disabled = true; updateState(); }
        }
    });
    byId("share-page").addEventListener("click", () => {
        if (!prepareExport()) return;
        byId("share-options").hidden = false; byId("share-page").setAttribute("aria-expanded", "true");
        const html = htmlForDownload();
        byId("share-size").textContent = "HTML: " + mb(new Blob([html]).size) + " · email estimate: " + mb(estimatedEmailBytes(html)) + ". Oversized email copies are optimized to an 8 MB budget.";
        byId("share-options").scrollIntoView({block:"nearest"});
    });
    byId("share-close").addEventListener("click", () => {
        cancelEmail();
        byId("share-options").hidden = true; byId("share-page").setAttribute("aria-expanded", "false"); byId("share-page").focus();
    });
    window.addEventListener("beforeunload", event => {
        if (changed || hasDraft()) { event.preventDefault(); event.returnValue = ""; }
    });

    const termsDialog = byId("terms-dialog");
    const termsSeenKey = "dysociate-terms-seen-v2";
    const supportsModal = typeof termsDialog.showModal === "function";
    function showTerms() {
        if (termsDialog.hasAttribute("open")) return;
        byId("terms-license").textContent = byId("dysociate-runtime-license").textContent;
        if (supportsModal) termsDialog.showModal();
        else termsDialog.setAttribute("open", "");
        byId("terms-continue").focus();
    }
    function rememberTermsDismissal() {
        // Store only a tab dismissal, independent of which button was used.
        try { sessionStorage.setItem(termsSeenKey, "1"); } catch (_) {}
    }
    function closeTerms() {
        if (supportsModal) termsDialog.close();
        else {
            termsDialog.removeAttribute("open");
            byId("show-terms").focus();
        }
        rememberTermsDismissal();
    }
    byId("show-terms").addEventListener("click", showTerms);
    byId("terms-continue").addEventListener("click", closeTerms);
    byId("terms-agree").addEventListener("click", () => {
        closeTerms();
        message("Karmic Law agreed.");
    });
    termsDialog.addEventListener("cancel", rememberTermsDismissal);

    render();
    if (bridge) message("New posts save automatically while the desktop app is open. Continue in browser works independently.");
    let termsSeen = false;
    try { termsSeen = sessionStorage.getItem(termsSeenKey) === "1"; } catch (_) {}
    if (!bridge && supportsModal && !termsSeen) showTerms();
})();
