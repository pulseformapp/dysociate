"""Check visible color states, reduced motion, live status, and failed deletion.

Copyright (c) 2026 Luna Love ~ LunaSoft
SPDX-License-Identifier: GPL-3.0-or-later. See LICENSE.
"""
import copy
import os
from pathlib import Path
import time
import tkinter as tk
from tkinter import ttk
from tkinter.font import Font
import unittest
from unittest.mock import patch

from dysociate_gui import DysociateApp, main
from app_resources import KARMIC_LAW
from pagebuilder_gui import Section
from ui_theme import NeonButton


def contrast(first, second):
    def luminance(color):
        channels = [int(color[i:i+2], 16) / 255 for i in (1, 3, 5)]
        linear = [c / 12.92 if c <= .04045 else ((c + .055) / 1.055) ** 2.4 for c in channels]
        return sum(c * weight for c, weight in zip(linear, (.2126, .7152, .0722)))
    light, dark = sorted((luminance(first), luminance(second)), reverse=True)
    return (light + .05) / (dark + .05)


class ProductUITests(unittest.TestCase):
    def setUp(self):
        self.app = DysociateApp()
        self.app.withdraw()
        self.app.update_idletasks()

    def tearDown(self):
        self.app.update_idletasks()
        self.app.destroy()

    def test_labels_contrast_in_all_button_states(self):
        states = [(), ('active',), ('pressed',), ('focus',), ('active', 'pressed'),
                  ('disabled',), ('disabled', 'active'), ('disabled', 'pressed')]
        style = ttk.Style(self.app)
        for options in ({}, {'primary': True}, {'subtle': True}, {'danger': True}):
            button = NeonButton(self.app, 'Readable label', lambda: None, **options)
            for state in states:
                foreground = style.lookup(button.cget('style'), 'foreground', state=state)
                background = style.lookup(button.cget('style'), 'background', state=state)
                self.assertGreaterEqual(contrast(foreground, background), 4.5, (options, state, foreground, background))
            button.destroy()

    def test_reduced_motion_has_no_animation_job(self):
        with patch.dict(os.environ, {'DYSOCIATE_REDUCED_MOTION': '1'}):
            button = NeonButton(self.app, 'No motion', lambda: None)
            button._animate(button._hover)
            self.assertIsNone(button._job)
            self.app._saved_feedback()
            self.assertIsNone(self.app._feedback_job)
            button.destroy()

    def test_hover_finishes_without_an_idle_timer(self):
        with patch('ui_theme.motion_allowed', return_value=True):
            button = NeonButton(self.app, 'Finite feedback', lambda: None)
        button._animate(button._hover)
        until = time.monotonic() + .4
        while time.monotonic() < until:
            self.app.update()
            time.sleep(.02)
        self.assertIsNone(button._job)
        button.destroy()

    def test_editing_updates_unsaved_indicator(self):
        self.app._update_document_state()
        self.assertIn('READY', self.app.document_state.cget('text'))
        self.app.body_text.insert('1.0', 'A new draft')
        self.app._update_document_state()
        self.assertIn('UNSAVED', self.app.document_state.cget('text'))
        self.app._reset_editor()
        self.app._update_document_state()
        self.assertIn('READY', self.app.document_state.cget('text'))

    def test_controls_fit_small_and_normal_windows(self):
        self.app.attributes('-fullscreen', False)
        self.app.deiconify()
        self.app.image_path = str(Path(__file__).with_name('assets') / 'dysociate.png')
        self.app._show_image()
        self.assertIsNotNone(self.app._preview)
        for width, height in ((1180, 850), (1024, 768), (980, 720)):
            self.app.geometry(f'{width}x{height}+20+20')
            self.app.update()
            self.app.update_idletasks()
            bottom = self.app.winfo_rooty() + self.app.winfo_height()
            right = self.app.winfo_rootx() + self.app.winfo_width()
            for widget in (self.app.brand_slogan, self.app.brand_subtitle,
                           self.app.body_text, self.app.commit_button, self.app.delete_button,
                           self.app.choose_image_button, self.app.window_button, self.app.document_state):
                self.assertLessEqual(widget.winfo_rooty() + widget.winfo_height(), bottom + 1,
                                     (width, height, str(widget)))
                self.assertLessEqual(widget.winfo_rootx() + widget.winfo_width(), right + 1,
                                     (width, height, str(widget)))
            self.assertGreaterEqual(self.app.body_text.winfo_height(), 40, (width, height))
            for label in (self.app.brand_slogan, self.app.brand_subtitle):
                self.assertGreaterEqual(label.winfo_height(), label.winfo_reqheight())

    def test_terms_unlock_at_end_of_each_page_and_keep_footer_visible(self):
        self.app.deiconify()
        for decline_at in (1, 2, None):
            failures = []
            self.app.status.set('Ready.')

            def choose():
                dialog = next(child for child in self.app.winfo_children()
                              if isinstance(child, tk.Toplevel))
                try:
                    widgets = [widget for frame in dialog.winfo_children()
                               for widget in frame.winfo_children()]
                    terms = next(widget for widget in widgets if isinstance(widget, tk.Text))
                    buttons = {widget.cget('text'): widget for widget in widgets
                               if isinstance(widget, NeonButton)}
                    agree, decline = buttons['I agree'], buttons['Close']
                    dialog.geometry('460x360')
                    dialog.update()

                    def check_in_view(button):
                        self.assertTrue(button.winfo_viewable())
                        self.assertLessEqual(button.winfo_rootx() + button.winfo_width(),
                                             dialog.winfo_rootx() + dialog.winfo_width())
                        self.assertLessEqual(button.winfo_rooty() + button.winfo_height(),
                                             dialog.winfo_rooty() + dialog.winfo_height())

                    self.assertIn("LUNA LOVE'S NO-WARRANTY AND LIABILITY DISCLAIMER", terms.get('1.0', 'end'))
                    self.assertLess(terms.yview()[1], 1.0)
                    self.assertFalse(agree.winfo_viewable())
                    check_in_view(decline)
                    license_font = Font(root=dialog, font=terms.cget('font'))['size']
                    agree.invoke()
                    self.assertIn('License Agreement', dialog.title())
                    if decline_at == 1:
                        decline.invoke()
                        return
                    terms.yview_moveto(1.0)
                    dialog.update_idletasks()
                    check_in_view(agree)
                    check_in_view(decline)
                    agree.invoke()
                    dialog.update_idletasks()
                    self.assertTrue(terms.get('1.0', 'end-1c').endswith(
                        KARMIC_LAW + '\n\n~ as above so below ~'))
                    self.assertGreater(Font(root=dialog, font=terms.cget('font'))['size'], license_font)
                    check_in_view(decline)
                    if decline_at == 2:
                        self.assertLess(terms.yview()[1], 1.0)
                        self.assertFalse(agree.winfo_viewable())
                        agree.invoke()
                        self.assertTrue(dialog.winfo_exists())
                        decline.invoke()
                        return
                    if terms.yview()[1] < 1.0:
                        self.assertFalse(agree.winfo_viewable())
                        terms.yview_moveto(1.0)
                        dialog.update_idletasks()
                    check_in_view(agree)
                    agree.invoke()
                except Exception as error:
                    failures.append(error)
                finally:
                    if dialog.winfo_exists():
                        dialog.destroy()

            wording = '\n\n'.join([KARMIC_LAW] * 12) if decline_at == 2 else KARMIC_LAW
            with patch('dysociate_gui.KARMIC_LAW', wording):
                self.app.after(50, choose)
                self.app.show_terms()
            if failures:
                raise failures[0]
            self.assertEqual(self.app.status.get(), 'Karmic Law agreed.' if decline_at is None else 'Ready.')

    def test_failed_delete_restores_post_and_draft(self):
        self.app.doc.page.sections = [Section('Post', 'Keep me', 'Original text', post_id='p1')]
        self.app._load_editor(self.app.doc.page.sections[0])
        from pathlib import Path
        self.app.doc.path = Path('test-only.html')
        before = copy.deepcopy(self.app.doc.page)
        draft = self.app._signature()
        with patch.object(self.app.doc, 'refresh', return_value=False), \
             patch.object(self.app.doc, 'save', side_effect=OSError('Test failed deletion')), \
             patch('dysociate_gui.messagebox.askyesno', return_value=True), \
             patch('dysociate_gui.messagebox.showerror'):
            self.app.delete_post()
        self.assertEqual(self.app.doc.page, before)
        self.assertEqual(self.app._signature(), draft)
        self.assertEqual(self.app.selected_id, 'p1')


class LaunchTests(unittest.TestCase):
    def test_launch_constructs_editor_only_after_agreement(self):
        from pathlib import Path

        for accepted in (False, True):
            with self.subTest(accepted=accepted), \
                 patch('sys.argv', ['dysociate.exe', 'thread.html']), \
                 patch('dysociate_gui.DysociateApp') as editor:
                def review():
                    editor.assert_not_called()
                    return accepted

                with patch('dysociate_gui.review_terms', side_effect=review) as terms:
                    self.assertEqual(main(), 0)
                terms.assert_called_once_with()
                if accepted:
                    editor.assert_called_once_with(Path('thread.html'))
                    editor.return_value.mainloop.assert_called_once_with()
                else:
                    editor.assert_not_called()


if __name__ == '__main__':
    unittest.main()
