"""A small file-backed document model for the dysociate GUI.

Copyright (c) 2026 Luna Love ~ LunaSoft
SPDX-License-Identifier: GPL-3.0-or-later. See LICENSE.

The HTML is the document. Before editing or sharing, reload external browser
changes so a newly added reply cannot be silently overwritten by stale GUI
state. Writes are staged alongside the destination and replaced atomically.
"""

from __future__ import annotations

import hashlib
import os
import tempfile
import threading
from collections import defaultdict
from pathlib import Path

from pagebuilder_gui import Page, Section, load_page, render_html


# Two different locks solve two different problems. The registry lock protects
# creation of a lock object; it is released before any file I/O. The per-file
# RLock covers a whole read/modify/write transaction. It must be re-entrant:
# BrowserPreview holds it, then calls open() and save(), which acquire it again.
# These locks coordinate threads in THIS PROCESS, not other app instances.
_file_locks: dict[str, threading.RLock] = defaultdict(threading.RLock)
_registry_lock = threading.Lock()


def page_file_lock(path: Path):
    """Return one process-local lock for all spellings of the same opened path.

    resolve() removes relative components; normcase() also folds Windows case.
    Without normalization, C:\\Pages\\index.html and c:\\pages\\index.html could
    get independent locks even though they name the same file on Windows.
    """
    with _registry_lock:
        return _file_locks[os.path.normcase(str(path.resolve()))]


class ThreadDocument:
    """An editable model plus the fingerprint of its last observed disk version.

    ``page`` is Python state, not a live view of the file. ``_disk_hash`` records
    the exact bytes that state was loaded/saved against. Refresh before editing;
    save checks again inside the write lock. docs/DEVELOPER_GUIDE.md follows a
    browser reply and GUI edit through this sequence step by step.
    """
    def __init__(self) -> None:
        self.page = Page(title='', terminal_banner='')
        self.path: Path | None = None
        self._disk_hash = ''

    @staticmethod
    def file_hash(path: Path) -> str:
        return hashlib.sha256(path.read_bytes()).hexdigest()

    def open(self, path: Path) -> None:
        # Read the model and fingerprint under the same lock. Otherwise another
        # request could replace the file between these two reads, leaving a
        # fingerprint for version B attached to a model loaded from version A.
        with page_file_lock(path):
            self.page = load_page(str(path))
            self.path = path.resolve()
            self._disk_hash = self.file_hash(self.path)

    def refresh(self) -> bool:
        """Reload external changes; return True only when a reload occurred.

        The GUI keeps its text-entry buffers separately, so reloading this
        model does not discard a draft. The caller decides whether the edited
        post itself changed or only unrelated replies were added.
        """
        if self.path and self.path.exists() and self.file_hash(self.path) != self._disk_hash:
            self.open(self.path)
            return True
        return False

    def save(self, path: Path | None = None) -> Path:
        """Write the current model, refusing to overwrite an unseen file version.

        Refreshing before an edit is not enough: a browser can save a reply
        between refresh() and this call. The second hash comparison closes that
        gap for writes using our shared lock. A different Save As destination
        deliberately has no old fingerprint; its selection belongs to the caller.
        """
        destination = (path or self.path)
        if destination is None:
            raise ValueError('Choose where to save this page.')
        destination = destination.resolve()
        with page_file_lock(destination):
            if self.path == destination and destination.exists() and self._disk_hash:
                if self.file_hash(destination) != self._disk_hash:
                    raise ValueError('The page changed while saving. Your draft is kept; save again to include the latest replies.')
            return self._save_locked(destination)

    def _save_locked(self, destination: Path) -> Path:
        """Stage complete HTML next to the target, then replace it in one step.

        Same-directory staging keeps the rename on the same filesystem.
        Closing mkstemp's descriptor before rendering matters on Windows, where
        leaving it open can prevent another open or rename of the temporary file.
        This avoids truncating the original during rendering. It is not a disk
        journal, backup, or guarantee against power loss; no fsync is performed.
        """
        descriptor, temporary = tempfile.mkstemp(prefix='.dysociate-', suffix='.html', dir=destination.parent)
        os.close(descriptor)
        try:
            render_html(self.page, temporary)
            os.replace(temporary, destination)
        finally:
            # After success os.replace() has moved this name away. After failure
            # remove only the staging file; never delete the destination here.
            if Path(temporary).exists():
                Path(temporary).unlink()
        # The saved document now owns embedded copies of all images, so a
        # later save does not depend on the original selected photo existing.
        for section in self.page.sections:
            if section.image_data_url:
                section.image_path = ''
        self.path = destination
        self.page.output_path = str(destination)
        self._disk_hash = self.file_hash(destination)
        return destination

    def delete(self, post_id: str) -> None:
        """Remove the post and its descendants from the in-memory model.

        Replies are stored as a flat list. Repeatedly expanding the ID set finds
        grandchildren at any list position, rather than assuming replies are
        adjacent or appear after their parent. The set makes the search stop
        even if malformed imported parent links contain a cycle. This method
        does not save; the UI can still report a write failure separately.
        """
        removed = {post_id}
        while True:
            next_ids = {section.post_id for section in self.page.sections if section.parent_id in removed}
            if next_ids.issubset(removed):
                break
            removed.update(next_ids)
        self.page.sections = [section for section in self.page.sections if section.post_id not in removed]
