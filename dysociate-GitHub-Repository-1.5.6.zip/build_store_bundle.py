"""Prepare buyer-friendly downloads from an already verified release.

Copyright (c) 2026 Luna Love ~ LunaSoft
SPDX-License-Identifier: GPL-3.0-or-later. See LICENSE.

The source is supplied with the portable application and as a separate ZIP
beside the installer, at no additional charge. Store artifacts exclude ISO
duplication, build caches, personal HTML files, and owner-only marketing drafts.
Every archive payload is read back and hashed before reporting success.
"""
import argparse
import hashlib
from pathlib import Path
import shutil
from zipfile import ZipFile, ZIP_DEFLATED


def digest(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def checked_zip(path, files):
    with ZipFile(path, 'w', compression=ZIP_DEFLATED, compresslevel=6) as archive:
        for source, name in files:
            archive.write(source, name)
    with ZipFile(path) as archive:
        if len(archive.namelist()) != len(files):
            raise RuntimeError('Store ZIP membership differs from its input list.')
        for source, name in files:
            if hashlib.sha256(archive.read(name)).hexdigest() != digest(source):
                raise RuntimeError('Store ZIP readback failed: ' + name)


def build(root):
    package = root / 'dysociate'
    destination = root / 'Store'
    # This is mutable build staging, not a frozen snapshot. Rebuild only the
    # same named artifacts; never enumerate/delete a user's other files.
    destination.mkdir(exist_ok=True)
    source_files = [(path, 'Source/' + path.relative_to(package / 'Source').as_posix())
                    for path in sorted((package / 'Source').rglob('*')) if path.is_file()]
    checked_zip(destination / 'dysociate-1.5.6-source.zip', source_files)
    portable_files = [(path, 'dysociate/' + path.relative_to(package).as_posix())
                      for path in sorted(package.rglob('*'))
                      if path.is_file() and path.name not in {'dysociate-setup.exe', 'SHA256SUMS.txt'}]
    checked_zip(destination / 'dysociate-1.5.6-portable-windows-x64.zip', portable_files)
    browser_files = [(path, 'Browser/' + path.relative_to(package / 'Browser').as_posix())
                     for path in sorted((package / 'Browser').rglob('*')) if path.is_file()]
    # Include corresponding source with the install-free browser download too.
    checked_zip(destination / 'dysociate-1.5.6-browser.zip', browser_files + source_files)
    for source, name in [(package / 'dysociate-setup.exe', 'dysociate-1.5.6-setup.exe'),
                         (package / 'Documentation' / 'User_Manual.docx', 'User_Manual.docx'),
                         (package / 'LICENSE', 'LICENSE.txt')]:
        shutil.copy2(source, destination / name)
    (destination / 'START_HERE.txt').write_text(
        'dλsociate 1.5.6\ncreated by luna love, lunasoft λ 2026\n\n'
        'INSTALL: Run dysociate-1.5.6-setup.exe. Source and manuals install with it.\n'
        'PORTABLE: Extract the portable ZIP fully, then open dysociate/dysociate.exe.\n'
        'SOURCE: The matching editable source is also in the source ZIP.\n\n'
        'No Python or WSL installation is needed for the executable.\n'
        'Alt+Enter switches fullscreen/window mode. Esc asks before quitting.\n'
        'Help or F1 opens the offline manual. The Word edition is included.\n\n'
        'Choose an image, write text, Add post, then Save and choose index.html.\n'
        'BROWSER: Open Browser/index.html or publish it on a static HTTPS host.\n'
        'Recipients post, reply, add images and save/share HTML in the browser.\n'
        'The desktop app is optional. Phone attachment previews may need the\n'
        'hosted browser editor: tap Open HTML and choose the received file.\n'
        'Share sends the saved HTML itself or an EML with HTML attached.\n'
        'Keep the app open while posting through its browser preview.\n'
        'Separate copies do not sync. Threads are not encrypted.\n\n'
        'GPL-3.0-or-later. Copyright (c) 2026 Luna Love ~ LunaSoft.\n'
        'Your original posts and pictures remain your content.\n', encoding='utf-8')
    items = sorted(path for path in destination.iterdir() if path.is_file() and path.name != 'SHA256SUMS.txt')
    (destination / 'SHA256SUMS.txt').write_text(
        '\n'.join(f'{digest(path)}  {path.name}' for path in items) + '\n', encoding='utf-8')
    print(f'PASS: installer, source ZIP, portable ZIP, manual and checksums: {destination}')


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('release_root', type=Path)
    build(parser.parse_args().release_root.resolve())
