"""Regression tests for direct saves, exact-file routing, and concurrent replies.

Copyright (c) 2026 Luna Love ~ LunaSoft
SPDX-License-Identifier: GPL-3.0-or-later. See LICENSE.
Run with: python -m unittest test_saving
"""

import json
import tempfile
import unittest
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
from unittest.mock import patch
from urllib.error import HTTPError
from urllib.request import Request, urlopen

from browser_preview import BrowserPreview
from pagebuilder_gui import Page, Section, load_page, render_html
from thread_document import ThreadDocument


class SavingTests(unittest.TestCase):
    def setUp(self):
        self.folder = tempfile.TemporaryDirectory(prefix='dysociate-save-test-')
        self.path = Path(self.folder.name) / 'index.html'
        page = Page(title='Original title', sections=[Section('Post', 'Original', 'Keep me.', post_id='p1')])
        render_html(page, str(self.path))
        self.preview = BrowserPreview()
        self.url = self.preview.open_page(self.path)
        self.endpoint = self.url.rsplit('/', 1)[0] + '/comment'

    def tearDown(self):
        self.preview.close()
        self.folder.cleanup()

    def post(self, identifier='reply1', origin=None, **fields):
        payload = dict(post_id=identifier, parent_id='p1', heading='Reply', body='Saved in place.', image_data_url='')
        payload.update(fields)
        request = Request(self.endpoint, data=json.dumps(payload).encode('utf-8'),
                          headers={'Origin': origin or self.preview.origin, 'Content-Type': 'application/json'})
        return json.loads(urlopen(request, timeout=10).read())

    def test_save_changes_only_the_opened_file(self):
        other = self.path.with_name('other.html')
        other.write_bytes(self.path.read_bytes())
        before = other.read_bytes()
        result = self.post(output_path=str(other))
        saved = load_page(str(self.path))
        self.assertEqual(saved.title, 'Original title')
        self.assertEqual(len(saved.sections), 2)
        self.assertEqual(saved.sections[1].parent_id, 'p1')
        self.assertEqual(len(result['page']['sections']), 2)
        self.assertEqual(other.read_bytes(), before)
        self.assertNotIn('id="dysociate-bridge"', self.path.read_text(encoding='utf-8'))

    def test_duplicate_retry_does_not_duplicate_reply(self):
        self.post()
        self.post()
        self.assertEqual(len(load_page(str(self.path)).sections), 2)

    def test_parallel_replies_are_both_saved(self):
        with ThreadPoolExecutor(max_workers=2) as worker:
            futures = [worker.submit(self.post, 'reply' + str(number)) for number in range(6)]
            for future in futures:
                future.result()
        self.assertEqual(len(load_page(str(self.path)).sections), 7)

    def test_browser_get_is_non_mutating_and_connected(self):
        before = self.path.read_bytes()
        source = urlopen(self.url, timeout=10).read().decode('utf-8')
        self.assertIn('id="dysociate-bridge"', source)
        self.assertNotIn('Enable automatic saving', source)
        self.assertEqual(self.path.read_bytes(), before)

    def test_foreign_page_cannot_write(self):
        before = self.path.read_bytes()
        with self.assertRaises(HTTPError) as failure:
            self.post(origin='https://example.com')
        self.assertEqual(failure.exception.code, 403)
        self.assertEqual(self.path.read_bytes(), before)

    def test_stale_gui_save_does_not_erase_browser_reply(self):
        document = ThreadDocument()
        document.open(self.path)
        self.post()
        document.page.title = 'Unsaved GUI title'
        with self.assertRaises(ValueError):
            document.save()
        self.assertEqual(len(load_page(str(self.path)).sections), 2)

    def test_failed_write_keeps_original_file(self):
        before = self.path.read_bytes()
        with patch.object(ThreadDocument, 'save', side_effect=OSError('test disk failure')):
            with self.assertRaises(HTTPError) as failure:
                self.post()
        self.assertEqual(failure.exception.code, 500)
        self.assertEqual(self.path.read_bytes(), before)

    def test_image_only_reply(self):
        image = 'data:image/png;base64,iVBORw0KGgo='
        self.post(body='', image_data_url=image)
        self.assertEqual(load_page(str(self.path)).sections[1].image_data_url, image)


if __name__ == '__main__':
    unittest.main()
