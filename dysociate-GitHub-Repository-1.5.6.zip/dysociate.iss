; dysociate - per-user Windows installer
; Copyright (c) 2026 Luna Love ~ LunaSoft
; SPDX-License-Identifier: GPL-3.0-or-later. See LICENSE.
; Installation manages program files and shortcuts, never saved HTML threads.

#ifndef PackageDir
  #define PackageDir ".."
#endif
#ifndef OutputDir
  #define OutputDir ".."
#endif

[Setup]
AppId={{946568EF-35C7-4BF8-9E0D-6323B273B143}
AppName=dλsociate
AppVersion=1.5.6
AppPublisher=Luna Love ~ LunaSoft
AppCopyright=Copyright (c) 2026 Luna Love ~ LunaSoft
VersionInfoDescription=dλsociate Setup
VersionInfoProductName=dλsociate
DefaultDirName={localappdata}\Programs\dysociate
DefaultGroupName=dysociate
PrivilegesRequired=lowest
ArchitecturesAllowed=x64compatible
ArchitecturesInstallIn64BitMode=x64compatible
MinVersion=10.0
OutputDir={#OutputDir}
OutputBaseFilename=dysociate-setup
SetupIconFile={#PackageDir}\dysociate.ico
UninstallDisplayIcon={app}\dysociate.exe
LicenseFile={#PackageDir}\LICENSE
WizardStyle=modern
Compression=lzma2
SolidCompression=yes
DisableProgramGroupPage=yes
CloseApplications=no

[Tasks]
Name: "desktopicon"; Description: "Create a desktop shortcut"; GroupDescription: "Shortcuts:"

[Files]
Source: "{#PackageDir}\dysociate.exe"; DestDir: "{app}"; Flags: ignoreversion
Source: "{#PackageDir}\dysociate.ico"; DestDir: "{app}"; Flags: ignoreversion
Source: "{#PackageDir}\dysociate.png"; DestDir: "{app}"; Flags: ignoreversion
Source: "{#PackageDir}\README.md"; DestDir: "{app}"; Flags: ignoreversion
Source: "{#PackageDir}\LICENSE"; DestDir: "{app}"; Flags: ignoreversion
Source: "{#PackageDir}\LICENSE_HISTORY.md"; DestDir: "{app}"; Flags: ignoreversion
Source: "{#PackageDir}\THIRD_PARTY_NOTICES.md"; DestDir: "{app}"; Flags: ignoreversion
Source: "{#PackageDir}\Source\*"; DestDir: "{app}\Source"; Flags: ignoreversion recursesubdirs createallsubdirs
Source: "{#PackageDir}\Browser\*"; DestDir: "{app}\Browser"; Flags: ignoreversion recursesubdirs createallsubdirs
Source: "{#PackageDir}\Licenses\*"; DestDir: "{app}\Licenses"; Flags: ignoreversion recursesubdirs createallsubdirs
; Keep persistent manuals beside the EXE: Help can remain open after the
; one-file runtime removes its temporary extraction directory on exit.
Source: "{#PackageDir}\Documentation\*"; DestDir: "{app}\Documentation"; Flags: ignoreversion recursesubdirs createallsubdirs

[Icons]
Name: "{group}\dλsociate"; Filename: "{app}\dysociate.exe"; WorkingDir: "{userdocs}"; IconFilename: "{app}\dysociate.ico"
Name: "{group}\Uninstall dλsociate"; Filename: "{uninstallexe}"
Name: "{group}\dλsociate Help"; Filename: "{app}\Documentation\User_Manual.html"
Name: "{userdesktop}\dλsociate"; Filename: "{app}\dysociate.exe"; WorkingDir: "{userdocs}"; IconFilename: "{app}\dysociate.ico"; Tasks: desktopicon

; Add an optional Open with entry without taking over the user's browser
; association for ordinary HTML files.
[Registry]
Root: HKCU; Subkey: "Software\Classes\Applications\dysociate.exe\shell\open\command"; ValueType: string; ValueData: """{app}\dysociate.exe"" ""%1"""; Flags: uninsdeletekey
Root: HKCU; Subkey: "Software\Classes\Applications\dysociate.exe\SupportedTypes"; ValueType: string; ValueName: ".html"; ValueData: ""; Flags: uninsdeletekey
Root: HKCU; Subkey: "Software\Classes\Applications\dysociate.exe\SupportedTypes"; ValueType: string; ValueName: ".htm"; ValueData: ""; Flags: uninsdeletekey

[Run]
Filename: "{app}\dysociate.exe"; Description: "Launch dλsociate"; Flags: nowait postinstall skipifsilent
