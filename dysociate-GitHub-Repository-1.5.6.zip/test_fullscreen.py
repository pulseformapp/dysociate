"""Exercise fullscreen transitions through real Tk shortcut dispatch.

Copyright (c) 2026 Luna Love ~ LunaSoft
SPDX-License-Identifier: GPL-3.0-or-later. See LICENSE.

Uses a temporary app window, not native keystrokes sent to another program.
No browser, file picker, or sharing service is opened.
"""

import time
import unittest
from unittest.mock import patch

from dysociate_gui import DysociateApp


class FullscreenTests(unittest.TestCase):
    def test_startup_shortcuts_and_window_restoration_preserve_draft(self):
        app = DysociateApp()
        try:
            def settle():
                # Windows applies window-manager geometry asynchronously.
                for _ in range(6):
                    app.update()
                    time.sleep(.025)

            settle()
            self.assertTrue(app.attributes('-fullscreen'))
            app.toggle_fullscreen()
            settle()
            self.assertFalse(app.attributes('-fullscreen'))
            app.geometry('1040x780+45+45')
            settle()
            windowed = app.geometry()
            app.post_title.set('Keep this draft')
            app.body_text.insert('1.0', 'My text must not gain a newline or be posted.')
            draft = app._signature()

            # The Text widget and button class normally handle Enter too.
            # Test dispatch, not only direct calls to toggle_fullscreen().
            for widget, key in ((app.body_text, '<Alt-Return>'),
                                (app.commit_button, '<Alt-Return>'),
                                (app, '<Alt-Return>')):
                widget.focus_force()
                settle()
                widget.event_generate(key)
                settle()
                self.assertTrue(app.attributes('-fullscreen'),
                                f'{widget.winfo_class()} {key}; focus={app.focus_get()}')
                widget.event_generate(key)
                settle()
                self.assertFalse(app.attributes('-fullscreen'))
                self.assertEqual(app.geometry(), windowed)
                self.assertEqual(app._signature(), draft)
                self.assertEqual(app.doc.page.sections, [])

            # Ordinary Enter still edits text after installing the private tag.
            app.body_text.focus_force()
            app.body_text.mark_set('insert', 'end-1c')
            app.body_text.event_generate('<Return>')
            settle()
            self.assertEqual(app.body_text.get('1.0', 'end-1c'), draft[1] + '\n')

            # Esc must reach the quit flow from editor/button focus. Cancel
            # keeps both the current mode and the actual editor contents.
            app.toggle_fullscreen()
            settle()
            self.assertTrue(app.attributes('-fullscreen'))
            for widget in (app.body_text, app.commit_button):
                widget.focus_force()
                settle()
                before = app._signature()
                mode = app.attributes('-fullscreen')
                with patch('dysociate_gui.messagebox.askyesnocancel', return_value=None) as prompt:
                    widget.event_generate('<Escape>')
                    settle()
                    prompt.assert_called_once()
                self.assertEqual(app._signature(), before)
                self.assertEqual(app.attributes('-fullscreen'), mode)
        finally:
            app.destroy()


if __name__ == '__main__':
    unittest.main()
