"""dysociate - a phosphor-green, mouse-first offline thread editor.

Copyright (c) 2026 Luna Love ~ LunaSoft
SPDX-License-Identifier: GPL-3.0-or-later. See LICENSE.

The GUI follows the generated webpage's visual language: near-black panels,
green text, amber borders, and ordinary readable fonts. A post has just an
image, title, and body. The document and Windows sharing adapters are separate
modules so presentation cannot become a second, incompatible file format.
"""

from __future__ import annotations

import argparse
import base64
import ctypes
import copy
import io
import json
import os
import subprocess
import sys
import tkinter as tk
import uuid
import webbrowser
from dataclasses import asdict, replace
from pathlib import Path
from tkinter import filedialog, messagebox, ttk
from tkinter.font import Font

from PIL import Image, ImageTk

from pagebuilder_gui import Section, self_test
from thread_document import ThreadDocument
from app_resources import KARMIC_LAW, KARMIC_SIGNOFF, help_manual_path, license_text
from ui_theme import (NeonButton, configure_scrollbar, motion_allowed, blend, BLACK,
                      PANEL, FIELD, BAR, GREEN, MUTED, LINE, SELECT, AMBER, CYAN, TEXT, FONT)


ASSETS = Path(getattr(sys, '_MEIPASS', Path(__file__).resolve().parent)) / 'assets'


def review_terms(parent: tk.Tk | None = None) -> bool:
    """Present both agreements and return true only after both are accepted."""
    window = tk.Toplevel(parent) if parent is not None else tk.Tk()
    window.withdraw()
    window.configure(bg=BLACK)
    screen_width, screen_height = window.winfo_screenwidth(), window.winfo_screenheight()
    width, height = min(740, screen_width - 64), min(550, screen_height - 96)
    window.geometry(f'{width}x{height}+{(screen_width - width) // 2}+{(screen_height - height) // 2}')
    window.minsize(min(460, width), min(360, height))
    style = ttk.Style(window)
    style.theme_use('clam')
    configure_scrollbar(style)
    if parent is not None:
        window.transient(parent)

    # Only the document row grows or shrinks. The footer keeps its own space.
    window.columnconfigure(0, weight=1)
    window.rowconfigure(1, weight=1)
    heading = tk.Label(window, bg=BLACK, fg=AMBER, font=(FONT, 20, 'bold'))
    heading.grid(row=0, column=0, sticky='w', padx=24, pady=(20, 10))
    content = tk.Frame(window, bg=BLACK)
    content.grid(row=1, column=0, sticky='nsew', padx=24)
    scroll = ttk.Scrollbar(content, orient='vertical', style='Terminal.Vertical.TScrollbar')
    scroll.pack(side='right', fill='y')
    text = tk.Text(content, bg=PANEL, fg=TEXT, font=(FONT, 11), wrap='word',
                   width=1, height=1, padx=14, pady=14, relief='flat')
    text.pack(fill='both', expand=True)
    scroll.configure(command=text.yview)

    agreed = False
    reached_end = False

    def unlock_if_at_end():
        nonlocal reached_end
        if not reached_end and text.winfo_viewable() and text.yview()[1] >= 1.0:
            reached_end = True
            scroll_hint.grid_remove()
            agree_button.grid()

    def report_scroll(first, last):
        scroll.set(first, last)
        unlock_if_at_end()

    def finish():
        nonlocal agreed
        if not reached_end:
            return
        agreed = True
        window.destroy()

    def set_page(title, step, wording, font_size):
        nonlocal reached_end
        reached_end = False
        agree_button.grid_remove()
        scroll_hint.grid()
        window.title(f'{title} · dλsociate')
        heading.configure(text=f'{step} OF 2  /  {title.upper()}')
        text.configure(state='normal', font=(FONT, font_size))
        text.delete('1.0', 'end')
        text.insert('1.0', wording)
        text.configure(state='disabled')
        text.yview_moveto(0)
        text.focus_set()

    def show_karmic_law():
        if not reached_end:
            return
        agree_button.configure(command=finish)
        set_page('Karmic Law', 2, f'{KARMIC_LAW}\n\n{KARMIC_SIGNOFF}', 18)
        window.update_idletasks()
        unlock_if_at_end()

    def cancel_from_keyboard(_event):
        window.destroy()
        return 'break'

    actions = tk.Frame(window, bg=BLACK)
    actions.grid(row=2, column=0, sticky='ew', padx=24, pady=16)
    actions.columnconfigure(1, weight=1)
    decline_label = 'Decline and exit' if parent is None else 'Close'
    NeonButton(actions, decline_label, window.destroy, subtle=True).grid(row=0, column=0, sticky='w')
    scroll_hint = tk.Label(actions, text='Scroll to the end to agree', bg=BLACK, fg=MUTED,
                           font=(FONT, 10), wraplength=190, justify='center')
    scroll_hint.grid(row=0, column=1, padx=8)
    agree_button = NeonButton(actions, 'I agree', show_karmic_law, primary=True)
    agree_button.grid(row=0, column=2, sticky='e')
    text.configure(yscrollcommand=report_scroll)
    window.protocol('WM_DELETE_WINDOW', window.destroy)
    window.bind('<Escape>', cancel_from_keyboard)
    set_page('License Agreement', 1, license_text(), 11)
    window.deiconify()
    window.update_idletasks()
    unlock_if_at_end()
    if parent is None:
        window.mainloop()
    else:
        window.grab_set()
        parent.wait_window(window)
    return agreed


class DysociateApp(tk.Tk):
    """Coordinate three states: editor widgets, the Page model, and saved HTML.

    A widget draft is deliberately separate from doc.page, which can be
    refreshed when browser replies arrive. selected_id names a post being edited;
    parent_id names the parent of a new reply. Empty selected_id means 'append',
    not 'edit the first item'. See docs/DEVELOPER_GUIDE.md for the state diagram.
    """
    def __init__(self, initial_path: Path | None = None) -> None:
        super().__init__()
        self.title('dλsociate')
        self.geometry('1180x850')
        self.minsize(980, 720)
        # Set this before the first window map to launch without a windowed
        # flash. Tk retains the normal window's placement for Alt+Enter.
        self.attributes('-fullscreen', True)
        self.configure(bg=BLACK)
        try:
            self.iconbitmap(str(ASSETS / 'dysociate.ico'))
        except tk.TclError:
            pass
        self.doc = ThreadDocument()
        self.selected_id = ''
        self.parent_id = ''
        self.image_path = ''
        self.image_data = ''
        self.image_alt = ''
        self._preview = None
        self._post_baseline = ''
        # Two baselines answer different questions. The widget signature asks
        # 'did the user type/change an image?'; the serialized post asks 'did
        # somebody else change the same post while this draft was open?'.
        self._draft_baseline = ('', '', '', '')
        self._busy = False
        self._quit_prompt_open = False
        self._state_job = None
        self._feedback_job = None
        self._closing = False
        self._share_dialog = None
        self._preview_server = None
        self.page_title = tk.StringVar()
        self.banner = tk.StringVar()
        self.post_title = tk.StringVar()
        self.status = tk.StringVar(value='Ready. Add a post, or open an existing page.')
        self.file_label = tk.StringVar(value='NOT SAVED YET')
        self.editor_label = tk.StringVar(value='[ NEW POST ]')
        self.counter = tk.StringVar(value='0 POSTS')
        self._build()
        self._bind_window_shortcuts()
        self._reset_editor()
        for variable in (self.page_title, self.banner, self.post_title):
            variable.trace_add('write', lambda *args: self._queue_document_state())
        self.body_text.bind('<<Modified>>', self._text_changed, add='+')
        self._queue_document_state()
        self.protocol('WM_DELETE_WINDOW', self.close)
        self.bind('<Control-o>', lambda event: self.open_page())
        self.bind('<Control-s>', lambda event: self.save_page())
        self.bind('<Control-n>', lambda event: self.new_page())
        self.bind('<Control-Return>', lambda event: self.add_post())
        self.bind('<F1>', lambda event: self.show_help())
        self.bind('<FocusIn>', self._focus_refresh)
        if initial_path:
            self.after(100, lambda: self.open_page(initial_path))

    def toggle_fullscreen(self, event=None) -> str:
        """Switch display mode without recreating widgets or changing the draft."""
        self.attributes('-fullscreen', not bool(self.attributes('-fullscreen')))
        if hasattr(self, 'window_button'):
            self.window_button.configure(text='Window' if self.attributes('-fullscreen') else 'Fullscreen')
        return 'break'

    def _bind_window_shortcuts(self) -> None:
        """Handle display/quit shortcuts before a focused widget's normal action.

        Tk normally visits widget, class, toplevel, then 'all' bindings. A
        toplevel-only shortcut can therefore run AFTER Text inserts a newline
        or a button activates. A private first bindtag consumes these shortcuts;
        other keyboard events still follow their original binding order.
        """
        tag = 'DysociateWindowShortcuts'
        self.bind_class(tag, '<Alt-Return>', self.toggle_fullscreen)
        self.bind_class(tag, '<Escape>', self.close)

        def attach(widget):
            widget.bindtags((tag, *widget.bindtags()))
            for child in widget.winfo_children():
                attach(child)
        attach(self)

    def label(self, parent, text='', **kwargs):
        options = {'bg': parent.cget('bg'), 'fg': TEXT, 'font': (FONT, 11), 'anchor': 'w'}
        return tk.Label(parent, text=text, **(options | kwargs))

    def button(self, parent, text, command, primary=False, subtle=False, danger=False):
        return NeonButton(parent, text, command, primary=primary, subtle=subtle, danger=danger)

    def entry(self, parent, variable):
        return tk.Entry(parent, textvariable=variable, bg=FIELD, fg=TEXT, width=1,
                        insertbackground=AMBER, insertwidth=2, selectbackground=SELECT,
                        selectforeground=TEXT, font=(FONT, 12), relief='flat', borderwidth=6,
                        highlightthickness=1, highlightbackground=LINE,
                        highlightcolor=CYAN)

    def section_bar(self, parent, title, detail):
        bar = tk.Frame(parent, bg=BAR)
        bar.grid(row=0, column=0, sticky='ew', pady=(0, 12))
        self.label(bar, title, fg=GREEN, font=(FONT, 12, 'bold')).pack(side='left', padx=12, pady=7)
        self.label(bar, textvariable=detail, fg=AMBER).pack(side='right', padx=12)

    def _build(self) -> None:
        style = ttk.Style(self)
        style.theme_use('clam')
        configure_scrollbar(style)
        shell = tk.Frame(self, bg=BLACK)
        shell.pack(fill='both', expand=True, padx=20, pady=14)
        top = tk.Frame(shell, bg=PANEL, highlightbackground=LINE, highlightthickness=1)
        top.pack(fill='x')
        self.brand_slogan = self.label(
            top, '~ the original off grid clandestine social network xD welcome to the outernet ~',
            bg=BAR, fg=GREEN, font=(FONT, 15, 'bold'), justify='left', padx=14, pady=7,
            wraplength=880,
        )
        self.brand_slogan.pack(fill='x')
        # Keep the full slogan on its own line across the header. Wrap against
        # the available width so the slogan can't squeeze the action buttons.
        self.brand_slogan.bind('<Configure>', lambda event: self.brand_slogan.configure(
            wraplength=max(1, event.width - 28)))
        top = tk.Frame(top, bg=PANEL)
        top.pack(fill='x', padx=14, pady=(7, 9))
        top.columnconfigure(1, weight=1)
        try:
            with Image.open(ASSETS / 'dysociate.png') as source:
                self._logo = ImageTk.PhotoImage(source.resize((62, 62), Image.Resampling.LANCZOS))
            tk.Label(top, image=self._logo, bg=PANEL, highlightbackground=CYAN,
                     highlightthickness=1, bd=0).grid(row=0, column=0, padx=(0, 12))
        except (OSError, tk.TclError):
            pass
        branding = tk.Frame(top, bg=PANEL)
        branding.grid(row=0, column=1, sticky='nsew', padx=(0, 18))
        branding.columnconfigure(0, weight=1)
        self.label(branding, 'dλsociate', fg=AMBER, font=(FONT, 34, 'bold')).grid(
            row=0, column=0, sticky='w')
        subtitle = 'OFFLINE THREADS / ONE HTML FILE / AI is kill /'
        credit = 'created by luna love, lunasoft λ 2026'
        subtitle_font = Font(root=self, family=FONT, size=12)
        self.brand_subtitle = self.label(branding, f'{subtitle} {credit}',
                                        fg=GREEN, font=subtitle_font, justify='left', wraplength=550)
        self.brand_subtitle.grid(row=1, column=0, sticky='ew')

        def wrap_subtitle(event):
            # Move the entire credit to the next line in narrower windows.
            available = max(1, event.width - 4)
            separator = ' ' if subtitle_font.measure(f'{subtitle} {credit}') <= available else '\n'
            self.brand_subtitle.configure(text=subtitle + separator + credit, wraplength=available)
        branding.bind('<Configure>', wrap_subtitle)
        self.header_actions = tk.Frame(top, bg=PANEL)
        self.header_actions.grid(row=0, column=2, sticky='e')
        self.button(self.header_actions, 'Help', self.show_help, subtle=True).grid(row=0, column=0, sticky='ew', padx=(0, 8), pady=(0, 8))
        self.window_button = self.button(self.header_actions, 'Window', self.toggle_fullscreen, subtle=True)
        self.window_button.grid(row=0, column=1, sticky='ew', padx=(0, 8), pady=(0, 8))
        self.button(self.header_actions, 'Quit', self.close, subtle=True, danger=True).grid(row=0, column=2, sticky='ew', pady=(0, 8))
        self.button(self.header_actions, 'Save', self.save_page).grid(row=1, column=0, sticky='ew', padx=(0, 8))
        self.button(self.header_actions, 'Preview', self.preview_page).grid(row=1, column=1, sticky='ew', padx=(0, 8))
        self.button(self.header_actions, 'Share ↗', self.share_page, primary=True).grid(row=1, column=2, sticky='ew')
        self.feedback_line = tk.Frame(shell, bg=LINE, height=2)
        self.feedback_line.pack(fill='x', pady=(0, 12))

        settings = tk.Frame(shell, bg=PANEL, highlightthickness=1, highlightbackground=LINE)
        settings.pack(fill='x', pady=(0, 12))
        settings.columnconfigure((0, 1), weight=1, uniform='page-fields')
        self.label(settings, '> PAGE TITLE', fg=GREEN).grid(row=0, column=0, sticky='w', padx=12, pady=(6, 2))
        self.label(settings, '> HEADER TEXT / OPTIONAL', fg=GREEN).grid(row=0, column=1, sticky='w', padx=12, pady=(6, 2))
        self.entry(settings, self.page_title).grid(row=1, column=0, sticky='ew', padx=12, pady=(0, 10))
        self.entry(settings, self.banner).grid(row=1, column=1, sticky='ew', padx=12, pady=(0, 10))

        body = tk.Frame(shell, bg=BLACK)
        body.pack(fill='both', expand=True)
        body.columnconfigure(1, weight=1)
        body.rowconfigure(0, weight=1)
        rail = tk.Frame(body, bg=PANEL, highlightthickness=1, highlightbackground=LINE, width=264)
        rail.grid(row=0, column=0, sticky='ns', padx=(0, 12))
        rail.grid_propagate(False)
        rail.columnconfigure(0, weight=1)
        rail.rowconfigure(3, weight=1)
        self.section_bar(rail, '// THREAD INDEX', self.counter)
        railtop = tk.Frame(rail, bg=PANEL)
        railtop.grid(row=1, column=0, sticky='ew', padx=12, pady=(0, 8))
        railtop.columnconfigure((0, 1), weight=1, uniform='thread-actions')
        self.button(railtop, 'New page', self.new_page, subtle=True).grid(row=0, column=0, sticky='ew', padx=(0, 4))
        self.button(railtop, 'Open…', self.open_page, subtle=True).grid(row=0, column=1, sticky='ew', padx=(4, 0))
        self.button(rail, '+ New post', self.new_post).grid(row=2, column=0, sticky='ew', padx=12, pady=(0, 10))
        listwrap = tk.Frame(rail, bg=FIELD)
        listwrap.grid(row=3, column=0, sticky='nsew', padx=12)
        listwrap.rowconfigure(0, weight=1)
        listwrap.columnconfigure(0, weight=1)
        self.posts = tk.Listbox(listwrap, bg=FIELD, fg=TEXT, font=(FONT, 11),
                                selectbackground=SELECT, selectforeground=GREEN,
                                activestyle='none', relief='flat', borderwidth=0,
                                highlightthickness=1, highlightbackground=LINE,
                                highlightcolor=CYAN, exportselection=False)
        self.posts.grid(row=0, column=0, sticky='nsew')
        self.posts.bind('<<ListboxSelect>>', self.select_post)
        scrollbar = ttk.Scrollbar(listwrap, orient='vertical', command=self.posts.yview, style='Terminal.Vertical.TScrollbar')
        scrollbar.grid(row=0, column=1, sticky='ns')
        def list_scroll(first, last):
            scrollbar.set(first, last)
            scrollbar.grid_remove() if float(first) <= 0 and float(last) >= 1 else scrollbar.grid()
        self.posts.configure(yscrollcommand=list_scroll)
        self.reply_button = self.button(rail, 'Reply to selected', self.reply_to_selected, subtle=True)
        self.reply_button.grid(row=4, column=0, sticky='ew', padx=12, pady=10)
        self.empty_hint = self.label(listwrap, 'No posts yet.\n\nWrite a post in the\ncomposer to start.', fg=MUTED, justify='left')
        self.empty_hint.place(x=14, y=12)

        editor = tk.Frame(body, bg=PANEL, highlightthickness=1, highlightbackground=LINE)
        editor.grid(row=0, column=1, sticky='nsew')
        editor.columnconfigure(0, weight=1)
        editor.rowconfigure(5, weight=1)
        self.section_bar(editor, '// COMPOSER', self.editor_label)
        image_row = tk.Frame(editor, bg=FIELD, highlightthickness=1, highlightbackground=LINE)
        image_row.grid(row=1, column=0, sticky='ew', padx=14, pady=(0, 10))
        image_row.columnconfigure(0, weight=1)
        self.image_widget = self.label(image_row, fg=MUTED, cursor='hand2',
                                       justify='left', height=2)
        self.image_widget.grid(row=0, column=0, sticky='ew', padx=10, pady=6)
        self.image_widget.bind('<Button-1>', lambda event: self.choose_image())
        self.choose_image_button = self.button(image_row, 'Choose image', self.choose_image)
        self.choose_image_button.grid(row=0, column=1, padx=(0, 8))
        self.remove_image_button = self.button(image_row, 'Remove', self.remove_image, subtle=True)
        self.remove_image_button.grid(row=0, column=2, padx=(0, 12))
        self.label(editor, '> POST TITLE / OPTIONAL', fg=GREEN).grid(row=2, column=0, sticky='w', padx=14, pady=(0, 3))
        self.entry(editor, self.post_title).grid(row=3, column=0, sticky='ew', padx=14, pady=(0, 8))
        self.label(editor, '> YOUR TEXT', fg=GREEN).grid(row=4, column=0, sticky='w', padx=14, pady=(0, 3))
        textwrap = tk.Frame(editor, bg=FIELD)
        textwrap.grid(row=5, column=0, sticky='nsew', padx=14)
        textwrap.columnconfigure(0, weight=1)
        textwrap.rowconfigure(0, weight=1)
        self.body_text = tk.Text(textwrap, bg=FIELD, fg=TEXT, insertbackground=AMBER, insertwidth=2,
                                 font=(FONT, 12), relief='flat', borderwidth=0,
                                 highlightthickness=1, highlightbackground=LINE,
                                 highlightcolor=CYAN, wrap='word', undo=True,
                                 padx=12, pady=6, height=1, width=1,
                                 selectbackground=SELECT, selectforeground=TEXT)
        self.body_text.grid(row=0, column=0, sticky='nsew')
        textscroll = ttk.Scrollbar(textwrap, command=self.body_text.yview, style='Terminal.Vertical.TScrollbar')
        textscroll.grid(row=0, column=1, sticky='ns')
        def body_scroll(first, last):
            textscroll.set(first, last)
            textscroll.grid_remove() if float(first) <= 0 and float(last) >= 1 else textscroll.grid()
        self.body_text.configure(yscrollcommand=body_scroll)
        actions = tk.Frame(editor, bg=PANEL)
        actions.grid(row=6, column=0, sticky='ew', padx=14, pady=10)
        self.commit_button = self.button(actions, 'Add post  →', self.add_post, primary=True)
        self.commit_button.pack(side='left')
        self.button(actions, 'Clear draft', self.clear_draft, subtle=True).pack(side='left', padx=12)
        self.delete_button = self.button(actions, 'Delete', self.delete_post, subtle=True, danger=True)
        self.delete_button.pack(side='right')
        footer = tk.Frame(shell, bg=BAR, highlightthickness=1, highlightbackground=LINE, padx=10, pady=5)
        # Reserve the status area before the expanding editor consumes space.
        # Otherwise short windows can push save/quit feedback below the client.
        footer.pack(side='bottom', before=body, fill='x', pady=(10, 0))
        footer.columnconfigure(1, weight=1)
        self.document_state = self.label(footer, 'READY', fg=CYAN, font=(FONT, 11, 'bold'))
        self.document_state.grid(row=0, column=0, sticky='w', padx=(0, 16))
        self.status_widget = self.label(footer, textvariable=self.status,
                                        justify='left', wraplength=600)
        self.status_widget.grid(row=0, column=1, sticky='ew')
        self.status_widget.bind('<Configure>', lambda event: self.status_widget.configure(wraplength=max(100, event.width)))
        self.button(footer, 'Terms / Karmic Law', self.show_terms, subtle=True).grid(row=0, column=2, sticky='e', padx=(16, 0))
        self.label(footer, textvariable=self.file_label, fg=MUTED, font=(FONT, 10),
                   width=1).grid(row=1, column=1, sticky='ew')
        self.label(footer, 'ALT+ENTER  window  /  ESC  quit', fg=MUTED, font=(FONT, 10)).grid(
            row=1, column=2, sticky='e', padx=(16, 0))

    def _text_changed(self, event=None) -> None:
        if self.body_text.edit_modified():
            self.body_text.edit_modified(False)
            self._queue_document_state()

    def _queue_document_state(self) -> None:
        """Debounce keystrokes; show actual unsaved work, not a pretend sync light."""
        if self._closing:
            return
        if self._state_job is not None:
            self.after_cancel(self._state_job)
        self._state_job = self.after(90, self._update_document_state)

    def _update_document_state(self) -> None:
        if self._state_job is not None:
            self.after_cancel(self._state_job)
        self._state_job = None
        changed = (self._dirty() or self.page_title.get() != self.doc.page.title
                   or self.banner.get() != self.doc.page.terminal_banner)
        if changed or (self.doc.page.sections and not self.doc.path):
            label, color = '● UNSAVED', AMBER
        elif self.doc.path:
            label, color = '● SAVED', GREEN
        else:
            label, color = '● READY', CYAN
        self.document_state.configure(text=label, fg=color)

    def _saved_feedback(self) -> None:
        """A single short acknowledgement; never leave an idle redraw loop running."""
        self._queue_document_state()
        if self._feedback_job is not None:
            self.after_cancel(self._feedback_job)
        if not motion_allowed():
            self.feedback_line.configure(bg=LINE)
            self._feedback_job = None
            return

        def fade(step=0):
            self._feedback_job = None
            self.feedback_line.configure(bg=blend(GREEN, LINE, step / 12))
            if step < 12:
                self._feedback_job = self.after(24, lambda: fade(step + 1))
        fade()

    def _signature(self):
        """Capture editable values, excluding Tk Text's mandatory final newline."""
        return (self.post_title.get(), self.body_text.get('1.0', 'end-1c'), self.image_path, self.image_data)

    def _dirty(self) -> bool:
        return self._signature() != self._draft_baseline

    def _has_content(self) -> bool:
        return bool(self.post_title.get().strip() or self.body_text.get('1.0', 'end-1c').strip() or self.image_path or self.image_data)

    def _reset_editor(self) -> None:
        self.selected_id = self.parent_id = self.image_path = self.image_data = self.image_alt = ''
        self._post_baseline = ''
        self.post_title.set('')
        self.body_text.delete('1.0', 'end')
        self._show_image()
        self.editor_label.set('[ NEW POST ]')
        self.commit_button.configure(text='Add post  →')
        self.delete_button.configure(state='disabled')
        self.reply_button.configure(state='disabled')
        self.posts.selection_clear(0, 'end')
        self._draft_baseline = self._signature()

    def _show_image(self) -> None:
        """Create a thumbnail only; never shrink the image stored in the thread.

        Tk keeps the image in its own runtime but Python still owns its wrapper.
        Holding PhotoImage on self._preview prevents garbage collection from
        turning a perfectly valid thumbnail into an unexpectedly blank widget.
        """
        self._preview = None
        try:
            if self.image_path:
                image = Image.open(self.image_path)
            elif self.image_data:
                image = Image.open(io.BytesIO(base64.b64decode(self.image_data.split(',', 1)[1])))
            else:
                image = None
            if image:
                with image:
                    image.thumbnail((320, 60))
                    self._preview = ImageTk.PhotoImage(image.convert('RGBA'))
        except (OSError, ValueError, IndexError):
            pass
        if self._preview:
            self.image_widget.configure(image=self._preview, text='', height=60)
        else:
            text = 'Image attached · click to change' if self.image_path or self.image_data else 'No image attached\nPNG / JPG / GIF / WEBP / BMP'
            self.image_widget.configure(image='', text=text, height=2)
        self.choose_image_button.configure(text='Change image' if self.image_path or self.image_data else 'Choose image')
        self.remove_image_button.configure(state='normal' if self.image_path or self.image_data else 'disabled')
        self._queue_document_state()

    def choose_image(self) -> None:
        selected = filedialog.askopenfilename(parent=self, title='Choose an image',
                    filetypes=[('Images', '*.png *.jpg *.jpeg *.gif *.webp *.bmp'), ('All files', '*.*')])
        if selected:
            try:
                with Image.open(selected) as image:
                    image.verify()
            except (OSError, ValueError) as error:
                messagebox.showerror('Image could not be opened', str(error), parent=self)
                return
            self.image_path, self.image_data = selected, ''
            self.image_alt = Path(selected).stem
            self._show_image()

    def remove_image(self) -> None:
        self.image_path = self.image_data = self.image_alt = ''
        self._show_image()

    def _metadata(self) -> None:
        self.doc.page.title = self.page_title.get().strip() or 'Untitled thread'
        self.doc.page.terminal_banner = self.banner.get()

    def _refresh_list(self) -> None:
        self.posts.delete(0, 'end')
        for index, section in enumerate(self.doc.page.sections):
            indent = '  ↳ ' if section.parent_id else ''
            self.posts.insert('end', f'{indent}{index + 1:02d}  {section.heading or "Untitled post"}')
            if section.post_id == self.selected_id:
                self.posts.selection_set(index)
        count = len(self.doc.page.sections)
        self.empty_hint.place_forget() if count else self.empty_hint.place(x=14, y=12)
        self.counter.set(f'{count} POST' + ('' if count == 1 else 'S'))
        self.file_label.set(self.doc.path.name if self.doc.path else 'NOT SAVED YET')
        self._queue_document_state()

    def _commit(self) -> bool:
        """Apply a meaningful draft, preserving unrelated changes and failed drafts.

        True includes the no-change/no-content case so navigation can continue.
        A new page without a chosen path is committed to memory only; after the
        first Save, commits also persist. False means a conflict choice stopped
        navigation. File errors propagate so the UI can keep the editor intact.
        """
        if not self._dirty() or not self._has_content():
            return True
        # A browser can add a reply while this window stays open. Refresh the
        # document before appending; reject a same-post conflict explicitly.
        old_metadata = self.page_title.get(), self.banner.get()
        # Refresh the document without replacing unsaved page-title/header
        # fields. They are widget state and may intentionally differ from disk.
        self.doc.refresh()
        self.page_title.set(old_metadata[0])
        self.banner.set(old_metadata[1])
        current = next((item for item in self.doc.page.sections if item.post_id == self.selected_id), None)
        # Compare only the edited post, not the whole file. A new reply elsewhere
        # should not trigger a same-post conflict or block this user's draft.
        if self.selected_id and (current is None or json.dumps(asdict(current), sort_keys=True) != self._post_baseline):
            if not messagebox.askyesno('This post changed', 'This post was changed outside the app. Keep your draft as a separate new post?', parent=self):
                return False
            current = None
            self.selected_id = ''
        section = replace(current) if current else Section('Post', post_id='p' + uuid.uuid4().hex[:12], parent_id=self.parent_id)
        # replace() copies scalar dataclass fields before mutation. Existing IDs
        # stay stable so replies remain attached; new posts get a fresh identity.
        section.heading = self.post_title.get().strip()
        section.body = self.body_text.get('1.0', 'end-1c')
        section.image_path, section.image_data_url, section.image_alt = self.image_path, self.image_data, self.image_alt
        previous_page, previous_id = copy.deepcopy(self.doc.page), self.selected_id
        # Rendering embeds images and mutates their cached data URLs, so a shallow
        # copy of the sections list would not be enough for rollback on failure.
        try:
            if current:
                self.doc.page.sections[self.doc.page.sections.index(current)] = section
            else:
                self.doc.page.sections.append(section)
            self.selected_id = section.post_id
            self._metadata()
            if self.doc.path:
                self.doc.save()
                section = next(item for item in self.doc.page.sections if item.post_id == self.selected_id)
                self.image_path, self.image_data = section.image_path, section.image_data_url
        except (OSError, ValueError):
            # Restore the MODEL only. Leaving the widgets untouched keeps every
            # character of the unsaved draft available for a retry or copying.
            self.doc.page, self.selected_id = previous_page, previous_id
            raise
        self._post_baseline = json.dumps(asdict(section), sort_keys=True)
        self._draft_baseline = self._signature()
        self.posts.selection_clear(0, 'end')
        for index, item in enumerate(self.doc.page.sections):
            if item.post_id == section.post_id:
                self.posts.selection_set(index)
                self.posts.see(index)
        self._refresh_list()
        return True

    def add_post(self) -> None:
        try:
            if not self._has_content():
                self.status.set('Choose an image or write something first.')
                self.body_text.focus_set()
                return
            if self._commit():
                self._reset_editor()
                self.status.set('Post saved. Ready for the next one.' if self.doc.path else 'Post added. Save the page whenever you are ready.')
                if self.doc.path:
                    self._saved_feedback()
        except (OSError, ValueError) as error:
            messagebox.showerror('Could not save post', str(error), parent=self)

    def new_post(self) -> None:
        try:
            if self._commit():
                self._reset_editor()
                self.body_text.focus_set()
        except (OSError, ValueError) as error:
            messagebox.showerror('Could not keep draft', str(error), parent=self)

    def _load_editor(self, section: Section) -> None:
        self.selected_id, self.parent_id = section.post_id, section.parent_id
        self.post_title.set(section.heading)
        self.body_text.delete('1.0', 'end')
        self.body_text.insert('1.0', section.body)
        self.image_path, self.image_data, self.image_alt = section.image_path, section.image_data_url, section.image_alt
        self._show_image()
        self.editor_label.set('[ EDIT REPLY ]' if section.parent_id else '[ EDIT POST ]')
        self.commit_button.configure(text='Save changes  →')
        self.delete_button.configure(state='normal')
        self.reply_button.configure(state='normal')
        self._post_baseline = json.dumps(asdict(section), sort_keys=True)
        self._draft_baseline = self._signature()
        self.posts.selection_clear(0, 'end')
        for index, item in enumerate(self.doc.page.sections):
            if item.post_id == section.post_id:
                self.posts.selection_set(index)
                self.posts.see(index)

    def select_post(self, event=None) -> None:
        selected = self.posts.curselection()
        if not selected:
            return
        target_id = self.doc.page.sections[selected[0]].post_id
        # Keep the identity before committing: refresh/commit can rebuild the
        # list and shift row numbers when another tab adds a comment.
        if target_id == self.selected_id:
            return
        try:
            if not self._commit():
                return
            target = next((item for item in self.doc.page.sections if item.post_id == target_id), None)
            if target:
                self._load_editor(target)
        except (OSError, ValueError) as error:
            messagebox.showerror('Could not switch post', str(error), parent=self)

    def reply_to_selected(self) -> None:
        target = self.selected_id
        if not target:
            self.status.set('Select a post in the thread first.')
            return
        try:
            if self._commit():
                self._reset_editor()
                # A reply starts a new object: selected_id remains empty while
                # parent_id is restored after resetting the editor fields.
                self.parent_id = target
                self.editor_label.set('[ NEW REPLY ]')
                self.body_text.focus_set()
        except (OSError, ValueError) as error:
            messagebox.showerror('Could not start reply', str(error), parent=self)

    def clear_draft(self) -> None:
        if self._dirty() and not messagebox.askyesno('Clear draft?', 'Discard the text and image changes in this draft?', parent=self):
            return
        target = next((item for item in self.doc.page.sections if item.post_id == self.selected_id), None)
        if target:
            self._load_editor(target)
        else:
            self._reset_editor()

    def delete_post(self) -> None:
        if self.selected_id and messagebox.askyesno('Delete post?', 'Delete this post and its replies?', parent=self):
            previous_page = None
            try:
                self.doc.refresh()
                previous_page = copy.deepcopy(self.doc.page)
                self.doc.delete(self.selected_id)
                self._metadata()
                if self.doc.path:
                    self.doc.save()
                self._reset_editor()
                self._refresh_list()
                self.status.set('Post deleted.')
            except (OSError, ValueError) as error:
                # Keep the visible model consistent with the unchanged file
                # if persisting a deletion fails. The selection/draft survive.
                if previous_page is not None:
                    self.doc.page = previous_page
                messagebox.showerror('Could not delete post', str(error), parent=self)

    def save_page(self) -> bool:
        """Save the draft and page together; ask for a path only on the first save."""
        try:
            if not self._commit():
                return False
            self.doc.refresh()
            self._metadata()
            destination = self.doc.path
            if destination is None:
                selection = filedialog.asksaveasfilename(parent=self, title='Save your webpage', initialfile='index.html',
                            defaultextension='.html', filetypes=[('Webpage', '*.html')])
                if not selection:
                    return False
                destination = Path(selection)
            self.doc.save(destination)
            self._refresh_list()
            if self.selected_id:
                item = next((item for item in self.doc.page.sections if item.post_id == self.selected_id), None)
                if item:
                    self._load_editor(item)
            self.status.set('Saved · ' + destination.name)
            self._saved_feedback()
            return True
        except (OSError, ValueError) as error:
            messagebox.showerror('Could not save webpage', str(error), parent=self)
            return False

    def _leave_document(self, *, quitting: bool = False) -> bool:
        """Distinguish Save, Discard, and Cancel before replacing the document.

        askyesnocancel returns True, False, or None. Do not reduce that to a
        plain truthiness check: False permits discarding, None must stop leaving.
        """
        unsaved = self._dirty() or (self.doc.page.sections and not self.doc.path) or self.page_title.get() != self.doc.page.title or self.banner.get() != self.doc.page.terminal_banner
        if not unsaved and not quitting:
            return True
        if quitting:
            # Esc always asks, even for an already-saved page. Cancel is the
            # default so another Esc dismisses the dialog and keeps editing.
            answer = messagebox.askyesnocancel(
                'Quit dλsociate?',
                'Save your page before quitting?\n\n'
                'Yes: Save and quit\nNo: Quit without saving\nCancel: Keep editing',
                parent=self, default=messagebox.CANCEL,
            )
        else:
            answer = messagebox.askyesnocancel('Keep your changes?', 'Save this page before continuing?', parent=self)
        return self.save_page() if answer else answer is False

    def new_page(self) -> None:
        if self._leave_document():
            self.doc = ThreadDocument()
            self.page_title.set('')
            self.banner.set('')
            self._reset_editor()
            self._refresh_list()
            self.status.set('New page. Choose an image and write your first post.')

    def open_page(self, path: Path | None = None) -> None:
        if not self._leave_document():
            return
        if path is None:
            selection = filedialog.askopenfilename(parent=self, title='Open a webpage thread', filetypes=[('Webpage', '*.html *.htm')])
            if not selection:
                return
            path = Path(selection)
        try:
            document = ThreadDocument()
            document.open(path)
            self.doc = document
            self.page_title.set(document.page.title)
            self.banner.set(document.page.terminal_banner)
            self._reset_editor()
            self._refresh_list()
            if document.page.sections:
                self._load_editor(document.page.sections[0])
                self._refresh_list()
            self.status.set('Opened · ' + path.name)
            self._open_browser_page()
        except (OSError, ValueError, TypeError) as error:
            messagebox.showerror('Could not open webpage', str(error), parent=self)

    def preview_page(self) -> None:
        if self.save_page():
            self._open_browser_page()

    def _open_browser_page(self) -> None:
        # The local preview registers this exact file. Opening file:// instead
        # would put saving back under browser file-picker permissions. The
        # temporary HTTP address must never be offered as a shareable web link.
        from browser_preview import BrowserPreview
        if self._preview_server is None:
            self._preview_server = BrowserPreview()
        webbrowser.open(self._preview_server.open_page(self.doc.path))

    def destroy(self) -> None:
        self._closing = True
        if self._share_dialog is not None:
            self._share_dialog.destroy()
        for job in (self._state_job, self._feedback_job):
            if job is not None:
                self.after_cancel(job)
        if self._preview_server is not None:
            self._preview_server.close()
            self._preview_server = None
        super().destroy()

    def _focus_refresh(self, event=None) -> None:
        """Notice saved browser replies when focus returns, without losing a draft."""
        if event and event.widget is not self:
            return
        try:
            if self.doc.refresh():
                self._refresh_list()
                if not self._dirty():
                    item = next((item for item in self.doc.page.sections if item.post_id == self.selected_id), None)
                    if item:
                        self._load_editor(item)
                self.status.set('Updated with changes saved in the browser.')
        except (OSError, ValueError):
            self.status.set('The file is being updated. Try again in a moment.')

    def share_page(self) -> None:
        """Save first, then share real files without entering Windows Share."""
        if self._share_dialog is not None and self._share_dialog.winfo_exists():
            self._share_dialog.destroy()
        if not self.save_page():
            return
        # Capture this document now. Background completion must never attach a
        # different file if the main editor subsequently opens another thread.
        share_path, share_title = self.doc.path.resolve(), self.doc.page.title
        dialog = tk.Toplevel(self)
        self._share_dialog = dialog
        dialog.title('Share · dλsociate')
        dialog.configure(bg=BLACK)
        dialog.geometry('660x610')
        dialog.resizable(False, False)
        dialog.transient(self)
        dialog.grab_set()
        tk.Label(dialog, text='SHARE YOUR THREAD', bg=BLACK, fg=AMBER,
                 font=(FONT, 19, 'bold')).pack(anchor='w', padx=26, pady=(26, 10))
        tk.Label(dialog, text='Send the file. Everything is inside.', bg=BLACK, fg=GREEN,
                 font=(FONT, 12)).pack(anchor='w', padx=26, pady=(0, 16))
        tk.Label(dialog, text=share_path.name, bg=PANEL, fg=GREEN,
                 font=(FONT, 12), padx=14, pady=12).pack(fill='x', padx=26)
        share_status = tk.StringVar(value='Email creates a message with your HTML already attached. Or copy the HTML file into your messaging app.')
        state = {'job': None, 'task': None, 'email_path': None}

        def finish():
            if state['job'] is not None:
                dialog.after_cancel(state['job'])
                state['job'] = None
            email_button.configure(text='Email · HTML attached', state='normal')
            cancel_button.configure(state='disabled')

        def cancel():
            if state['task'] is not None:
                state['task'].cancel()
                state['task'] = None
            finish()
            share_status.set('Stopped waiting. Copy file and Show file are ready. Any completed email file stays beside your HTML.')

        def poll():
            state['job'] = None
            task = state['task']
            if task is None:
                return
            try:
                result = task.poll()
                if result is None:
                    share_status.set(task.progress)
                    state['job'] = dialog.after(40, poll)
                    return
                state['task'] = None
                finish()
                email_path, error = result
                state['email_path'] = email_path
                show_email_button.configure(state='normal')
                if error:
                    share_status.set('Email file saved with HTML attached. No email app opened; use Show email file, then Open with your mail app.')
                else:
                    share_status.set(f'Email file ready with HTML attached · {task.email_bytes / 1_000_000:.2f} MB. Large images may be optimized in this copy; your saved thread is unchanged. Choose a recipient and send; use Forward or Edit as new if needed.')
            except Exception as error:
                task.cancel()
                state['task'] = None
                finish()
                share_status.set(str(error) + ' Use Copy file or Show file.')

        def email():
            if state['task'] is not None:
                return
            from email_draft import EmailDraftTask
            # ShellExecute itself can stall in an external application. Keep
            # that call in the worker too; Tk only polls a Python queue.
            state['task'] = EmailDraftTask(share_path, share_title, opener=os.startfile)
            email_button.configure(text='Preparing email…', state='disabled')
            cancel_button.configure(state='normal')
            share_status.set('Preparing an email file with your HTML attached…')
            state['job'] = dialog.after(40, poll)

        def copy_file():
            try:
                from windows_share import copy_file_to_clipboard
                copy_file_to_clipboard(share_path, self.winfo_id())
                share_status.set('HTML file copied. Paste it into an app that accepts file attachments.')
            except OSError as error:
                share_status.set(str(error))

        row = tk.Frame(dialog, bg=BLACK)
        row.pack(fill='x', padx=26, pady=(18, 10))
        email_button = self.button(row, 'Email · HTML attached', email, primary=True)
        email_button.pack(side='left', fill='x', expand=True, padx=(0, 8))
        cancel_button = self.button(row, 'Cancel', cancel, subtle=True)
        cancel_button.configure(state='disabled')
        cancel_button.pack(side='right')
        files = tk.Frame(dialog, bg=BLACK)
        files.pack(fill='x', padx=26)
        copy_button = self.button(files, 'Copy file', copy_file)
        copy_button.pack(side='left', fill='x', expand=True, padx=(0, 6))
        self.button(files, 'Show file', lambda: subprocess.Popen(['explorer.exe', '/select,', str(share_path)])).pack(side='left', fill='x', expand=True, padx=(6, 0))
        show_email_button = self.button(dialog, 'Show email file', lambda: subprocess.Popen(['explorer.exe', '/select,', str(state['email_path'])]), subtle=True)
        show_email_button.configure(state='disabled')
        show_email_button.pack(fill='x', padx=26, pady=(10, 0))
        tk.Label(dialog, text='WEB MESSAGING', bg=BLACK, fg=MUTED, font=(FONT, 10)).pack(anchor='w', padx=26, pady=(18, 8))
        messaging = tk.Frame(dialog, bg=BLACK)
        messaging.pack(fill='x', padx=26)
        for name, url in [('WhatsApp', 'https://web.whatsapp.com/'), ('Messenger', 'https://www.messenger.com/')]:
            self.button(messaging, name, lambda target=url: webbrowser.open(target), subtle=True).pack(side='left', fill='x', expand=True, padx=3)
        tk.Label(dialog, textvariable=share_status, wraplength=595, justify='left',
                 bg=BLACK, fg=GREEN, font=(FONT, 10)).pack(anchor='w', padx=26, pady=(16, 6))
        tk.Label(dialog, text='WhatsApp / Messenger: paste the file or use their Attach control.\nEmail creates an extra .eml file beside your HTML; delete it when done.',
                 bg=BLACK, fg=MUTED, font=(FONT, 9), justify='left').pack(anchor='w', padx=26)

        def cleanup(event):
            if event.widget is not dialog:
                return
            if state['job'] is not None:
                dialog.after_cancel(state['job'])
                state['job'] = None
            if state['task'] is not None:
                state['task'].cancel()
                state['task'] = None
            if self._share_dialog is dialog:
                self._share_dialog = None
        dialog.bind('<Destroy>', cleanup, add='+')
        dialog.bind('<Escape>', lambda event: (dialog.destroy(), 'break')[1])
        dialog.email_button = email_button
        dialog.cancel_email_button = cancel_button
        dialog.show_email_button = show_email_button
        dialog.copy_file_button = copy_button
        dialog.share_status = share_status

    def show_terms(self) -> None:
        """Reopen the startup agreements from the editor."""
        if review_terms(self):
            self.status.set('Karmic Law agreed.')

    def show_help(self) -> None:
        """Open the packaged guide locally; Word or internet access is not required.

        The guide includes a link to its DOCX companion for readers who prefer
        Word. Resource lookup supports the installed package AND an EXE copied
        by itself; do not construct this path relative to the current directory.
        """
        try:
            webbrowser.open(help_manual_path().as_uri())
            self.status.set('Opened the offline instruction manual.')
        except OSError as error:
            messagebox.showerror('Help could not be opened', str(error), parent=self)

    def close(self, event=None) -> str:
        """Confirm quitting; a canceled/failed save must leave the app open.

        The flag prevents repeated Esc/close events from stacking prompts while
        Tk runs the dialog's nested event loop. New/Open retain their existing
        unsaved-change prompt rather than acquiring this always-ask quit flow.
        """
        if self._quit_prompt_open:
            return 'break'
        self._quit_prompt_open = True
        try:
            if self._leave_document(quitting=True):
                self.destroy()
        finally:
            self._quit_prompt_open = False
        return 'break'


def main() -> int:
    parser = argparse.ArgumentParser(prog='dysociate')
    parser.add_argument('page', nargs='?', type=Path)
    parser.add_argument('--self-test', action='store_true')
    args = parser.parse_args()
    if args.self_test:
        self_test()
        # Run in source AND the packaged executable: a successful code build
        # alone would miss an omitted manual/add-data packaging regression.
        guide = help_manual_path()
        assert 'dλsociate User Manual' in guide.read_text(encoding='utf-8')
        assert guide.with_suffix('.docx').is_file()
        return 0
    if sys.platform == 'win32':
        ctypes.windll.shell32.SetCurrentProcessExplicitAppUserModelID('LunaSoft.dysociate')
    # The agreement window owns its own event loop. Only create the editor
    # after both agreements, including when a thread was passed on the command line.
    if review_terms():
        DysociateApp(args.page).mainloop()
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
