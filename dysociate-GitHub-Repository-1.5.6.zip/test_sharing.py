"""Real email attachments and a responsive, native-sheet-free sharing dialog.

Copyright (c) 2026 Luna Love ~ LunaSoft
SPDX-License-Identifier: GPL-3.0-or-later. See LICENSE.
"""
from email import policy
from email.parser import BytesParser
from pathlib import Path
import tempfile
import threading
import time
import unittest
from unittest.mock import patch

from email_draft import create_email_file, EmailDraftTask
from email_size import MAX_EMAIL_BYTES, EmailTooLargeError


class EmailTests(unittest.TestCase):
    def test_animated_picture_is_never_flattened_to_fit_an_email(self):
        import base64
        import io
        from PIL import Image
        from pagebuilder_gui import Page, Section
        from email_size import smaller_email_page
        images = [Image.effect_noise((400, 400), 90).convert('P') for _ in range(2)]
        output = io.BytesIO()
        images[0].save(output, 'GIF', save_all=True, append_images=images[1:], duration=100, loop=0)
        self.assertGreater(len(output.getvalue()), 30_000)
        original = 'data:image/gif;base64,' + base64.b64encode(output.getvalue()).decode('ascii')
        page = Page(sections=[Section('Post', post_id='p1', image_data_url=original)])
        smaller = smaller_email_page(page, 100, 50)
        self.assertEqual(smaller.sections[0].image_data_url, original)
        self.assertEqual(page.sections[0].image_data_url, original)

    def test_large_existing_png_thread_gets_smaller_email_without_changing_original(self):
        from pagebuilder_gui import Page, Section, render_html, load_page
        import base64
        import io
        from PIL import Image
        with tempfile.TemporaryDirectory(dir=Path.cwd()) as folder:
            source = Path(folder) / 'index.html'
            asset = Path(__file__).resolve().parent / 'assets/dysociate.png'
            render_html(Page(title='Size regression', sections=[Section('Post', body='Keep these words λ',
                        post_id='root', image_path=str(asset)), Section('Post', body='Keep the reply', post_id='reply', parent_id='root')]), str(source))
            before = source.read_bytes()
            draft = create_email_file(source, 'Size regression')
            self.assertLessEqual(draft.stat().st_size, MAX_EMAIL_BYTES)
            message = BytesParser(policy=policy.default).parsebytes(draft.read_bytes())
            compact = Path(folder) / 'received.html'
            compact.write_bytes(list(message.iter_attachments())[0].get_payload(decode=True))
            page = load_page(str(compact))
            self.assertEqual([p.body for p in page.sections], ['Keep these words λ', 'Keep the reply'])
            self.assertEqual(page.sections[1].parent_id, 'root')
            data = base64.b64decode(page.sections[0].image_data_url.split(',', 1)[1])
            with Image.open(io.BytesIO(data)) as photo:
                self.assertLessEqual(max(photo.size), 1600)
            self.assertEqual(source.read_bytes(), before)

    def test_over_budget_text_is_rejected_before_a_file_or_mail_app_is_created(self):
        from pagebuilder_gui import Page, render_html
        with tempfile.TemporaryDirectory(dir=Path.cwd()) as folder:
            source = Path(folder) / 'index.html'
            render_html(Page(), str(source))
            original = source.read_bytes()
            with self.assertRaises(EmailTooLargeError):
                create_email_file(source, 'Too big', max_email_bytes=1000)
            self.assertEqual(list(Path(folder).glob('*.eml')), [])
            self.assertEqual(source.read_bytes(), original)

    def test_canceled_optimization_never_creates_a_message(self):
        from pagebuilder_gui import Page, render_html
        with tempfile.TemporaryDirectory(dir=Path.cwd()) as folder:
            source = Path(folder) / 'index.html'
            render_html(Page(), str(source))
            canceled = threading.Event()
            canceled.set()
            with self.assertRaises(InterruptedError):
                create_email_file(source, 'Canceled', cancelled=canceled)
            self.assertEqual(list(Path(folder).glob('*.eml')), [])

    def test_desktop_email_includes_configured_phone_editor_link(self):
        from pagebuilder_gui import Page, render_html
        with tempfile.TemporaryDirectory(dir=Path.cwd()) as folder:
            source = Path(folder) / 'index.html'
            render_html(Page(browser_editor_url='https://threads.example/editor.html'), str(source))
            draft = create_email_file(source, 'Phone thread')
            message = BytesParser(policy=policy.default).parsebytes(draft.read_bytes())
            self.assertIn('https://threads.example/editor.html', message.get_body(preferencelist=('plain',)).get_content())
            self.assertEqual(list(message.iter_attachments())[0].get_payload(decode=True), source.read_bytes())

    def test_mime_attachment_is_exact_unicode_html_and_unique_draft(self):
        with tempfile.TemporaryDirectory(dir=Path.cwd()) as folder:
            source = Path(folder) / 'my thread λ.html'
            payload = '<html>λ 💜 <script>test</script></html>\r\n'.encode('utf-8')
            source.write_bytes(payload)
            first = create_email_file(source, 'Thread λ\r\nBcc: nobody')
            second = create_email_file(source, 'Thread')
            self.assertNotEqual(first, second)
            message = BytesParser(policy=policy.default).parsebytes(first.read_bytes())
            attachments = list(message.iter_attachments())
            self.assertEqual(len(attachments), 1)
            self.assertEqual(attachments[0].get_payload(decode=True), payload)
            self.assertEqual(attachments[0].get_filename(), source.name)
            self.assertEqual(attachments[0].get_content_type(), 'text/html')
            self.assertEqual(message['X-Unsent'], '1')
            self.assertIsNone(message['Bcc'])
            self.assertEqual(source.read_bytes(), payload)
            self.assertFalse(message.defects)

    def test_pending_os_call_does_not_block_poll_or_timeout(self):
        gate, entered = threading.Event(), threading.Event()
        def opener(path):
            entered.set()
            gate.wait(3)
        clock = [0.]
        task = EmailDraftTask(Path('dummy'), 't', writer=lambda *a: Path('draft.eml'),
                              opener=opener, timeout=1, clock=lambda: clock[0])
        try:
            self.assertTrue(entered.wait(1))
            started = time.monotonic()
            self.assertIsNone(task.poll())
            clock[0] = 2
            with self.assertRaises(TimeoutError):
                task.poll()
            self.assertLess(time.monotonic() - started, .2)
        finally:
            gate.set()

    def test_cancel_ignores_late_result_and_prevents_mail_launch(self):
        gate, entered = threading.Event(), threading.Event()
        opened = []
        def writer(*args):
            entered.set()
            gate.wait(3)
            return Path('old.eml')
        task = EmailDraftTask(Path('dummy'), 't', writer=writer, opener=opened.append)
        self.assertTrue(entered.wait(1))
        task.cancel()
        gate.set()
        time.sleep(.05)
        self.assertIsNone(task.poll())
        self.assertEqual(opened, [])

    def test_missing_association_preserves_created_attachment(self):
        def opener(path):
            raise OSError('No association')
        task = EmailDraftTask(Path('dummy'), 't', writer=lambda *a: Path('ready.eml'), opener=opener)
        until = time.monotonic() + 1
        result = None
        while result is None and time.monotonic() < until:
            result = task.poll()
            time.sleep(.005)
        self.assertEqual(result[0], Path('ready.eml'))
        self.assertIsInstance(result[1], OSError)


class ShareDialogTests(unittest.TestCase):
    def setUp(self):
        from dysociate_gui import DysociateApp
        from pagebuilder_gui import Page, Section, render_html
        self.folder = tempfile.TemporaryDirectory(dir=Path.cwd())
        self.path = Path(self.folder.name) / 'index.html'
        render_html(Page(title='Thread A', sections=[Section('Post', body='Saved', post_id='p1')]), str(self.path))
        self.app = DysociateApp()
        self.app.withdraw()
        self.app.doc.open(self.path)
        self.app.page_title.set('Thread A')
        with patch.object(self.app, 'save_page', return_value=True):
            self.app.share_page()
        self.dialog = self.app._share_dialog

    def tearDown(self):
        self.app.update_idletasks()
        self.app.destroy()
        self.folder.cleanup()

    def pump(self, seconds=.18):
        until = time.monotonic() + seconds
        while time.monotonic() < until:
            self.app.update()
            time.sleep(.01)

    def test_email_attaches_captured_document_without_native_share(self):
        self.assertFalse(hasattr(self.dialog, 'native_share_button'))
        self.app.doc.path = self.path.with_name('other.html')
        with patch('dysociate_gui.os.startfile') as opened:
            self.dialog.email_button.invoke()
            self.pump(.35)
            opened.assert_called_once()
            message = BytesParser(policy=policy.default).parsebytes(Path(opened.call_args.args[0]).read_bytes())
            self.assertEqual(list(message.iter_attachments())[0].get_payload(decode=True), self.path.read_bytes())
            self.assertIn('HTML attached', self.dialog.share_status.get())

    def test_stalled_email_launch_keeps_tk_responsive_and_cancellable(self):
        gate, entered = threading.Event(), threading.Event()
        def stalled(path):
            entered.set()
            gate.wait(3)
        try:
            with patch('dysociate_gui.os.startfile', side_effect=stalled):
                self.dialog.email_button.invoke()
                self.assertTrue(entered.wait(1))
                beats = []
                self.app.after(10, lambda: beats.append(True))
                self.pump()
                self.assertTrue(beats)
                self.dialog.cancel_email_button.invoke()
                self.assertFalse(self.dialog.email_button.instate(('disabled',)))
                self.assertIn('Stopped waiting', self.dialog.share_status.get())
        finally:
            gate.set()

    def test_association_failure_offers_existing_email_file(self):
        with patch('dysociate_gui.os.startfile', side_effect=OSError('No association')):
            self.dialog.email_button.invoke()
            self.pump(.35)
        self.assertFalse(self.dialog.show_email_button.instate(('disabled',)))
        self.assertIn('No email app opened', self.dialog.share_status.get())

    def test_copy_file_stays_bound_to_original_document(self):
        self.app.doc.path = self.path.with_name('other.html')
        with patch('windows_share.copy_file_to_clipboard') as copied:
            self.dialog.copy_file_button.invoke()
        self.assertEqual(copied.call_args.args[0], self.path.resolve())

    def test_closing_dialog_does_not_launch_late_email(self):
        from email_draft import EmailDraftTask
        gate, entered = threading.Event(), threading.Event()
        opened = []
        def writer(*args):
            entered.set()
            gate.wait(3)
            return Path('unused.eml')
        def factory(*args, **kwargs):
            return EmailDraftTask(*args, writer=writer, opener=opened.append)
        try:
            with patch('email_draft.EmailDraftTask', side_effect=factory):
                self.dialog.email_button.invoke()
                self.assertTrue(entered.wait(1))
                self.dialog.destroy()
                gate.set()
                self.pump()
            self.assertTrue(self.app.winfo_exists())
            self.assertIsNone(self.app._share_dialog)
            self.assertEqual(opened, [])
        finally:
            gate.set()


if __name__ == '__main__':
    unittest.main()
