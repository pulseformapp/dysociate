"""Master a dysociate release directory into a verified, mountable data ISO.

Copyright (c) 2026 Luna Love ~ LunaSoft
SPDX-License-Identifier: GPL-3.0-or-later. See LICENSE.

ISO 9660 provides the disc structure; Joliet and Rock Ridge preserve the real
file names for Windows and other readers. This is application distribution
media, not a bootable operating-system image. Every file is read back from
the completed ISO and checked against its original SHA-256 digest.
"""

from __future__ import annotations

import argparse
import hashlib
import io
from pathlib import Path

import pycdlib


def digest(path: Path) -> str:
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def build_iso(source: Path, output: Path) -> None:
    source = source.resolve()
    output = output.resolve()
    if output == source or source in output.parents:
        raise ValueError('The ISO destination must be outside the source directory.')
    files = sorted(path for path in source.rglob('*') if path.is_file())
    if not files:
        raise ValueError('The release directory is empty.')

    manifest = source / 'SHA256SUMS.txt'
    # A manifest cannot include its own digest without an impossible recursive
    # dependency. Exclude it while writing entries, then include its completed
    # bytes in ISO readback verification alongside every other file.
    entries = [f'{digest(path)}  {path.relative_to(source).as_posix()}'
               for path in files if path != manifest]
    manifest.write_text('\n'.join(entries) + '\n', encoding='utf-8', newline='\n')
    files = sorted(path for path in source.rglob('*') if path.is_file())
    expected = {path.relative_to(source).as_posix(): digest(path) for path in files}

    iso = pycdlib.PyCdlib()
    iso.new(interchange_level=3, joliet=3, rock_ridge='1.09',
            vol_ident='DYSOCIATE', app_ident_str='dysociate 1.5.6 - LunaSoft')
    directories = {Path('.'): ''}
    folders = sorted((path for path in source.rglob('*') if path.is_dir()),
                     key=lambda path: (len(path.relative_to(source).parts), str(path)))
    for number, folder in enumerate(folders, start=1):
        relative = folder.relative_to(source)
        # Internal aliases cannot collide; readable names live in Joliet and
        # Rock Ridge, the namespaces used by modern operating systems.
        iso_path = directories[relative.parent] + f'/D{number:06d}'
        directories[relative] = iso_path
        iso.add_directory(iso_path=iso_path, rr_name=folder.name,
                          joliet_path='/' + relative.as_posix())
    for number, path in enumerate(files, start=1):
        relative = path.relative_to(source)
        iso.add_file(str(path),
                     iso_path=directories[relative.parent] + f'/F{number:06d};1',
                     rr_name=path.name, joliet_path='/' + relative.as_posix())
    output.parent.mkdir(parents=True, exist_ok=True)
    iso.write(str(output))
    iso.close()

    check = pycdlib.PyCdlib()
    # Successful mastering is not proof that names and bytes survived. Reopen
    # the finished image via its Windows-readable Joliet namespace and hash the
    # extracted payload of every staged file, not only the EXE or installer.
    check.open(str(output))
    try:
        for name, expected_digest in expected.items():
            payload = io.BytesIO()
            check.get_file_from_iso_fp(payload, joliet_path='/' + name)
            if hashlib.sha256(payload.getvalue()).hexdigest() != expected_digest:
                raise RuntimeError(f'ISO verification failed: {name}')
    finally:
        check.close()
    checksum = output.with_suffix(output.suffix + '.sha256')
    checksum.write_text(f'{digest(output)}  {output.name}\n', encoding='ascii')
    print(f'PASS: verified all {len(files)} files in {output}')
    print(f'Size: {output.stat().st_size:,} bytes; volume: DYSOCIATE')


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('source', type=Path)
    parser.add_argument('output', type=Path)
    args = parser.parse_args()
    build_iso(args.source, args.output)


if __name__ == '__main__':
    main()
