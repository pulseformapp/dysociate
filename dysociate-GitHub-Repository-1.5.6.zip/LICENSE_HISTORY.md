# License history

Copyright (c) 2026 Luna Love ~ LunaSoft

dλsociate 1.4.0 is licensed under GNU GPL version 3 or, at your option, any later
version (SPDX: GPL-3.0-or-later). The complete terms are in LICENSE. Covered
distributed modifications must preserve GPL freedoms and supply corresponding
source to recipients as required by those terms. The product source, assets,
documentation, and build scripts accompany the binary distribution.

Versions through 1.3.2 were distributed under MIT. Their original permissions
and notices remain in force for those releases; earlier frozen archives are
preserved. Changing the license of this new release does not revoke an earlier
recipient's MIT grant for an earlier copy.

Bundled upstream components keep their own licenses and copyright notices.
This project does not relicense Python, Tcl/Tk, Pillow, PyWinRT, PyInstaller's
bootloader, or the installer runtime as exclusively LunaSoft work.
