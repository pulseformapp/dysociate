# dλsociate

Copyright (c) 2026 Luna Love ~ LunaSoft
SPDX-License-Identifier: GPL-3.0-or-later. See LICENSE.

## Download dλsociate 1.5.6

dλsociate is an offline thread editor. Write a post, add a picture, and save a
thread as one HTML file you can share.

- **Windows 10 or 11, 64-bit.** Open this repository's **Releases** and download
  `dysociate-1.5.6-setup.exe`. Run setup and open **dλsociate** from the Start menu.
- **Portable Windows app.** Extract `dysociate-1.5.6-portable-windows-x64.zip` and open
  `dysociate/dysociate.exe`.
- **Browser edition.** Extract `dysociate-1.5.6-browser.zip` and open `Browser/index.html` in a
  full browser. The same file can be hosted over HTTPS.

For help, use **Help** in the app or open the [user manual](docs/User_Manual.md).
For build instructions, see [Source and builds](#source-and-builds) and the
[developer guide](docs/DEVELOPER_GUIDE.md). See [LICENSE](LICENSE) for the
GPL-3.0-or-later terms.

Release 1.5.5 refreshes the desktop terminal theme with higher contrast and
larger header text. Karmic Law closes with “~ as above so below ~”.

Release 1.5.4 gives Karmic Law larger text and keeps the startup controls in
view while the agreement scrolls. I agree appears at the end of each screen.

Release 1.5.3 shows Luna Love's license agreement and Karmic Law before the
Windows executable opens the editor. Select I agree on both screens to start.
Decline and exit closes startup. The executable includes the full agreement
for portable use. The GNU GPL governs software rights.

Release 1.5.1 fixes Outlook's oversized-attachment rejection. Images are stored
once in HTML. Email automatically optimizes an oversized copy, measures the
complete MIME message and blocks export above an 8 MB preparation budget.
Working originals remain unchanged; provider limits can still be lower.

Release 1.5.0 puts the complete thread editor inside every generated HTML file.
The Windows desktop app remains available. Recipients can use the browser
edition without installing Python, the desktop app, or any npm package.

## Use a thread in the browser

1. Save the received HTML attachment and open it in a full browser.
2. Write text, choose an image if you want one, then tap **Post to thread**.
3. Tap **Reply** on a post to join its conversation. **Edit** changes your copy.
4. Tap **Save HTML** to keep the updated file, or **Share / Email** to send it.

Posting happens immediately in the tab. On phones, Save HTML normally downloads
a new copy; check Downloads or Save to Files. It does not silently replace the
original attachment. Supporting desktop browsers can write a selected file.
Canceled or failed writes keep the posted changes in the tab.

Save and Email include a meaningful unfinished standalone draft automatically.
Wait for an image to finish preparing. Save before closing/reloading: browser
storage is not a backup, and phones can unload tabs without warning.

The exported HTML contains its own editor, text, pictures, readable JavaScript
and GPL license. No desktop listener, remote database, CDN or external asset is
needed to continue that copy. Separate copies do not synchronize or merge.

## Phone attachment previews and a public browser link

Some mail/file apps display HTML in a preview that does not run its controls.
Use a full browser. If a phone cannot open the attachment as an interactive
page, open your hosted browser edition and tap **Open HTML** to choose it.

The release includes **Browser/index.html**, an empty edition of the same
editor, ready for an ordinary static HTTPS host such as GitHub Pages. Hosting
is not provisioned by the build; no public editor URL is configured by default.
A hosted editor reads the chosen HTML on the device without uploading it.

After hosting, set **Browser editor link** in **Thread details**. That optional
HTTPS address travels in the HTML and in email invitations. A hosted editor
also supplies its own origin/path automatically on export, without query/hash.
The desktop's private loopback address and file paths are never editor links.

A hosted thread opens its published copy. Posting locally does not update that
host or other people's copies. Send the newest saved HTML to pass replies on.
Browser/mail compatibility needs testing on the actual target phones; a desktop
phone-sized viewport is not evidence of every iPhone/Android attachment viewer.

## Email and messaging

**Share / Email** opens the options without creating an unwanted extra download.
**Email · HTML attached** downloads a .eml email message containing the actual
updated HTML attachment. Open it in a compatible mail app; if it opens read-only,
choose Forward or Edit as new, then select a recipient and send. Nothing sends
automatically. Email estimates/final size are shown, and preparation can be
canceled. Oversized copies use smaller images; originals and normal HTML saves
retain their image data. Animation is preserved. If an email still cannot fit,
use fewer/smaller pictures, split the thread or transfer HTML another way.
Providers can impose lower attachment format/size limits.

**Download HTML** creates the file to attach in WhatsApp, Messenger or another
destination using its Attach control. A C-drive path is not a public link.
The freezing native Windows share sheet is not used on any platform.

## Windows desktop app

Run dysociate.exe directly, or run dysociate-setup.exe for a per-user install
with Start menu and optional Desktop shortcuts. Python/WSL are not required by
the EXE. Windows 10/11 x64 is the desktop target. The ISO is mountable application
distribution media, not a bootable operating system.

Choose an image, write text, Add post, then Save and choose index.html once.
Later desktop additions/edits save to that file. Open or Preview opens the
browser UI; new posts in that connected tab still save automatically while the
app runs. **Continue in browser** keeps the draft and removes that dependency.
Browser edits to existing posts/details work on a portable copy, avoiding stale
whole-page writes through the desktop's append-only connection.

Alt+Enter toggles fullscreen/window mode. Esc and Quit ask whether to save and
quit, discard and quit, or stay. Help/F1 opens the offline manual, with a link
to its Word edition. Source documentation lives in docs; packaged documentation
is in Documentation. The original supplied artwork is the icon.

Desktop Share saves first. Email creates a real .eml beside the saved HTML,
then opens it in the default mail app. Show email file locates it if no app
opens. These extra files contain the thread; delete them when done. Cancel
stops waiting, but a completed email file may remain. Copy file puts the real
HTML on the Windows file clipboard; Show file selects it in Explorer.

Older HTML gains the new editor by opening it in the current browser edition
and using Save HTML, or by opening/saving it in the current desktop app.
The browser importer requires embedded thread metadata. Pre-metadata legacy
pages can first be upgraded by the desktop importer.

## Source and builds

The desktop source uses Python 3.11+, Tkinter, Pillow and PowerShell.
The optional old terminal reference also uses windows-curses.
Run from Source:

~~~powershell
& '.\run_dysociate.ps1'
& '.\run_dysociate.ps1' -SelfTest
~~~

The launcher creates a local virtual environment if needed. Build dependencies
are listed in requirements-build.txt. Documentation tooling is separate in
requirements-docs.txt; reviewed manuals are build inputs, not regenerated
silently during release packaging.

~~~powershell
& '.\.venv\Scripts\python.exe' build_browser.py '..\Browser'
& '.\build_distribution.ps1' -InnoCompiler 'C:\your-tools\Inno Setup\ISCC.exe' -ReleaseRoot '.\release'
~~~

build_distribution.ps1 produces the EXE, installer, Browser folder, full source,
manuals/notices, verified ISO and Store downloads. Store includes matching
source, Windows portable/installer files and a browser ZIP with corresponding
source. The supplied Windows binaries remain unsigned.

browser_runtime.js is the reviewed browser source. pagebuilder_gui.py embeds it
verbatim, with CSS and JSON data, into the single HTML. Changing the JS requires
rebuilding both Browser/index.html and the desktop package. See the developer
guide for state, escaping, imports, file ownership and concurrency details.

## Verification and freezing

~~~powershell
& '.\.venv\Scripts\python.exe' -m unittest discover -p 'test_*.py'
& '.\.venv\Scripts\python.exe' dysociate_gui.py --self-test
& '.\.venv\Scripts\python.exe' build_browser.py Browser
npm install
node test_browser.cjs Browser/index.html browser-check-output
~~~

npm/jsdom are development-only test dependencies. The tests replace OS pickers,
downloads and delivery boundaries; they never send mail. Real device/provider
acceptance is separate. Browser output preserves images and reopens in Python.

~~~powershell
& '.\.venv\Scripts\python.exe' freeze_release.py --release-root release --snapshot dysociate-Frozen-1.5.0 --archive dysociate-Frozen-1.5.0.zip
& '.\.venv\Scripts\python.exe' freeze_release.py --verify dysociate-Frozen-1.5.0 --archive dysociate-Frozen-1.5.0.zip
~~~

A freeze requires fresh destinations, rejects reparse points, compares content
hashes, reads back ZIP payloads and checks that release inputs did not change.
It includes program/source/docs/build material, not personal HTML threads.

## Content, privacy and licensing

Imports never execute a received file's scripts or read its claimed image_path.
The browser accepts embedded raster images, validates reply graphs and retains
the current thread if import fails. It accepts HTML up to 64 MB/10,000 posts and
selected images up to 20 MB. Large JPEGs are reduced for sharing. Other photo
formats need browser decoder support; choose JPG/PNG if conversion fails.

Threads are readable/editable files, not encrypted or identity-verified messages.
The app provides no accounts, analytics, background upload, automatic sync or
unsaved-draft recovery. The optional desktop preview binds only to 127.0.0.1.
A static host and external mail/messaging apps operate under their own settings.
See docs/PRIVACY.md.

Product source from 1.4.0 onward is GPL-3.0-or-later; distributed covered
derivatives must preserve GPL freedoms and corresponding source access.
Earlier frozen MIT releases retain their grants; see LICENSE_HISTORY.md.
Posts and photos remain the user's content. Runtime dependencies retain their
upstream terms; see THIRD_PARTY_NOTICES.md and Licenses.
