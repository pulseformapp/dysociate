"""Build Word, HTML, and Markdown manuals from one reviewed content file.

Copyright (c) 2026 Luna Love ~ LunaSoft
SPDX-License-Identifier: GPL-3.0-or-later. See LICENSE.

This is build tooling, not an application runtime dependency. Keeping the
content in JSON lets Help and the printable manual explain the same workflow.
The DOCX uses explicit topic page breaks; it must still be rendered and visually
checked after editing because Word/LibreOffice perform their own text layout.
"""

from __future__ import annotations

import html
import json
from pathlib import Path

from docx import Document
from docx.enum.table import WD_CELL_VERTICAL_ALIGNMENT
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Inches, Pt, RGBColor


def build_manual() -> None:
    folder = Path(__file__).resolve().parent / 'docs'
    data = json.loads((folder / 'manual_content.json').read_text(encoding='utf-8'))
    document = Document()
    # The starter template gives Title an accent-colored border. Remove
    # inherited paragraph rules so print output stays plain and black.
    for border in document.styles.element.xpath('.//w:pBdr'):
        border.getparent().remove(border)
    section = document.sections[0]
    section.page_width, section.page_height = Inches(8.5), Inches(11)
    section.top_margin = section.bottom_margin = Inches(.65)
    section.left_margin = section.right_margin = Inches(.75)
    normal = document.styles['Normal']
    normal.font.name, normal.font.size = 'Calibri', Pt(11)
    normal.font.color.rgb = RGBColor(0, 0, 0)
    normal.paragraph_format.space_after = Pt(6)
    normal.paragraph_format.line_spacing = 1.06
    for name, size in [('Title', 25), ('Heading 1', 19), ('Heading 2', 12)]:
        style = document.styles[name]
        style.font.name, style.font.size = 'Calibri', Pt(size)
        style.font.color.rgb = RGBColor(0, 0, 0)
        style.paragraph_format.keep_with_next = True
        style.paragraph_format.space_before = Pt(9 if name == 'Heading 2' else 0)
        style.paragraph_format.space_after = Pt(5)
    document.core_properties.title = data['title']
    document.core_properties.author = data['author']
    document.core_properties.subject = 'Instructions for creating saving and sharing offline webpage threads'

    # A page field is useful in a manual readers may print. No running header
    # or decorative title rule is needed; headings provide the navigation.
    footer = section.footer.paragraphs[0]
    footer.alignment = 2
    footer.add_run('dλsociate  ')
    field = OxmlElement('w:fldSimple')
    field.set(qn('w:instr'), 'PAGE')
    footer._p.append(field)
    for run in footer.runs:
        run.font.size = Pt(9)

    html_parts = [f'<h1>{html.escape(data["title"])}</h1>',
                  f'<p class="meta">{html.escape(data["author"])} · version {data["release"]} · {data["date"]}</p>',
                  '<p><a href="User_Manual.docx">Open the Word manual</a> · <a href="DEVELOPER_GUIDE.md">Read the developer guide</a></p>']
    markdown = [f'# {data["title"]}', '', f'{data["author"]} · version {data["release"]} · {data["date"]}', '']
    nav = '<nav>' + ' · '.join(f'<a href="#topic-{number}">{html.escape(page["heading"])}</a>'
                              for number, page in enumerate(data['pages'], 1)) + '</nav>'
    html_parts.append(nav)
    for number, page in enumerate(data['pages'], 1):
        if number == 1:
            document.add_paragraph(data['title'], 'Title')
            document.add_paragraph(f'{data["author"]} | Version {data["release"]} | {data["date"]}')
        else:
            document.add_page_break()
        document.add_paragraph(page['heading'], 'Heading 1')
        document.add_paragraph(page['intro'])
        html_parts += [f'<section id="topic-{number}"><h2>{html.escape(page["heading"])}</h2>', f'<p>{html.escape(page["intro"])}</p>']
        markdown += [f'## {page["heading"]}', '', page['intro'], '']
        for block in page['blocks']:
            document.add_paragraph(block['heading'], 'Heading 2')
            html_parts.append(f'<h3>{html.escape(block["heading"])}</h3>')
            markdown += [f'### {block["heading"]}', '']
            if 'steps' in block:
                html_parts.append('<ol>')
                for index, text in enumerate(block['steps'], 1):
                    # Explicit visible numbering restarts per procedure. It does
                    # not inherit a previous procedure's Word list counter.
                    paragraph = document.add_paragraph(f'{index}. {text}')
                    paragraph.paragraph_format.left_indent = Inches(.18)
                    paragraph.paragraph_format.first_line_indent = Inches(-.18)
                    html_parts.append(f'<li>{html.escape(text)}</li>')
                    markdown.append(f'{index}. {text}')
                html_parts.append('</ol>')
                markdown.append('')
            for text in block.get('paragraphs', []):
                document.add_paragraph(text)
                html_parts.append(f'<p>{html.escape(text)}</p>')
                markdown += [text, '']
            if 'table' in block:
                table = document.add_table(rows=0, cols=2)
                table.autofit = False
                table.columns[0].width, table.columns[1].width = Inches(1.25), Inches(5.75)
                html_parts.append('<table>')
                for row_number, values in enumerate(block['table']):
                    cells = table.add_row().cells
                    html_parts.append('<tr>')
                    for cell, value in zip(cells, values):
                        cell.text = value
                        cell.vertical_alignment = WD_CELL_VERTICAL_ALIGNMENT.CENTER
                        props = cell._tc.get_or_add_tcPr()
                        margins = OxmlElement('w:tcMar')
                        for edge in ('top', 'left', 'bottom', 'right'):
                            margin = OxmlElement('w:' + edge)
                            margin.set(qn('w:w'), '90')
                            margin.set(qn('w:type'), 'dxa')
                            margins.append(margin)
                        props.append(margins)
                        borders = OxmlElement('w:tcBorders')
                        for edge in ('top', 'left', 'bottom', 'right'):
                            border = OxmlElement('w:' + edge)
                            border.set(qn('w:val'), 'single')
                            border.set(qn('w:sz'), '4')
                            border.set(qn('w:color'), 'D9D9D9')
                            borders.append(border)
                        props.append(borders)
                        shading = OxmlElement('w:shd')
                        shading.set(qn('w:fill'), '263238' if row_number == 0 else ('F3F5F6' if row_number % 2 == 0 else 'FFFFFF'))
                        props.append(shading)
                        for paragraph in cell.paragraphs:
                            paragraph.paragraph_format.space_before = Pt(4)
                            paragraph.paragraph_format.space_after = Pt(4)
                            for run in paragraph.runs:
                                run.font.size = Pt(10)
                                run.font.bold = row_number == 0
                                run.font.color.rgb = RGBColor.from_string('FFFFFF' if row_number == 0 else '000000')
                        tag = 'th' if row_number == 0 else 'td'
                        html_parts.append(f'<{tag}>{html.escape(value)}</{tag}>')
                    html_parts.append('</tr>')
                html_parts.append('</table>')
                for row_number, values in enumerate(block['table']):
                    markdown.append('| ' + ' | '.join(values) + ' |')
                    if row_number == 0:
                        markdown.append('| --- | --- |')
                markdown.append('')
        html_parts.append('</section>')
    document.save(folder / 'User_Manual.docx')
    css = '''body{margin:0;background:#020602;color:#b3ff72;font:17px/1.65 Consolas,monospace}main{max-width:900px;margin:auto;padding:2rem 1.25rem 4rem;overflow-wrap:anywhere}h1,h2,h3{line-height:1.25}h1,h2,a{color:#ffb000}h2{margin-top:2.25rem}h3{margin-top:1.5rem}.meta{color:#85a975}nav{border:1px solid #365e2b;padding:1rem}li{margin:.5rem 0}table{border-collapse:collapse;width:100%}th,td{border:1px solid #365e2b;padding:.6rem;text-align:left}@media print{body{background:white;color:black;font:11pt/1.3 Calibri,sans-serif}h1,h2,h3,a{color:black}nav{display:none}main{max-width:none;padding:0}}'''
    manual = '<!doctype html><html lang="en"><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>' + html.escape(data['title']) + '</title><style>' + css + '</style><main>' + '\n'.join(html_parts) + '</main></html>'
    (folder / 'User_Manual.html').write_text(manual, encoding='utf-8')
    (folder / 'User_Manual.md').write_text('\n'.join(markdown), encoding='utf-8')
    print('Created Word, offline HTML, and Markdown instruction manuals.')


if __name__ == '__main__':
    build_manual()
