# dysociate - source launcher
# Copyright (c) 2026 Luna Love ~ LunaSoft
# SPDX-License-Identifier: GPL-3.0-or-later. See LICENSE.
[CmdletBinding()]
param([switch]$SelfTest)

# Keep one implementation of environment setup for both launcher names.
& (Join-Path $PSScriptRoot 'run_pagebuilder.ps1') -SelfTest:$SelfTest
exit $LASTEXITCODE
