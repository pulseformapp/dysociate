"""Received HTML must not grant local-file access or inject image attributes.

Copyright (c) 2026 Luna Love ~ LunaSoft
SPDX-License-Identifier: GPL-3.0-or-later. See LICENSE.
"""
import json
from pathlib import Path
import tempfile
import unittest

from pagebuilder_gui import Page, Section, load_page, render_document


class ImportTests(unittest.TestCase):
    def setUp(self):
        self.folder = tempfile.TemporaryDirectory(dir=Path.cwd())
        self.root = Path(self.folder.name)

    def tearDown(self):
        self.folder.cleanup()

    def load(self, data):
        path = self.root / 'received.html'
        path.write_text('<script id="luna-page-data" type="application/json">' +
                        json.dumps(data) + '</script>', encoding='utf-8')
        return load_page(str(path))

    def test_embedded_metadata_cannot_read_a_local_file(self):
        secret = self.root / 'private.png'
        secret.write_bytes(b'PRIVATE FILE MUST NEVER BE EMBEDDED')
        page = self.load({'title': 'Received', 'sections': [
            {'kind': 'Post', 'post_id': 'p1', 'body': 'Hello', 'image_path': str(secret)}]})
        self.assertEqual(page.sections[0].image_path, '')
        self.assertNotIn('PRIVATE FILE', render_document(page))
        self.assertNotIn('UFJJVkFURSBGSUxF', render_document(page))

    def test_reject_remote_active_or_broken_image_sources(self):
        for value in ['https://example.com/tracker.png', 'x" onerror="alert(1)',
                      'data:image/svg+xml;base64,PHN2Zz4=', 'data:image/png;base64,%%%']:
            with self.subTest(value=value), self.assertRaises(ValueError):
                self.load({'sections': [{'kind': 'Post', 'post_id': 'p1', 'image_data_url': value}]})

    def test_reject_invalid_metadata_shapes(self):
        for value in [[], None, {'sections': {}}, {'sections': [3]}]:
            with self.subTest(value=value), self.assertRaises(ValueError):
                self.load(value)

    def test_legacy_button_cannot_execute_an_active_url(self):
        with self.assertRaises(ValueError):
            self.load({'sections': [{'kind': 'Button', 'post_id': 'p1',
                                     'button_url': 'javascript:alert(1)'}]})

    def test_reject_duplicate_cycle_or_missing_parent(self):
        for sections in [
            [{'post_id': 'p1'}, {'post_id': 'p1'}],
            [{'post_id': 'p1', 'parent_id': 'p2'}, {'post_id': 'p2', 'parent_id': 'p1'}],
            [{'post_id': 'p1', 'parent_id': 'missing'}],
        ]:
            with self.subTest(sections=sections), self.assertRaises(ValueError):
                self.load({'sections': sections})

    def test_older_missing_identifiers_are_stable(self):
        data = {'sections': [{'kind': 'Post', 'body': 'Older post'}]}
        first, second = self.load(data), self.load(data)
        self.assertEqual(first.sections[0].post_id, second.sections[0].post_id)

    def test_browser_deep_reply_chain_reopens_without_recursion(self):
        page = Page(sections=[Section('Post', body=f'Reply {i}', post_id=f'p{i}',
                                     parent_id=f'p{i-1}' if i else '') for i in range(1600)])
        output = render_document(page)
        self.assertEqual(output.count('class="thread-depth"'), 1600)
        path = self.root / 'deep.html'
        path.write_text(output, encoding='utf-8')
        self.assertEqual(len(load_page(str(path)).sections), 1600)

    def test_image_bytes_exist_only_once_and_remain_editable(self):
        image = 'data:image/png;base64,iVBORwABAgM='
        output = render_document(Page(sections=[Section('Post', image_data_url=image, post_id='p1')]))
        self.assertEqual(output.count(image), 1)
        self.assertNotIn('src="' + image, output)
        path = self.root / 'single-copy.html'
        path.write_text(output, encoding='utf-8')
        self.assertEqual(load_page(str(path)).sections[0].image_data_url, image)

    def test_editor_link_survives_roundtrip_and_rejects_private_or_active_schemes(self):
        page = self.load({'title': 'Phone thread', 'browser_editor_url': 'https://threads.example/editor.html', 'sections': []})
        self.assertIn('https://threads.example/editor.html', render_document(page))
        for address in ['file:///C:/index.html', 'http://127.0.0.1/index.html',
                        'javascript:alert(1)', 'https://localhost/editor', 'https://user:password@example.com/']:
            with self.subTest(address=address), self.assertRaises(ValueError):
                self.load({'sections': [], 'browser_editor_url': address})


if __name__ == '__main__':
    unittest.main()
