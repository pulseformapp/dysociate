# Privacy and file sharing

Copyright (c) 2026 Luna Love ~ LunaSoft
SPDX-License-Identifier: GPL-3.0-or-later. See LICENSE.

dλsociate's desktop app has no account sign-in, advertising, analytics,
background upload, online activation, or automatic update checker. Creating
and saving a thread writes the HTML file at the location you choose. The app
does not provide automatic backup or recovery of unsaved drafts.

The standalone browser editor runs entirely in the HTML. Open HTML reads the
chosen file with FileReader; it never uploads it. Posts stay in memory until
saved/exported. No browser recovery database is promised. A hosted editor fetches
its own HTML from its host, under that host's ordinary access logging; importing
or posting does not upload the selected thread or change the hosted original.

The optional desktop browser preview starts a temporary server bound to
127.0.0.1 on your computer.
It accepts comments for files you explicitly opened. That session address is
not a public link. Keep the app running while posting through that tab.

Sharing is an explicit user action. Copy file puts the actual HTML on the file
clipboard. Email creates an extra .eml file containing the HTML beside your saved
page, then asks the default mail app to open it. The webpage downloads that email
file instead. These files contain your posts/images; delete extra copies when
done. Cancel stops waiting but a completed email file may remain. Nothing is
sent automatically. Your mail app may sync its drafts under its own settings.
WhatsApp/Messenger shortcuts open external websites; attach the HTML there.
The native Windows share sheet is not used. Gumroad handles purchases/receipts.

An HTML thread contains readable text, embedded pictures, and comment metadata.
It is not encrypted, identity-verified, anonymous, or tamper-proof. Anyone with
a copy can read or modify it. Separate copies do not automatically synchronize.
Deleting content from your copy does not remove copies already sent to others.
Photo metadata is not automatically removed; choose images accordingly.

Imported metadata cannot name an image file for the app to read from this
computer. Only an explicit image-picker selection grants that local authoring
path. Imported images must be embedded raster data; remote/active image sources,
active legacy button URLs, duplicate IDs, missing parents, and reply cycles are
rejected. Opening an arbitrary HTML attachment directly in a browser is outside
this import validation; it can contain the sender's own executable web content.

The program's GPL license covers the software and embedded thread runtime.
It does not automatically relicense the user's original posts or pictures.

Email may resize/compress images in a temporary outgoing copy to fit the app's
8 MB MIME budget. The original saved thread is unchanged. Resizing applies EXIF
orientation and re-encoding can remove photo metadata in that copy; this is not
a promise to strip metadata from every image. Normal HTML saves keep image data.
