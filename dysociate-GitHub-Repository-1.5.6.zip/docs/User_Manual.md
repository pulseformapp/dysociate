# dλsociate User Manual

luna love ~ lunasoft · version 1.5.1 · 4 November 2026

## Start using the app

dλsociate creates webpage threads that you can keep and share as a single HTML file. This manual explains how to create posts, add replies, save changes, and send the updated page to somebody else. Start with a new page or open an existing thread. Your images travel inside the saved file. Recipients can also use the HTML directly in their browser without installing this app; see Use the browser edition.

### Install or run

On Windows 10 or 11 x64, run dysociate-setup.exe and choose the installation folder. The installer adds a Start menu shortcut and offers a Desktop shortcut. You can also run dysociate.exe directly from the release folder; Python and WSL are not required.

If using the ISO, double-click dysociate.iso to mount it, then run the installer from the mounted drive. The ISO contains the app and its source; it is not a bootable operating system.

### Create your first page

1. Launch dλsociate. The editor is ready for a new post.
2. Enter a page title. The header text is optional and appears in the generated webpage banner.
3. Click Choose an image if you want a picture. Select it using the normal file browser.
4. Enter a post title if you want one, then write the post text. You can also make a picture-only post.
5. Click Add post. The editor clears so you can write the next post.
6. Click Save, choose a folder, and save as index.html. You choose the location once for this new page.
7. Click Preview to open the saved webpage in your default browser. Keep dλsociate running while adding browser comments.

### Display and help

The app starts fullscreen. Alt+Enter or the Window button switches modes. Esc or Quit asks before closing: Yes saves and quits, No quits without saving, and Cancel keeps editing. A canceled or failed save keeps the app open. The bottom indicator shows unsaved work.

Click Help in the app header or press F1. The offline guide opens in your browser. It also links to this Word manual. Short hover/save effects respect Windows' animation preference. No internet connection or Word installation is needed to read the guide.

## Edit posts and replies

The list on the left is your thread. The editor on the right holds the post or reply you are working on. A title or image is optional; use the fields you need.

### Add and edit posts

Click Add post to keep the current post and prepare the editor for another one. Before the first Save, posts are held in the app's current page. After you choose a save location, adding and editing posts writes to that same file.

Select an existing post in the left list to edit it. The main editor button becomes Save changes. Switching to another post first keeps a meaningful draft; if the page already has a filename, that change is saved too. Click New post for a fresh entry.

### Images and replies

Click the image area to choose or replace a picture. Remove takes the picture out of the draft. PNG, JPG, GIF, WEBP, and BMP are supported. Large pictures make the finished HTML larger, so use smaller images when a messaging service cannot send the file.

To reply inside the app, select a post and click Reply to selected. Enter your reply and click Add post. In the browser, Reply to this post selects the same target in the comment form.

### Clear or delete

Clear draft discards unsaved editor changes after asking you. When editing a saved post, it reloads that post's existing content. Delete removes the selected post and all of its replies after confirmation. These are different actions.

When leaving a page with unsaved work, Save keeps it, Discard continues without it, and Cancel leaves you on the current page.

### Keyboard shortcuts

| Shortcut | Action |
| --- | --- |
| Ctrl O | Open an existing HTML thread |
| Ctrl S | Save the page and current draft |
| Ctrl N | Start a new page |
| Ctrl Enter | Add the current post or save its edits |
| Alt Enter | Toggle fullscreen and normal window mode |
| Esc | Ask to save and quit or keep editing |
| F1 | Open the offline instruction manual |

## Use the browser edition

Every new HTML thread contains a complete browser editor. Recipients can post, reply, choose images, edit, save and email a thread without Python or the desktop app. The same editor is also supplied as Browser/index.html for static hosting.

### Open a received thread

Save the HTML attachment and open it in a full browser. If your phone only shows an attachment preview with no working controls, open your hosted browser edition in Safari or Chrome, tap Open HTML and choose the saved thread. The editor reads that file on your device; it does not upload it.

Browser/index.html can be published on an ordinary static HTTPS host. Share that editor URL with phone users so they can open received HTML attachments. Hosting is not included automatically and the browser edition does not create a live shared database. In Thread details, set Browser editor link after hosting. That address travels in HTML and email invitations; a hosted editor also supplies its own address automatically on export.

### Post, reply and edit

Write text, choose a picture if you want one, then tap Post to thread. It appears immediately without a save dialog. Reply selects a post; Edit loads it into the form. Keep changes updates that post. Delete post + replies removes it and its descendants from your copy after confirmation.

Save HTML and Email include a meaningful unfinished draft automatically in standalone browser mode. Wait until an image is ready first. Clear draft discards just the form after asking. Thread details changes the page title/header or starts a new thread.

### Keep the updated file

Tap Save HTML. Supporting desktop browsers can write a selected file; phones and other browsers download a fresh copy. Check Downloads or Save to Files and keep that updated HTML. A download does not replace the original attachment automatically. If it did not start, tap the visible download link.

Save before closing or reloading. Posts held only in the tab can be lost. A browser permission prompt or canceled save leaves your changes in the tab. The editor cannot bypass the browser's file permissions.

### Optional desktop connection

A tab opened by the desktop app still saves new posts automatically while the app runs. If it stops responding, Continue in browser keeps your draft and makes posting independent. Save HTML or Email then keeps that local version. Editing posts or thread details also works on a browser copy rather than overwriting the desktop original.

## Share and receive a thread

Share the HTML file itself. It contains the saved posts, replies, and images. A path on your C drive and the app's temporary local browser address will not open on another person's computer.

### Send from the app

1. Click Share. The app saves your draft and page first. A new page asks for its save location once.
2. Click Email · HTML attached. The app creates an .eml message beside your HTML with the actual webpage attached, then opens it in your mail app. Choose the recipient and send. If it opens read-only, use Forward or Edit as new.
3. If no email app opens, click Show email file and open it with your mail app. Cancel stops waiting; any completed .eml stays beside the HTML. You can delete that extra copy after sending.
4. For WhatsApp or Messenger, use Copy file and paste it into the destination, or use Show file and its Attach control. These shortcuts open the destination; they do not attach automatically.

### Send from the webpage

Tap Share / Email, then Email · HTML attached. The size estimate includes email encoding. Oversized email copies automatically resize/compress pictures toward an 8 MB preparation budget. This affects the email attachment only; your working thread keeps its original images. GIF animation is preserved.

When ready, the .eml contains the latest HTML and its working editor. Open it in a compatible mail app; use Forward or Edit as new if needed, choose a recipient and send. The prepared size is shown. Cancel preparation stops image processing. If the copy still cannot fit, no email is created; use fewer/smaller pictures, split the thread or transfer the HTML another way.

Download HTML keeps the full-resolution images. Each image is stored once and restored by the inline editor. For messaging apps, attach that HTML with their paperclip control. The app's budget is not a guarantee of every provider's limits.

### Receive and continue

Save the received HTML and open it in the browser editor. Post your reply, then Save HTML or Email the updated thread back. Open in the desktop app remains available if you prefer it.

Separate copies do not synchronize or merge automatically. If two people reply to different copies, agree which copy to continue and keep any other copy you need. Send the latest saved file each time.

### Public web links

A public hyperlink requires hosting the HTML somewhere reachable. Publishing the file does not create a shared online comment database; comments in this app still update local file copies.

## Solve common problems

Read the status message beside the form or at the bottom of the app. It distinguishes a saved comment from a draft that still needs attention.

### The page still has an enable saving button

You may be using an older generated page or an old browser tab. Open the HTML in the current dλsociate app. It opens the current comment interface automatically. Click Save or Preview in the app when you want to write the updated page layout to disk.

### The app connected tab cannot save

Use Continue in browser in the already-loaded tab to keep working independently; your draft stays there. Post it, then Save HTML or Email a copy. To resume automatic desktop saves, open the HTML through the app again and use its new preview tab.

### The browser downloads a new copy

That is the normal phone flow. Save HTML requests a new file when direct writing is unavailable. Confirm it in Downloads or Save to Files, then share that newest copy. A preview inside Mail or Files may disable interaction; use a full browser or the hosted browser editor and Open HTML.

### The folder is not writable or the file is too large to send

Email now prepares smaller copies automatically and includes MIME encoding in its 8 MB budget. If you see an old oversized Outlook draft, create a new email with this version; the old draft does not shrink automatically. For a rejected export, use fewer/smaller pictures or split the conversation. Animated images are retained and may still exceed the budget. Confirm the final size shown by the app; provider limits vary.

### A post changed while you were editing

If the same post changed elsewhere, the app offers to keep your draft as a separate new post. This avoids silently overwriting the other change. A reply added elsewhere is normally loaded automatically when the app regains focus or saves.

### Keep your own copies

Back up HTML threads you want to keep. The release freeze archives the application and source code; it does not automatically back up your personal pages. Uninstalling the app removes its program files, while pages you saved elsewhere stay where you put them.

Created by luna love, lunasoft λ 2026. Release 1.4.0 is GPLv3-or-later; corresponding product source is included. Distributed covered modifications must retain GPL freedoms and source access. Your posts/images remain your content. Each HTML includes its readable GPL runtime and license. Earlier releases remain MIT. See LICENSE and LICENSE_HISTORY.md for details.
