# dλsociate developer guide

Copyright (c) 2026 Luna Love ~ LunaSoft. Product source is GPL-3.0-or-later.

This guide explains the decisions that are easy to break when changing the app.
Start here if a save, reply, image, or email attachment operation is confusing.
The user-facing procedures are in `User_Manual.docx` and `User_Manual.html`.

## Where the code lives

| File | Responsibility |
| --- | --- |
| `dysociate_gui.py` | Current Tk GUI, draft state, conflict choices, opening previews, Help and Share panels |
| `thread_document.py` | File identity, SHA-256 freshness checks, per-file locks, atomic replacement, descendant deletion |
| `pagebuilder_gui.py` | Shared data classes, current HTML/CSS/JavaScript, metadata import and legacy recovery; its old Tk class is reference code |
| `browser_runtime.js` | Complete install-free browser editor embedded in every HTML |
| `build_browser.py` | Same-renderer starter page for file use or static HTTPS hosting |
| `test_browser.cjs` | Boundary-mocked browser lifecycle tests; development-only jsdom |
| `browser_preview.py` | Temporary loopback connection that saves comments to explicitly opened files |
| `windows_share.py` | The binary Windows file clipboard format |
| `email_draft.py` | Local MIME email attachment files and cancellable background tasks |
| `app_resources.py` | Help lookup for source, installed, and one-file executable layouts |
| `build_manual.py` | Word, HTML, and Markdown manuals from `docs/manual_content.json` |
| `build_release.ps1` | Standalone Windows GUI executable and self-test |
| `build_distribution.ps1`, `dysociate.iss` | Complete source/docs staging and per-user installer |
| `build_iso.py` | ISO mastering, file manifest, and readback validation |
| `freeze_release.py` | Fresh archival snapshot, manifest, ZIP, and verification |
| `test_saving.py`, `test_help.py` | Save/concurrency and Help-resource regression tests |
| `pagebuilder_prompt.py`, `pagebuilder.py` | Earlier terminal interfaces, retained as reference source |

The historical filenames are not an instruction to launch the old UI. The
shipping entry point is `dysociate_gui.py`. Keep that entry point in the build
script when changing the renderer. `dλsociate` is the visible name, while
`dysociate.exe` remains the filename and part of the installed Open with entry.

## There are three versions of the page at once

The GUI's text fields and image selection are an **editor draft**. The
`ThreadDocument.page` object is the current **Python model**. The selected HTML
is the **saved document**. They are related, but are not aliases of one object.

```text
editor draft -- _commit() --> Python Page -- save() --> saved HTML
                                  ^                       |
                                  +------ refresh() <------+
browser form -- local comment request -------------------->|
```

This separation lets a browser add a reply while someone is typing in the GUI.
Refreshing the Python model must not replace the GUI's unsaved text. The GUI
keeps two baselines:

- `_draft_baseline` is a tuple of widget values. It answers whether this user
  changed the editor. Tk Text always has a final newline, so the signature reads
  through `end-1c` to exclude that structural character.
- `_post_baseline` is stable JSON for the particular post loaded into the
  editor. It answers whether that same post changed on disk. A new reply to a
  different post must not be treated as a conflict with this draft.

`selected_id` identifies an existing object being edited. An empty selected ID
means append a new object. `parent_id` identifies the parent of a new reply and
can be nonempty even when `selected_id` is empty. Row numbers in the list are
presentation only; refreshing can move them. `select_post()` remembers the
target ID before committing, then resolves that ID again afterward.

`_commit()` returns True when there is nothing meaningful to change as well as
after a successful commit. False means a conflict choice stopped the operation.
It commits only to memory before the first filename is chosen. Later commits
also save to the selected path. Add post commits and then clears the editor;
switching posts commits without losing the intended target's identity.

The rollback copy is deep because rendering can cache image data on Section
objects. Restoring a shallow copy of a list would still leave the same mutated
Section instances inside it. On a save error, the model is restored while the
widgets are left alone, preserving the draft for a retry.

## Why saving uses both locks and fingerprints

The registry lock in `thread_document.py` ensures two threads do not create
different locks for the same normalized path. It is released before file I/O.
The resulting per-file lock covers the read/modify/write operation. It is an
RLock because a browser transaction holds it while calling `open()` and
`save()`, which acquire the same lock again. A normal Lock would deadlock here.

These locks coordinate threads inside one running process. They are not an
operating-system-wide mutex. Another application or another dλsociate process
can still change the file, which is why `_disk_hash` also exists.

The hash represents the exact file bytes last loaded or saved. Even a formatting
change that leaves the visible posts identical changes the hash. `refresh()`
reloads a changed file. `save()` checks freshness again inside the file lock:
another tab might have saved a reply between the caller's refresh and save.
If that happened, save raises instead of silently overwriting the unseen change.
This is a conservative conflict check, not an automatic merge of arbitrary edits.

The write itself follows this sequence:

1. Create a temporary `.html` in the destination directory.
2. Close its initial descriptor before the renderer opens it on Windows.
3. Render the complete new document to that temporary name.
4. Replace the destination using `os.replace`.
5. Remove a leftover staging file if rendering/replacement failed.
6. Record the new path and hash after success.

Staging beside the destination keeps replacement on the same filesystem. It
avoids truncating the original while generating HTML. It does not create a
backup or provide a power-loss guarantee; this code does not call `fsync`.
Errors after replacement may require reloading the new file to understand its
current state. Do not describe every possible save exception as proof that no
disk change happened.

## A browser comment is an operation rather than a replacement page

`BrowserPreview` registers a file chosen by the app, assigns a random token, and
listens on `127.0.0.1` with an operating-system-selected port. It does not expose
a general directory listing or accept a filesystem destination from JSON.
Each tab's token stays tied to its file even after the GUI selects another file.

GET loads that file and renders the current comment interface in memory. It
injects a small `dysociate-bridge` JSON script into that response only. Viewing
an old page does not itself rewrite the source file. A later comment/save writes
the current portable format to disk.

POST accepts a **new comment**, validates its field types and image encoding,
then reloads the latest file inside the per-file lock and appends. If the browser
sent its entire old model, it could erase replies added after that tab loaded.
The response returns the complete updated model so the tab can redraw accurately.

The endpoint checks the generated Host value, the route token, the Origin, and
the JSON content type. Its 32 MiB request limit includes base64 and JSON overhead;
it is not a limit on total thread size. Body text is limited to one million
characters and headings to 4096 characters at this endpoint. Supported image
MIME types are raster data URLs; local paths and arbitrary replacement HTML are
not accepted as image sources by this endpoint.

The bounded body is consumed before a rejection is sent. On Windows, closing a
connection while incoming bytes remain unread can produce a TCP reset that
hides the useful HTTP error from the client. Consuming those bytes is not a
permission decision: validation still happens before parsing or writing.

A repeated ID with the same body and image is treated as a retry after a lost
response, rather than appended twice. This check deliberately compares those
fields; it is not a general revision system or a merge algorithm for two shared
HTML copies. The new parent must already exist, preventing new orphan replies.

The server handles requests on background threads and never changes Tk widgets.
The GUI reloads disk changes when focus returns or when it next commits. Closing
the app shuts down its listener. The loaded tab can detach with Continue in
browser and continue independently, but can no longer save through that session.

## Standalone browser editing and explicit saves

browser_runtime.js is the full editor, loaded verbatim by render_document and
embedded inline in every HTML. build_browser.py uses that same renderer to make
the empty Browser/index.html. No runtime asset, Python process, CDN or API server
is required by an exported thread. A static HTTPS host supplies a phone entry
point when a mail/file preview refuses to execute an attachment's scripts.

Standalone Post commits to the in-memory model immediately, clears the composer
and marks the tab changed. Save/Email include a meaningful unfinished draft too;
an image must finish preparing first. Native file writing is an optional Save
transport, not a prerequisite for posting. Save starts showSaveFilePicker or
requestPermission synchronously within its click handler, before awaiting.
Browsers without that API download a Blob through an ordinary anchor. The URL
stays alive for an explicit second tap if a phone does not start the first
download. Opening Share itself never creates an extra unwanted download.

A granted file handle belongs only to this document in this tab. Import and New
reset it. No IndexedDB/localStorage recovery is claimed: changes remain in
memory until exported, and mobile browsers may kill a tab without beforeunload.
The dirty indicator and beforeunload prompt are useful reminders, not backup.
A prepared download cannot prove the user completed the browser's Save UI.

Open HTML reads a chosen file with FileReader, extracts only the historical JSON
script by pattern, validates it, then renders fresh DOM. It does not execute or
adopt the file's scripts/markup, request remote images, or upload anything.
Allowlisted fields, base64 raster validation, safe legacy links, unique IDs,
existing parents and iterative cycle checks protect the new rendering. Local
image_path is always blank. Invalid imports leave the open thread intact.
The browser importer requires metadata; pre-metadata legacy pages can first be
upgraded by the desktop importer. Selected HTML is limited to 64 MB/10,000 posts,
images to 20 MB. Large JPEGs are resized to 1600px at .85 quality; other photo
formats are converted only if the browser can decode them. Unsupported phone
formats report an error and keep the draft. Text remains plain, not HTML.

Async image selections carry a generation token so a slow old read cannot
replace a newer picture or a cleared draft. Busy saves/imports/desktop appends
disable conflicting mutations. Save snapshots a revision and preserves changes
after failed/canceled writes. A desktop append retries with the same post ID
after a lost response; its twelve-second timeout keeps the draft.

The optional bridge still posts append operations to the desktop's exact file.
Continue in browser detaches it while retaining the draft. Editing existing
posts, thread details or importing a file also detaches: the append-only server
must never accept a stale whole-page replacement. The original desktop file is
unchanged by those browser-copy edits until the user explicitly chooses a save.

browser_editor_url is optional HTTPS metadata. A hosted editor uses its own
origin/path (excluding query/hash) when exporting; a configured address travels
in HTML and email invitations. file:// and the desktop's HTTP loopback URL are
never inferred as shareable editor addresses. A URL is a navigation aid, not a
live synchronization endpoint. No host is provisioned by building this package.

## Portable HTML has two representations and two escaping layers

The file carries visible HTML and an editable JSON model in the script named
`luna-page-data`. That historical script ID is part of the format. Renaming it
requires updating Python import, browser startup, fixtures, and compatibility
handling together.

`body_html()` and the browser's `text()` escape text before converting
newlines into `<br>`. Posts are plain text, not user-supplied HTML. JSON string
escaping is a separate concern: a literal `</script>` inside JSON can end an
HTML script element even though the JSON itself is valid. Both serializers
escape the slash in `</` so that the HTML parser cannot terminate it early.

Images are base64 data URLs stored once in the canonical JSON. Python's
renderer and browser HTML export omit visible img src bytes, using an embedded
marker instead. The inline runtime immediately hydrates pictures from metadata.
A script-disabled attachment preview therefore shows text without these images.
Saving keeps original image bytes; browser email optimization changes only the
temporary outgoing model. This removes the earlier visible+JSON duplication.

`image_html()` caches the encoded bytes on its Section object. After saving,
ThreadDocument clears original image paths when embedded data is available.
Moving/deleting an original photo then does not break a later save. Metadata
always blanks authoring paths in shared files. Keep image-path and image-data
state changes together when modifying this code.

`htmlForDownload()` clones the DOM instead of exporting it directly. It removes
the temporary bridge configuration and resets busy submit buttons. The snapshot
is taken while the live submit button can be disabled; keeping that attribute
would make a reopened saved page unable to post. Export must not remove the
real thread JSON or strip the images along with temporary connection state.

Replies use a flat parent-ID graph. Python and JavaScript build a temporary
parent-to-children index and traverse it iteratively to display it. New writers must preserve
unique IDs, existing parents, and acyclic links. The renderers do not repair
arbitrary hand-edited cycles or orphan links. Deletion expands the descendant
ID set repeatedly so grandchildren disappear even when not adjacent in the list.

`load_page()` trusts current-format JSON only as data, not code. If the JSON tag
exists but is malformed, it raises. Only an absent tag invokes the older class-
based HTML recovery parser. That parser is not a general website importer and
does not promise to preserve every old layout. The actual selected file path,
not a metadata-claimed path, becomes the destination for later saves.

## Sharing without a native share sheet

The desktop and HTML runtimes deliberately never invoke Windows Share or
navigator.share. Both native paths stalled on the user's machine even after
asynchronous preparation. No WinRT dependency remains in the build.

The app's share dialog saves first and captures that file's path/title.
EmailDraftTask runs MIME construction and os.startfile on a daemon worker:
even a stalled external mail application cannot block Tk. A 40 ms GUI timer
polls an attempt-specific queue, with a 45-second deadline. Cancel, timeout,
and dialog destruction abandon that attempt without joining a worker. A late
result never updates another dialog or launches email after cancellation if
opening has not begun. An OS call already in progress cannot be forcibly undone.

email_draft.create_email_file uses stdlib EmailMessage with SMTP/CRLF policy.
The multipart message holds a plain-text invitation and a base64 HTML
attachment whose decoded bytes exactly match the saved page. Header newlines
are removed from the title; the email package handles Unicode header/filename
encoding. Message IDs use a random identifier and dysociate.local rather than
the computer's hostname. Exclusive creation beside the HTML prevents overwriting
another draft and makes this extra personal-content copy visible. Cancel may
leave a completed EML; the program does not delete the user's completed files.

X-Unsent: 1 requests compose mode where supported, but client behavior varies.
Some clients require Forward or Edit as new. Missing file association preserves
the EML and enables Show email file. No mailto link pretends to attach a file.
No code chooses a recipient or sends email.

The browser Email action builds the same multipart/mixed format and downloads
a message/rfc822 EML containing index.html. UTF-8 text is converted to base64 in
bounded chunks to avoid overflowing the JS call stack on image-heavy threads.
RFC 2047 subject words split on Unicode code points and remain under the
75-character encoded-word limit; attachment lines wrap at 76 characters.
Portable exports hide transient sharing controls/status and strip the local
bridge. Browser Email downloads a file; it cannot force a mail client to compose.

The Windows file clipboard uses CF_HDROP: a 20-byte DROPFILES header, fWide=1,
and a UTF-16 path list ending in two NUL code units. GlobalAlloc must supply
movable memory. A successful SetClipboardData transfers ownership to Windows;
freeing that handle afterward would leave a dangling clipboard entry. On
failure, the program still owns and frees it. A text pathname is not a file
attachment. windows_share.py retains its historic module name only for this
clipboard function.

## Help resources and manual maintenance

`ui_theme.py` supplies the current desktop palette and `NeonButton`. The clam
renderer uses explicit foreground AND background maps for normal, active,
pressed, focus, and disabled combinations. Disabled takes priority over pressed
and hover. This avoids inherited native colors hiding a label. Each instance
owns a style so its finite hover animation cannot repaint other buttons. Windows'
client-area animation preference disables motion; tests can also set
`DYSOCIATE_REDUCED_MOTION=1`. The save acknowledgement fades a two-pixel rule
once and stops. There is no continuous scanline/glitch animation or idle timer.

The status indicator debounces widget edits and computes unsaved state from the
actual draft, page metadata, and chosen file. It is not network/sync status.
Destroy marks the app closing before canceling jobs so pending widget events
cannot schedule callbacks against a destroyed interpreter. The status footer
reserves space before the expanding body; small-window tests check real bounds.
The explicit image button provides keyboard access while the image area retains
its mouse shortcut. Window and Quit expose the existing keyboard actions.

On import, metadata never populates local `image_path`. Only the image picker
grants that authoring path. Raster data URLs are alphabet/encoding validated,
attribute-escaped, and cannot be remote/active image markup. Shape checks and
iterative graph validation reject malformed metadata, duplicate IDs, missing
parents, and cycles before rendering. Missing older IDs are assigned stable
ordinal names so independent GUI/browser reads agree before an upgrade save.
Legacy button links reject active schemes. This is scoped input validation,
not a claim that arbitrary HTML opened directly in a browser becomes safe.

Starting with 1.4.0, product code uses GPL-3.0-or-later; earlier MIT releases keep
their original grants. The full license and corresponding product source ship
with the binary. Each generated HTML also contains readable runtime JavaScript,
its copyright/SPDX notice, and full software license in a nonexecuting text
script. That travels through browser exports too. User posts/images remain
separate original content and are not automatically relicensed by the app.

`build_store_bundle.py` prepares verified installer/source/portable downloads
from the completed release. The portable ZIP includes source and notices; the
separate source ZIP also accompanies the installer at no extra charge. Keep
owner-only launch drafts separate from buyer downloads. Signing, fresh-PC,
provider, assistive-technology, recovery, and stress acceptance are recorded in
the release's Launch review; build success does not claim those passed.

The main window requests Tk's `-fullscreen` mode before its first map. Tk
retains its normal geometry, so Alt+Enter switches modes without rebuilding
the UI or touching the document/draft.
A private bindtag is prepended to the main window's widget tree so the shortcut
is consumed before Text's newline or a button's activation binding. Ordinary
key events keep their existing order. Newly introduced main-window controls
should receive the same tag if they are created after initial construction.

Esc uses that same first bindtag to call `close()`. Quit always asks, including
for a clean page. `_leave_document(quitting=True)` distinguishes Yes (save and
quit), No (quit without saving), and None (cancel). A False result from
`save_page()` also stops quitting, covering picker cancellation, write errors,
and unresolved conflicts. The native dialog defaults to Cancel. A reentrancy
flag prevents repeated close/Esc events stacking dialogs during Tk's nested
modal loop; `finally` resets the flag after every outcome. New/Open still use
the original unsaved-change-only flow.

The source manual is `docs/manual_content.json`. `build_manual.py` generates
Word, offline HTML, and Markdown editions from that same content. Edit the
content source first so Help and the printed instructions do not drift apart.
Rebuild using Python with `requirements-docs.txt`, then render and inspect every
Word page. An importable/structurally valid DOCX is not proof of a readable layout.

Help prefers `Documentation/User_Manual.html` beside an installed/portable EXE.
That persistent path keeps working after the app closes. When someone copies
only the EXE, it falls back to PyInstaller's embedded `docs` under `_MEIPASS`.
That folder is temporary and is not the EXE's directory. Source runs use their
own docs directory. Lookup never depends on the shell's working directory.

## Building and freezing the complete project

From Source, run `build_release.ps1` for the EXE. It bootstraps a private virtual
environment if needed, bundles images/docs, uses the GUI bootloader,
and runs the executable's self-test. Python packages are not the Inno Setup
compiler; supply that compiler explicitly to `build_distribution.ps1`.

The distribution builder stages an explicit product/source list plus assets,
documentation, and upstream licenses. It excludes virtual environments, previous
builds, personal pages, and test-tool caches. The installer uses the existing
AppId for upgrades and a per-user directory. Its optional Open with entry does
not take over the browser's HTML association. Documentation is installed along
with the source, and the same Help files are embedded in the standalone EXE.

ISO 9660 internal aliases are intentionally short; Joliet and Rock Ridge store
the readable filenames. After mastering, `build_iso.py` reopens the image and
hashes every extracted file. SHA256SUMS excludes itself to avoid a recursive
digest, while ISO readback includes the completed manifest too. A data ISO is
application distribution media, not an operating-system boot image.

`freeze_release.py` then creates a new archival folder and ZIP. It refuses
existing destinations and reparse/symlink inputs, records relative filenames,
sizes and SHA-256 hashes, verifies copied bytes and ZIP payloads, and checks
the source release did not change during the snapshot. The manifest does not
hash itself; the archive checksum covers the entire final ZIP separately.
Freezing here means a verified versioned snapshot, not filesystem write
protection or a promise that user-created threads were backed up.

## Checks before shipping a change

```powershell
& '.\.venv\Scripts\python.exe' -m unittest -v test_saving test_help
& '.\.venv\Scripts\python.exe' '.\dysociate_gui.py' --self-test
& '.\.venv\Scripts\python.exe' -m unittest -v test_fullscreen
& '.\.venv\Scripts\python.exe' -m unittest -v test_quit
& '.\.venv\Scripts\python.exe' -m unittest -v test_sharing
```

The save tests use temporary files and localhost. They check exact-file routing,
retry deduplication, parallel replies, read-only viewing, rejected foreign-origin
writes, stale GUI protection, write-failure preservation, and image-only replies.
Help tests check source lookup and persistent-versus-embedded precedence. They
also have a separate fullscreen check that opens a temporary Tk window, verifies
startup mode and shortcut dispatch from the editor/button, checks restored
window placement and preserved drafts, and then closes the window. These checks
do not send email/messages or provide evidence that every third-party sharing
service accepts HTML. Windows-only integration checks are needed when changing
the file clipboard or email adapter. Quit tests exercise successful real saves, canceled pickers,
failed writes, discarded changes preserving the old file, clean-page prompts,
and reentrancy; fullscreen tests also dispatch Esc from the editor/button.
A document render check is needed after editing the manual.

For comment-only changes, stripping Python docstrings/comments and comparing ASTs
is useful evidence that logic stayed the same. The JavaScript string is executable
source too: compare it with comments removed, not as a Python string constant.
Treat extra tests as evidence for what they exercise, not as a guarantee of crash,
power-loss, device, provider, or arbitrary imported-file behavior.

## Email size checks and temporary image copies (1.5.1)

The reported browser email was 47,608,833 bytes. Its HTML alone was 34,790,453
bytes: pictures appeared in both visible src and JSON, and email encoded that
whole HTML as base64 again. Fix the payload rather than tweaking Outlook.

email_size.py defines an 8,000,000-byte preparation budget. This is a conservative
application policy, not a provider limit or a delivery guarantee. Desktop checks
the actual complete EmailMessage bytes. Browser first estimates base64/CRLF size
to avoid encoding huge candidates repeatedly, then checks the final MIME Blob.
Oversized messages are rejected before writing/opening mail or downloading EML.

The first reduction is lossless: serialize each picture once. If still too
large, try original-data profiles at 1600/1200/960 pixels and .82/.72/.62 quality.
Never recompress an already-recompressed profile. Only smaller candidates win.
Python uses Pillow with EXIF orientation; browser uses decoded Image/canvas.
WebP preserves transparency and PNG is the browser/encoder fallback. Animated
images are retained; a failed decoder retains its input. No post, picture or
reply is dropped to fit. Failure to fit is an actionable error, not a bad EML.

Both implementations optimize a copy. Normal Save HTML and the source thread
retain their full image data. An imported older file gains the new deduplicated
renderer when saved/exported. Images now require the inline runtime even for
initial display; the noscript message states this tradeoff explicitly.

Browser preparation has a generation-owned job, 45-second deadline, image
timeouts, cancellation and a yield between pictures. Cancel/Close stop the
pending decoder callback and prevent a late download. Conflicting edits remain
disabled during preparation; finally only resets the still-current job. The
desktop polls worker progress without touching Tk from that worker. Cancellation
is checked before image work and before writing a completed message.

