"""Check offline Help lookup without launching a browser or sending anything.

Copyright (c) 2026 Luna Love ~ LunaSoft
SPDX-License-Identifier: GPL-3.0-or-later. See LICENSE.
"""

from pathlib import Path
import sys
import tempfile
import unittest
from unittest.mock import patch

from app_resources import help_manual_path


class HelpResourceTests(unittest.TestCase):
    def test_source_manual_is_packaged(self):
        with patch.object(sys, 'frozen', False, create=True):
            self.assertTrue(help_manual_path().is_file())

    def test_installed_manual_wins_over_temporary_copy(self):
        with tempfile.TemporaryDirectory() as folder:
            root = Path(folder)
            persistent = root / 'Documentation' / 'User_Manual.html'
            embedded = root / 'bundle' / 'docs' / 'User_Manual.html'
            for path in (persistent, embedded):
                path.parent.mkdir(parents=True, exist_ok=True)
                path.write_text('Local guide', encoding='utf-8')
            with patch.object(sys, 'frozen', True, create=True), \
                 patch.object(sys, 'executable', str(root / 'dysociate.exe')), \
                 patch.object(sys, '_MEIPASS', str(root / 'bundle'), create=True):
                self.assertEqual(help_manual_path(), persistent.resolve())
                persistent.unlink()
                self.assertEqual(help_manual_path(), embedded.resolve())


if __name__ == '__main__':
    unittest.main()
