"""Create and verify a fresh source-inclusive dλsociate release snapshot.

Copyright (c) 2026 Luna Love ~ LunaSoft
SPDX-License-Identifier: GPL-3.0-or-later. See LICENSE.

This archives an already built release, not a developer's entire machine.
Original files are never moved or deleted. Exclusive destination creation
prevents accidental replacement of an earlier freeze. Relative file hashes
let the same snapshot be checked after copying it to another drive.
"""

from __future__ import annotations

import argparse
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import shutil
import stat
from zipfile import ZipFile, ZIP_DEFLATED


MANIFEST = 'FREEZE_MANIFEST.json'


def digest(path: Path) -> str:
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def regular_files(root: Path) -> list[Path]:
    """Reject links/reparse points rather than silently archiving their targets.

    Path.resolve() alone would follow a junction before we noticed it. Inspect
    the supplied tree with lstat first; Windows junctions need the reparse flag
    check in addition to Python's portable is_symlink() test.
    """
    files = []
    for path in [root, *sorted(root.rglob('*'))]:
        info = path.lstat()
        if path.is_symlink() or getattr(info, 'st_file_attributes', 0) & getattr(stat, 'FILE_ATTRIBUTE_REPARSE_POINT', 0x400):
            raise ValueError(f'Refusing linked/reparse input: {path}')
        if path.is_file():
            files.append(path)
    return files


def inventory(root: Path) -> list[dict]:
    return [dict(path=path.relative_to(root).as_posix(), size=path.stat().st_size, sha256=digest(path))
            for path in regular_files(root) if path != root / MANIFEST]


def verify_snapshot(root: Path) -> dict:
    """Check exact file membership and bytes, not merely that a manifest exists."""
    manifest = json.loads((root / MANIFEST).read_text(encoding='utf-8'))
    actual = inventory(root)
    expected = manifest['files']
    if actual != expected:
        raise RuntimeError('Snapshot contents differ from the freeze manifest.')
    return manifest


def verify_archive(root: Path, archive: Path) -> None:
    """Read each ZIP entry and compare it to the verified frozen folder."""
    files = regular_files(root)
    expected = {root.name + '/' + path.relative_to(root).as_posix(): path for path in files}
    with ZipFile(archive) as zipped:
        if len(zipped.namelist()) != len(expected) or set(zipped.namelist()) != set(expected):
            raise RuntimeError('ZIP file membership differs from the snapshot.')
        for name, source in expected.items():
            check = hashlib.sha256()
            with zipped.open(name) as stream:
                for block in iter(lambda: stream.read(1024 * 1024), b''):
                    check.update(block)
            if check.hexdigest() != digest(source):
                raise RuntimeError(f'ZIP readback failed: {name}')


def freeze(release: Path, snapshot: Path, archive: Path) -> None:
    release, snapshot, archive = release.absolute(), snapshot.absolute(), archive.absolute()
    if not release.is_dir():
        raise ValueError('Build the complete release directory first.')
    if release == snapshot or release in snapshot.parents or snapshot in release.parents:
        raise ValueError('The snapshot and input release must be separate trees.')
    if snapshot in archive.parents or release in archive.parents:
        raise ValueError('Write the ZIP outside the input and snapshot trees.')
    if snapshot.exists() or archive.exists():
        raise FileExistsError('Choose new snapshot and archive destinations; an existing freeze is never overwritten.')
    before = inventory(release)
    snapshot.mkdir(parents=True, exist_ok=False)
    for item in before:
        target = snapshot / item['path']
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(release / item['path'], target)
        if digest(target) != item['sha256']:
            raise RuntimeError(f'Copy verification failed: {item["path"]}')
    start = '''dλsociate 1.5.6 frozen release
created by luna love, lunasoft λ 2026
License: GPL-3.0-or-later; corresponding product source is included.

Run the app: dysociate/dysociate.exe
Install the app: dysociate/dysociate-setup.exe
No-install browser edition: dysociate/Browser/index.html
Host that HTML on a static HTTPS site for a phone-friendly public editor link.
Read the manual: dysociate/Documentation/User_Manual.docx
Offline browser guide: dysociate/Documentation/User_Manual.html
Understand the code: dysociate/Documentation/DEVELOPER_GUIDE.md
Editable source and builds: dysociate/Source
Mountable distribution image: dysociate.iso

The app starts fullscreen; Alt+Enter toggles back to a normal window.
Esc asks whether to save and quit, quit without saving, or keep editing.
The app's Help button or F1 opens the offline guide.
This freeze contains the program and source, not your personal HTML threads.

Verify this folder using Source/freeze_release.py --verify <snapshot-folder>.
Add --archive <zip-file> to compare every ZIP payload as well.
'''
    (snapshot / 'START_HERE.txt').write_text(start, encoding='utf-8')
    manifest = {
        'product': 'dλsociate', 'version': '1.5.6',
        'frozen_at_utc': datetime.now(timezone.utc).isoformat(),
        'hash_algorithm': 'SHA-256',
        'scope': 'Application, installer, ISO, all product source, assets, documentation, and upstream notices. Excludes developer environments and personal threads.',
        'manifest_note': 'The manifest excludes itself. The archive checksum covers the complete ZIP separately.',
        'files': inventory(snapshot),
    }
    (snapshot / MANIFEST).write_text(json.dumps(manifest, indent=2, ensure_ascii=False) + '\n', encoding='utf-8')
    verify_snapshot(snapshot)
    archive.parent.mkdir(parents=True, exist_ok=True)
    # Mode x means exclusive create; a typo cannot replace a prior ZIP.
    with ZipFile(archive, 'x', compression=ZIP_DEFLATED, compresslevel=6) as zipped:
        for path in regular_files(snapshot):
            zipped.write(path, snapshot.name + '/' + path.relative_to(snapshot).as_posix())
    verify_archive(snapshot, archive)
    if inventory(release) != before:
        raise RuntimeError('The source release changed during freezing; do not publish this snapshot.')
    archive.with_suffix(archive.suffix + '.sha256').write_text(f'{digest(archive)}  {archive.name}\n', encoding='ascii')
    print(f'PASS: frozen folder and ZIP verified; {len(manifest["files"])} content files; source release unchanged.')
    print(snapshot)
    print(archive)


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--release-root', type=Path)
    parser.add_argument('--snapshot', type=Path)
    parser.add_argument('--archive', type=Path)
    parser.add_argument('--verify', type=Path)
    args = parser.parse_args()
    if args.verify:
        verify_snapshot(args.verify)
        if args.archive:
            verify_archive(args.verify, args.archive)
        print('PASS: frozen content verified.')
    elif args.release_root and args.snapshot and args.archive:
        freeze(args.release_root, args.snapshot, args.archive)
    else:
        parser.error('Supply --release-root, --snapshot, --archive; or --verify with optional --archive.')


if __name__ == '__main__':
    main()
