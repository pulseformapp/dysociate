"""Save browser comments directly to the HTML selected in dλsociate.

Copyright (c) 2026 Luna Love ~ LunaSoft
SPDX-License-Identifier: GPL-3.0-or-later. See LICENSE.

The local listener serves only files explicitly registered by the app. Each
page gets an unguessable URL, and writes accept same-origin JSON comments,
never a filesystem path or arbitrary replacement document. Shared/exported
HTML omits this temporary connection and remains a standalone offline file.
"""

from __future__ import annotations

import base64
import json
import re
import secrets
import threading
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import urlsplit

from pagebuilder_gui import Section, load_page, page_metadata, render_document
from thread_document import ThreadDocument, page_file_lock


MAX_COMMENT_BYTES = 32 * 1024 * 1024


class BrowserPreview:
    """Own the temporary local connection for pages explicitly opened by the GUI.

    _paths maps a random capability token to a real file. _tokens gives repeat
    previews of that file the same address during this app session. Neither map
    is a directory server: a client cannot name an arbitrary path in a request.
    Tk widgets are never accessed from these HTTP worker threads.
    """
    def __init__(self) -> None:
        self._paths: dict[str, Path] = {}
        self._tokens: dict[Path, str] = {}
        self._lock = threading.Lock()
        owner = self

        # A nested handler closes over this preview instance. BaseHTTPRequest-
        # Handler is constructed by the server for each connection, so passing
        # the GUI or a mutable 'currently selected file' into it would be fragile.
        # A tab stays bound to its registered file even if the GUI opens another.

        class Handler(BaseHTTPRequestHandler):
            def log_message(self, *args) -> None:
                pass

            def _send(self, status: int, payload: bytes, mime: str = 'application/json') -> None:
                self.send_response(status)
                self.send_header('Content-Type', mime + '; charset=utf-8')
                self.send_header('Content-Length', str(len(payload)))
                self.send_header('Cache-Control', 'no-store')
                self.send_header('X-Content-Type-Options', 'nosniff')
                self.send_header('Referrer-Policy', 'no-referrer')
                self.end_headers()
                self.wfile.write(payload)

            def _json(self, status: int, payload: dict) -> None:
                self._send(status, json.dumps(payload, ensure_ascii=False).encode('utf-8'))

            def _target(self, suffix: str) -> tuple[str, Path] | None:
                """Resolve the route token, never a path supplied by the browser."""
                # Loopback binding alone does not validate the Host header.
                # Require the exact generated authority before looking up a
                # token; do not accept another hostname resolving to this port.
                if self.headers.get('Host') != owner.authority:
                    self._json(403, {'error': 'Invalid page host.'})
                    return None
                match = re.fullmatch(r'/s/([A-Za-z0-9_-]+)/' + suffix, urlsplit(self.path).path)
                with owner._lock:
                    path = owner._paths.get(match[1]) if match else None
                if path is None:
                    self._json(404, {'error': 'This page is not open in the app.'})
                    return None
                return match[1], path

            def do_GET(self) -> None:
                target = self._target(r'index\.html')
                if target is None:
                    return
                token, path = target
                try:
                    with page_file_lock(path):
                        # Render using CURRENT app code without rewriting the
                        # user's file just because they viewed it. Older pages
                        # gain today's comment UI in memory; a later save writes
                        # the upgraded portable document back to disk.
                        page = load_page(str(path))
                        document = render_document(page)
                    # This is a response-only script, not document metadata.
                    # htmlForDownload() removes it before export. Escaping </
                    # also prevents a filename from closing the script element.
                    config = json.dumps({'comment_url': f'/s/{token}/comment', 'filename': path.name}, ensure_ascii=False).replace('</', '<\\/')
                    document = document.replace('</head>', f'<script id="dysociate-bridge" type="application/json">{config}</script>\n</head>', 1)
                    self._send(200, document.encode('utf-8'), 'text/html')
                except (OSError, ValueError) as error:
                    self._json(422, {'error': str(error)})

            def do_POST(self) -> None:
                target = self._target('comment')
                if target is None:
                    return
                try:
                    size = int(self.headers.get('Content-Length', '0'))
                    # This limit applies to the whole encoded JSON request,
                    # including base64 image overhead, not the finished thread.
                    if not 0 < size <= MAX_COMMENT_BYTES:
                        self._json(413, {'error': 'The comment or image is too large.'})
                        return
                    self.connection.settimeout(15)
                    raw = self.rfile.read(size)
                    # Consume the bounded body before returning a rejection:
                    # Windows TCP can otherwise reset a connection with unread
                    # incoming bytes, hiding our useful HTTP error response.
                    # Origin + JSON checks are still done BEFORE parsing/writing.
                    if self.headers.get('Origin') != owner.origin or self.headers.get_content_type() != 'application/json':
                        self._json(403, {'error': 'Only this page can save its comments.'})
                        return
                    post = json.loads(raw.decode('utf-8'))
                    result = owner.add_comment(target[1], post)
                    self._json(200, {'page': result})
                except (ValueError, TypeError, UnicodeError) as error:
                    self._json(400, {'error': str(error)})
                except OSError:
                    self._json(500, {'error': 'Could not write the page. Your original file was kept.'})

        # Port 0 asks Windows for a free ephemeral port. 127.0.0.1 deliberately
        # limits access to this computer; this is not LAN/internet hosting.
        self.server = ThreadingHTTPServer(('127.0.0.1', 0), Handler)
        self.server.daemon_threads = True
        self.authority = f'127.0.0.1:{self.server.server_port}'
        self.origin = 'http://' + self.authority
        self._thread = threading.Thread(target=self.server.serve_forever, kwargs={'poll_interval': .1}, daemon=True)
        self._thread.start()

    def open_page(self, path: Path) -> str:
        """Register an app-chosen file and return its session-only browser URL.

        The URL is useful only while this preview owner is alive. Sharing must
        send the HTML file, not this address. Keeping old registrations allows
        two tabs for different files to keep saving to their own destinations.
        """
        path = path.resolve()
        if path.suffix.lower() not in {'.html', '.htm'} or not path.is_file():
            raise ValueError('Choose an existing HTML page.')
        with self._lock:
            if path not in self._tokens:
                token = secrets.token_urlsafe(32)
                self._tokens[path] = token
                self._paths[token] = path
            return f'{self.origin}/s/{self._tokens[path]}/index.html'

    @staticmethod
    def add_comment(path: Path, payload: dict) -> dict:
        """Append a validated comment to the newest file and return its new model.

        Accept an operation, not a full replacement HTML/model from a stale tab.
        Reloading inside the per-file lock preserves replies from other tabs.
        Any extra payload field such as 'output_path' is ignored; the route's
        pre-registered Path is the only possible destination.
        """
        if not isinstance(payload, dict):
            raise ValueError('Invalid comment.')
        for field in ('post_id', 'parent_id', 'heading', 'body', 'image_data_url', 'image_alt'):
            if not isinstance(payload.get(field, ''), str):
                raise ValueError('Invalid comment field.')
        post_id = payload.get('post_id', '')
        if re.fullmatch(r'[A-Za-z0-9_-]{1,80}', post_id) is None:
            raise ValueError('Invalid comment identifier.')
        body = payload.get('body', '')
        image = payload.get('image_data_url', '')
        if not body.strip() and not image:
            raise ValueError('Write a comment or choose an image.')
        if len(body) > 1_000_000 or len(payload.get('heading', '')) > 4096:
            raise ValueError('The comment is too long.')
        if image:
            # Data URLs keep images portable. Restrict this write endpoint to
            # supported raster MIME types and validate the base64 alphabet;
            # a URL/path in this field must never become a local file read.
            if re.match(r'^data:image/(png|jpeg|gif|webp|bmp|x-icon);base64,', image, re.I) is None:
                raise ValueError('Choose a PNG, JPG, GIF, WEBP, or BMP image.')
            base64.b64decode(image.split(',', 1)[1], validate=True)
        with page_file_lock(path):
            document = ThreadDocument()
            document.open(path)
            existing = next((item for item in document.page.sections if item.post_id == post_id), None)
            if existing:
                # The client may have lost the HTTP response after a successful
                # write. A retry with the same ID/body/image is acknowledged
                # rather than appended twice. This is retry deduplication, not
                # merging two independently edited copies of the whole thread.
                if existing.body != body or existing.image_data_url != image:
                    raise ValueError('This comment identifier is already in use.')
                return page_metadata(document.page)  # Safe retry after a lost response.
            parent = payload.get('parent_id', '')
            if parent and not any(item.post_id == parent for item in document.page.sections):
                raise ValueError('That post changed. Refresh the page and try again.')
            document.page.sections.append(Section(
                'Post', heading=payload.get('heading', '') or 'Comment', body=body,
                post_id=post_id, parent_id=parent, image_data_url=image,
                image_alt=payload.get('image_alt', '') or 'Comment image',
            ))
            document.save()
            return page_metadata(document.page)

    def close(self) -> None:
        """Stop accepting connections before the GUI destroys its resources."""
        self.server.shutdown()
        self.server.server_close()
        self._thread.join(timeout=2)
