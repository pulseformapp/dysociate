// Copyright (c) 2026 Luna Love ~ LunaSoft
// SPDX-License-Identifier: GPL-3.0-or-later. See LICENSE.
// Tests execute the actual generated HTML. File pickers/downloads/transport are
// replaced at their boundary; no mail application or network recipient opens.
const fs = require('node:fs');
const path = require('node:path');
const assert = require('node:assert/strict');
const {JSDOM, VirtualConsole} = require(process.argv[4] || 'jsdom');
const source = fs.readFileSync(process.argv[2], 'utf8');
const output = process.argv[3]; fs.mkdirSync(output, {recursive:true});
const pause = ms => new Promise(resolve => setTimeout(resolve, ms));
let passed = 0;
function check(value, explanation) { assert.ok(value, explanation); }
async function until(predicate) {
  for (let i = 0; i < 300; i++) { if (predicate()) return; await pause(5); }
  throw Error('Browser operation timed out');
}
function fixture(html=source, options={}) {
  const files=[], errors=[], calls={native:0,fetch:0,picker:0,permission:0,writes:[]};
  const virtualConsole = new VirtualConsole();
  virtualConsole.on('jsdomError', error => errors.push(error));
  const dom = new JSDOM(html, {url:options.url || 'file:///C:/Threads/index.html',runScripts:'dangerously',virtualConsole,
    beforeParse(w) {
      w.Blob=globalThis.Blob; w.TextEncoder=options.legacy ? undefined : globalThis.TextEncoder;
      w.HTMLElement.prototype.scrollIntoView=function(){};
      w.confirm=()=>true;
      w.URL.createObjectURL=blob=>{files.push(blob);return 'blob:test-'+files.length;};
      w.URL.revokeObjectURL=()=>{};
      w.HTMLAnchorElement.prototype.click=function(){};
      w.navigator.share=()=>{calls.native++;return new Promise(()=>{});};
      w.navigator.canShare=()=>{calls.native++;return true;};
      w.fetch=async()=>{calls.fetch++;throw Error('No server available');};
      if (options.native) {
        const handle={name:'index.html',requestPermission:async()=>{calls.permission++;return 'granted';},
          createWritable:async()=>({write:async html=>{if(options.fail)throw Error('Disk full');calls.writes.push(html);},close:async()=>{},abort:async()=>{}})};
        w.showSaveFilePicker=async()=>{calls.picker++;if(options.cancel)throw new w.DOMException('Canceled','AbortError');return handle;};
      }
      if(options.before)options.before(w,calls);
    }});
  const d=dom.window.document;
  const result={dom,d,w:dom.window,files,errors,calls,
    click:id=>d.getElementById(id).click(),
    data:()=>JSON.parse(d.getElementById('luna-page-data').textContent),
    status:()=>d.getElementById('comment-status').textContent,
    async post(value,target='') {
      d.getElementById('comment-parent').value=target;
      d.getElementById('comment-body').value=value;
      d.getElementById('comment-form').requestSubmit();
      await until(()=>!d.getElementById('post-submit').disabled);
    },
    async choose(id,content,name,type='text/html') {
      const node=d.getElementById(id);
      Object.defineProperty(node,'files',{configurable:true,value:[new dom.window.File([content],name,{type})]});
      node.dispatchEvent(new dom.window.Event('change'));
      await until(()=>!d.getElementById('post-submit').disabled);
    },
    close(){assert.equal(calls.native,0,'native sharing must never run');assert.equal(errors.length,0,errors.map(e=>e.message).join(';'));dom.window.close();}
  };
  return result;
}
function cleanExport(html) {
  const dom=new JSDOM(html),d=dom.window.document;
  check(!d.getElementById('dysociate-bridge'),'local bridge leaked');
  for(const id of ['share-options','download-ready','image-preview','delete-post','continue-browser'])check(d.getElementById(id).hidden,id+' leaked');
  check(!d.getElementById('post-submit').disabled,'post button exported disabled');
  check(d.getElementById('dysociate-runtime-license').textContent.includes('GNU GENERAL PUBLIC LICENSE'),'GPL missing');
  check(!html.includes('navigator.share'),'native sharing code survived');
  dom.window.close();
}
async function test(name,fn){await fn();passed++;console.log('PASS '+name);}

(async()=>{
await test('Karmic Law and license carry through a saved thread',async()=>{
  const b=fixture();
  b.click('show-terms');
  const dialog=b.d.getElementById('terms-dialog');
  check(dialog.hasAttribute('open'),'terms dialog did not open');
  check(dialog.textContent.includes('If the app is used for nefarious purposes'),'Karmic Law missing');
  assert.equal(dialog.querySelector('p + p').textContent,'~ as above so below ~');
  check(dialog.textContent.includes("LUNA LOVE'S NO-WARRANTY AND LIABILITY DISCLAIMER"),'named disclaimer missing');
  b.click('terms-continue');
  check(!dialog.hasAttribute('open'),'Continue must dismiss the browser notice');
  await b.post('A post after continuing');
  b.click('show-terms');
  b.click('terms-agree');
  check(!dialog.hasAttribute('open')&&b.status()==='Karmic Law agreed.','agreement did not dismiss and acknowledge');
  b.click('save-html');
  const saved=new JSDOM(await b.files[0].text());
  const document=saved.window.document;
  assert.equal(document.querySelector('#terms-dialog p + p').textContent,'~ as above so below ~');
  check(!document.getElementById('terms-dialog').hasAttribute('open'),'open dialog leaked into the export');
  check(!document.getElementById('terms-license').textContent,'duplicate license leaked into the export');
  check(document.getElementById('dysociate-runtime-license').textContent.includes('non-waivable'),'disclaimer missing from the export');
  saved.window.close();b.close();
});
await test('standalone post, image, nested reply, save, reopen, reply again and email',async()=>{
  const b=fixture();
  await b.post('First post λ💜'); const first=b.data().sections[0].post_id;
  check(b.files.length===0&&b.calls.picker===0&&b.calls.fetch===0,'posting unexpectedly needs saving/server');
  const png=Buffer.from('iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAwMCAO+aY1UAAAAASUVORK5CYII=','base64');
  await b.choose('comment-image',png,'phone.png','image/png');
  await b.post('Photo reply',first);
  check(b.data().sections[1].image_data_url.startsWith('data:image/png;base64,'),'image missing');
  b.click('save-html'); check(b.files.length===1,'phone save did not offer HTML');
  const saved=await b.files[0].text(); cleanExport(saved); fs.writeFileSync(path.join(output,'mobile-saved.html'),saved);
  check(saved.split(b.data().sections[1].image_data_url).length===2,'image bytes serialized more than once');
  const reopened=fixture(saved);
  await reopened.post('Reply after reopening',first);
  reopened.click('share-page');check(reopened.files.length===0,'opening share should not download an extra file');
  reopened.click('share-email');check(reopened.files.length===1,'email file not created');
  fs.writeFileSync(path.join(output,'mobile-email.eml'),Buffer.from(await reopened.files[0].arrayBuffer()));
  check(reopened.data().sections.length===3,'reopened thread lost data');
  reopened.close();b.close();
});
await test('save includes an unfinished text draft and read-only hosting stays local',async()=>{
  const b=fixture(source,{url:'https://editor.invalid/index.html',legacy:true});
  b.d.getElementById('comment-body').value='Draft included by Save';
  b.click('save-html');const saved=await b.files[0].text();
  check(saved.includes('Draft included by Save'),'pending draft omitted');
  check(!b.d.getElementById('comment-body').value,'draft not committed');
  b.d.getElementById('page-title').value='Long λ💜日本語 title '.repeat(30);
  b.d.getElementById('page-title').dispatchEvent(new b.w.Event('change'));
  b.click('share-email');
  fs.writeFileSync(path.join(output,'legacy-email.eml'),Buffer.from(await b.files[1].arrayBuffer()));
  check(b.calls.fetch===0,'standalone hosted editor unexpectedly contacted a server');b.close();
});
await test('native save requests permission only on Save and reuses this document handle',async()=>{
  const b=fixture(source,{native:true});await b.post('Native post');check(b.calls.picker===0,'post opened picker');
  b.click('save-html');await until(()=>b.calls.writes.length===1);await until(()=>!b.d.getElementById('save-html').disabled);
  await b.post('Another post');b.click('save-html');await until(()=>b.calls.writes.length===2);
  check(b.calls.picker===1&&b.calls.permission===1,'wrong permission flow');
  cleanExport(b.calls.writes[1]);b.close();
});
for(const mode of ['cancel','fail'])await test(mode+' keeps posted changes in the tab',async()=>{
  const b=fixture(source,{native:true,[mode]:true});await b.post('Keep this post');
  b.click('save-html');await until(()=>!b.d.getElementById('save-html').disabled);
  check(b.data().sections.length===1,'save failure removed a post');
  check(/still/.test(b.status()),'save error not explained');
  const event=new b.w.Event('beforeunload',{cancelable:true});b.w.dispatchEvent(event);check(event.defaultPrevented,'unsaved changes not guarded');b.close();
});
await test('open received metadata without executing scripts, then reset the save handle',async()=>{
  const b=fixture(source,{native:true});await b.post('Old thread');b.click('save-html');await until(()=>b.calls.writes.length===1);
  await until(()=>!b.d.getElementById('save-html').disabled);
  const data={title:'Received thread',sections:[{kind:'Post',post_id:'received',body:'Imported safely',image_path:'C:/private.png'}]};
  const received='<script>window.attacked=true</script><img src="https://invalid.test/tracker"><script id="luna-page-data" type="application/json">'+JSON.stringify(data)+'</script>';
  await b.choose('open-html',received,'received.html');check(!b.w.attacked,'received script ran');
  check(b.data().sections[0].image_path==='','authoring path imported');
  await b.post('New reply','received');b.click('save-html');await until(()=>b.calls.writes.length===2);
  check(b.calls.picker===2,'old thread handle reused for new thread');b.close();
});
await test('malformed imports preserve the open thread',async()=>{
  const b=fixture();await b.post('Keep original');
  for(const sections of [
    [{post_id:'x',parent_id:'x'}], [{post_id:'x'},{post_id:'x'}],
    [{post_id:'x',image_data_url:'https://invalid.test/tracker'}],
    [{kind:'Button',post_id:'x',button_url:'javascript:alert(1)'}]
  ]){
    await b.choose('open-html','<script id="luna-page-data">'+JSON.stringify({sections})+'</script>','bad.html');
    check(b.data().sections[0].body==='Keep original','invalid import destroyed current page');
  }b.close();
});
await test('edit an image post and delete its descendant replies',async()=>{
  const b=fixture();await b.post('Root');const first=b.data().sections[0].post_id;
  await b.post('Child',first);await b.post('Grandchild',b.data().sections[1].post_id);
  b.d.querySelector('[data-edit-post="'+first+'"]').click();b.d.getElementById('comment-body').value='Edited root';
  b.d.getElementById('comment-form').requestSubmit();check(b.data().sections[0].body==='Edited root','edit failed');
  b.d.querySelector('[data-edit-post="'+first+'"]').click();b.click('delete-post');check(b.data().sections.length===0,'descendants survived deletion');b.close();
});
await test('deep replies render iteratively with capped phone indentation',async()=>{
  const sections=Array.from({length:1600},(_,i)=>({kind:'Post',post_id:'p'+i,parent_id:i?'p'+(i-1):'',body:'reply '+i}));
  const html=source.replace(/(<script id="luna-page-data"[^>]*>)[\s\S]*?(<\/script>)/,'$1'+JSON.stringify({title:'Deep',sections})+'$2');
  const b=fixture(html);check(b.d.querySelectorAll('.thread-item').length===1600,'deep replies lost');
  check([...b.d.querySelectorAll('.thread-item')].every(n=>Number(n.style.getPropertyValue('--depth'))<=3),'unbounded nesting');b.close();
});
await test('desktop preview still appends, strips bridge on export, and detaches when offline',async()=>{
  const config='<script id="dysociate-bridge" type="application/json">{"comment_url":"/comment","filename":"index.html"}</script>';
  const b=fixture(source.replace('</head>',config+'</head>'),{
    url:'http://127.0.0.1:3000/index.html',
    before(w,calls){
      const sections=[];
      w.fetch=async(url,opts)=>{
        calls.fetch++;
        sections.push(JSON.parse(opts.body));
        return {ok:true,json:async()=>({page:{title:'Managed',sections}})};
      };
    }
  });
  await b.post('Managed post');check(b.calls.fetch===1&&b.status().includes('Saved to'),'managed auto-save failed');
  b.click('share-email');fs.writeFileSync(path.join(output,'managed-email.eml'),Buffer.from(await b.files[0].arrayBuffer()));
  b.click('continue-browser');await b.post('Independent reply',b.data().sections[0].post_id);
  check(b.calls.fetch===1&&b.data().sections.length===2,'browser mode still depends on app');b.close();
});
await test('oversized text-only email is blocked instead of creating an unusable message',async()=>{
  const data={title:'Oversized',sections:Array.from({length:5},(_,i)=>({kind:'Post',post_id:'p'+i,body:'x'.repeat(650000)}))};
  const html=source.replace(/(<script id="luna-page-data"[^>]*>)[\s\S]*?(<\/script>)/,'$1'+JSON.stringify(data)+'$2');
  const b=fixture(html);b.click('share-email');await until(()=>!b.d.getElementById('share-email').disabled);
  check(b.files.length===0,'oversized message was exported');
  check(b.d.getElementById('share-status').textContent.includes('8 MB'),'missing budget explanation');
  check(b.data().sections.length===5,'oversized rejection lost posts');b.close();
});
await test('canceling image optimization stops the pending job without exporting or changing images',async()=>{
  const image='data:image/png;base64,'+'A'.repeat(6500000);
  const data={title:'Cancel',sections:[{kind:'Post',post_id:'p1',body:'Keep',image_data_url:image}]};
  const html=source.replace(/(<script id="luna-page-data"[^>]*>)[\s\S]*?(<\/script>)/,'$1'+JSON.stringify(data)+'$2');
  const b=fixture(html);b.click('share-email');check(b.d.getElementById('share-email').disabled,'no pending optimizer');
  b.click('cancel-email');await pause(30);
  check(!b.d.getElementById('share-email').disabled&&b.files.length===0,'canceled optimizer exported late');
  check(b.data().sections[0].image_data_url===image,'optimizer changed original image');b.close();
});
console.log('PASS: '+passed+' browser scenarios; standalone HTML and MIME artifacts ready for independent parser checks.');
})().catch(error=>{console.error(error);process.exitCode=1;});
