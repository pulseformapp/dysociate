"""Local email attachments without COM, WinRT, or a blocking share sheet.

Copyright (c) 2026 Luna Love ~ LunaSoft
SPDX-License-Identifier: GPL-3.0-or-later. See LICENSE.
"""
from __future__ import annotations

from email.message import EmailMessage
from email.policy import SMTP
from email.utils import format_datetime
from datetime import datetime, timezone
from pathlib import Path
from queue import SimpleQueue, Empty
from threading import Event, Thread
import os
import time
import uuid
from email_size import MAX_EMAIL_BYTES, EMAIL_PROFILES, EmailTooLargeError, megabytes, smaller_email_page


def create_email_file(path: Path, title: str, *, max_email_bytes=MAX_EMAIL_BYTES, cancelled=None, progress=None) -> Path:
    """Build a real attachment, optimizing an oversized COPY before opening mail.

    A mailto URL cannot carry an attachment. An EML can: its multipart body
    contains both the readable invitation and the base64-encoded HTML. The
    X-Unsent hint requests compose mode where supported; other clients may
    open a message that the user must Forward or Edit as new. Nothing is sent.
    Keep the draft beside the HTML so the user can find/delete this extra copy.
    Exclusive creation and a random name never overwrite somebody's email.
    """
    path = Path(path).resolve()
    # The optional public editor link gives phones a route out of a mail/file
    # preview. Never infer that link from the app's private loopback address.
    from pagebuilder_gui import load_page, render_document
    try:
        page = load_page(str(path))
        editor_url = page.browser_editor_url
    except (ValueError, OSError):
        page = None
        editor_url = ''
    invitation = 'Here is an offline webpage thread. Save the attached HTML file and open it in a full browser to post and reply. No desktop app is required.\n'
    if editor_url:
        invitation += '\nPhone showing a read-only preview? Open this browser editor, then choose Open HTML and select the saved thread:\n' + editor_url + '\n'
    def encode(html):
        message = EmailMessage(policy=SMTP)
        message['Subject'] = ' '.join((title or 'Offline thread').splitlines())
        message['Date'] = format_datetime(datetime.now(timezone.utc))
        message['Message-ID'] = f'<{uuid.uuid4().hex}@dysociate.local>'
        message['X-Unsent'] = '1'
        message.set_content(invitation)
        message.add_attachment(html, maintype='text', subtype='html', filename=path.name)
        return message.as_bytes()

    if progress:
        progress('Checking the complete email size…')
    payload = encode(path.read_bytes())
    if len(payload) > max_email_bytes and page is not None:
        # Older files contain visible and JSON copies of each image. Today's
        # renderer removes that duplication without changing the image bytes.
        payload = encode(render_document(page).encode('utf-8'))
        for edge, quality in EMAIL_PROFILES:
            if len(payload) <= max_email_bytes:
                break
            smaller = smaller_email_page(page, edge, quality, cancelled=cancelled, progress=progress)
            candidate = encode(render_document(smaller).encode('utf-8'))
            if len(candidate) < len(payload):
                payload = candidate
    if cancelled and cancelled.is_set():
        raise InterruptedError('Email preparation canceled.')
    if len(payload) > max_email_bytes:
        raise EmailTooLargeError(f'Email is {megabytes(len(payload))} after optimization; the app budget is {megabytes(max_email_bytes)}. No email was opened. Use fewer/smaller pictures, split the thread, or transfer the HTML file another way.')
    destination = path.with_name(f'{path.stem}-email-{uuid.uuid4().hex[:12]}.eml')
    with destination.open('xb') as output:
        output.write(payload)
    return destination


class EmailDraftTask:
    """Poll a daemon worker; Tk must never wait for disk or a mail application.

    Each click owns one task/queue, so a canceled task's late result cannot
    open a different document or update a replacement dialog. Cancel/timeout
    stop waiting, not an already-running OS call. Completed EML files remain
    beside the HTML even after cancellation; they contain the user's content.
    Neither cancel nor poll joins a worker. Only the GUI thread touches Tk.
    """
    def __init__(self, path, title, *, writer=create_email_file, opener=os.startfile,
                 timeout=45, clock=time.monotonic):
        self.cancelled = Event()
        self.results = SimpleQueue()
        self.clock, self.deadline = clock, clock() + timeout
        self.progress = 'Preparing email…'
        self.email_bytes = 0

        def run():
            try:
                if writer is create_email_file:
                    result = writer(path, title, cancelled=self.cancelled,
                                    progress=lambda value: setattr(self, 'progress', value))
                else:
                    result = writer(path, title)
                try:
                    self.email_bytes = result.stat().st_size
                except OSError:
                    pass
                error = None
                if not self.cancelled.is_set():
                    try:
                        opener(str(result))
                    except OSError as failure:
                        error = failure
                self.results.put((result, error))
            except Exception as error:
                self.results.put(error)
        Thread(target=run, name='dysociate-email', daemon=True).start()

    def cancel(self):
        self.cancelled.set()

    def poll(self):
        if self.cancelled.is_set():
            return None
        try:
            result = self.results.get_nowait()
        except Empty:
            if self.clock() >= self.deadline:
                self.cancel()
                raise TimeoutError('The email app is taking too long. Use Copy file or Show file.')
            return None
        if isinstance(result, Exception):
            raise result
        return result
