"""dysociate: prompt-first offline webpage and thread authoring application.

Copyright (c) 2026 Luna Love ~ LunaSoft

The terminal workflow is intentionally small: a post is an optional image,
a title, and body text.  Existing generated HTML files can be opened, viewed
in the browser, and extended through the webpage's own comment form.  The
HTML file remains the portable offline thread artifact.

See LICENSE for the GPLv3-or-later terms.
"""

from __future__ import annotations

import curses
import ctypes
import shlex
import sys
import tkinter as tk
import webbrowser
from pathlib import Path
from tkinter import filedialog

from pagebuilder_gui import (
    BODY_LIMIT,
    PATH_LIMIT,
    Page,
    Section,
    index_path_from_selection,
    load_page,
    new_section,
    render_html,
    self_test,
)


class QuitRequested(Exception):
    pass


# PromptTerminal owns the small command language and the current Page.  It
# intentionally does not render webpage fields in a GUI: every post question
# appears in sequence, while native Windows dialogs handle only file picking.
class PromptTerminal:
    """Reference TUI sharing today's renderer, not the current GUI launcher.

    Leading ':' commands inside an answer are intentional: plain text such as
    'help' must still be usable as a post title/body. Command-mode answers use
    the separate dispatch() parser. Legacy prompt saves do not use the GUI's
    BrowserPreview owner; launch the GUI for the current automatic save flow.
    """
    def __init__(self, stdscr: curses.window) -> None:
        self.stdscr = stdscr
        self.page = Page()
        self.has_saved_file = False
        self.lines: list[str] = []
        self.max_lines = 100

    def redraw(self, prompt: str = "") -> None:
        height, width = self.stdscr.getmaxyx()
        self.stdscr.erase()
        try:
            self.stdscr.attron(curses.color_pair(1) | curses.A_BOLD)
            self.stdscr.addnstr(0, 0, " dysociate :: PROMPT MODE ", max(1, width - 1))
            self.stdscr.attroff(curses.color_pair(1) | curses.A_BOLD)
        except curses.error:
            pass
        self._add(1, 2, "Pure Python | PowerShell | curses | commands: help, gen, add, list, quit", width - 4, curses.A_DIM)
        self._add(2, 2, f"Page: {self.page.title} | Sections: {len(self.page.sections or [])}", width - 4, curses.A_DIM)
        try:
            self.stdscr.hline(3, 0, curses.ACS_HLINE, width)
        except curses.error:
            pass

        body_bottom = max(5, height - 3)
        visible = self.lines[-max(1, body_bottom - 5):]
        for row, line in enumerate(visible, start=5):
            if row >= body_bottom:
                break
            self._add(row, 2, line, width - 4)

        if height >= 3:
            self._add(height - 2, 2, prompt, width - 4, curses.A_BOLD)
        self.stdscr.refresh()

    def _add(self, y: int, x: int, text: str, width: int, attr: int = 0) -> None:
        if width <= 0:
            return
        try:
            self.stdscr.addnstr(y, x, text[:width], width, attr)
        except curses.error:
            pass

    def say(self, text: str = "") -> None:
        self.lines.extend(str(text).splitlines() or [""])
        self.lines = self.lines[-self.max_lines:]
        self.redraw()

    def raw_input(self, question: str) -> str:
        # The question and the editable answer occupy separate rows.  This
        # keeps long questions readable in a normal PowerShell console.
        height, width = self.stdscr.getmaxyx()
        self.redraw()
        self._add(max(0, height - 2), 2, f"? {question}", width - 4, curses.A_BOLD)
        self._add(max(0, height - 1), 2, "> ", width - 4, curses.A_BOLD)
        self.stdscr.refresh()
        self.stdscr.nodelay(False)
        curses.echo()
        try:
            raw = self.stdscr.getstr(max(0, height - 1), 4, max(1, width - 6))
        except curses.error:
            raw = b""
        finally:
            curses.noecho()
            self.stdscr.nodelay(False)
        answer = raw.decode("utf-8", errors="replace").strip()
        self.lines.append(f"> {answer}")
        self.lines = self.lines[-self.max_lines:]
        return answer

    def handle_inline_command(self, answer: str) -> bool:
        command = answer[1:].strip().lower() if answer.startswith(":") else ""
        if command == "help":
            self.show_help()
            return True
        if command in {"gen", "generate"}:
            self.generate()
            return True
        if command in {"list", "ls"}:
            self.list_sections()
            return True
        if command in {"quit", "q", "exit"}:
            raise QuitRequested
        return False

    def ask(self, question: str, default: str = "") -> str | None:
        while True:
            answer = self.raw_input(question + (f" [{default}]" if default else ""))
            if answer == "":
                return default
            if answer.startswith(":"):
                command = answer[1:].strip().lower()
                if command == "cancel":
                    return None
                if self.handle_inline_command(answer):
                    continue
                self.say("Unknown inline command. Use :help, :gen, :list, :cancel, or :quit.")
                continue
            return answer

    def show_help(self) -> None:
        self.say("COMMANDS")
        self.say("  add                 Start another run of post questions.")
        self.say("  list                Show all posts.")
        self.say("  edit N              Re-answer one post's image, title, and body.")
        self.say("  delete N            Delete a post.")
        self.say("  open                Load an existing index.html and open it.")
        self.say("  view                Open the current webpage in the browser.")
        self.say("  new                 Start a new offline thread.")
        self.say("  page                Re-answer page title and banner questions.")
        self.say("  gen                 Write or update index.html.")
        self.say("  clear               Clear the terminal history.")
        self.say("  quit                Exit the webpage maker.")
        self.say("During any question, use :help, :gen, :list, :cancel, or :quit.")

    def setup_page(self) -> None:
        title = self.ask("What should the webpage title be?", self.page.title)
        if title is not None:
            self.page.title = title
        banner = self.ask("What text should appear inside the terminal header?", self.page.terminal_banner)
        if banner is not None:
            self.page.terminal_banner = banner
        self.say("Page settings updated.")

    def list_sections(self) -> None:
        if not self.page.sections:
            self.say("No sections yet. Type add to create one.")
            return
        self.say("SECTIONS")
        for index, section in enumerate(self.page.sections, start=1):
            heading = section.heading or "(untitled)"
            image = " +image" if section.image_path or section.image_data_url else ""
            indent = "  " if section.parent_id else ""
            self.say(f"{indent}{index}. {heading}{image}")

    def choose_image(self, current_path: str = "") -> str:
        root = None
        try:
            root = tk.Tk()
            root.withdraw()
            root.attributes("-topmost", True)
            root.update_idletasks()
            current = Path(current_path).expanduser()
            initial_directory = str(current.parent if current_path and str(current.parent) != "." else Path.home())
            selected = filedialog.askopenfilename(
                parent=root,
                title="Choose image",
                initialdir=initial_directory,
                filetypes=[
                    ("Image files", ("*.png", "*.jpg", "*.jpeg", "*.gif", "*.webp", "*.svg", "*.bmp")),
                    ("All files", "*.*"),
                ],
            )
            return selected
        except Exception as error:
            self.say(f"Image browser unavailable: {error}")
            return current_path
        finally:
            if root is not None:
                root.destroy()

    def ask_body(self, current: str = "") -> str | None:
        """Collect multiple terminal lines; '.' ends input and None cancels.

        An empty string is valid body text, so callers must not treat all falsey
        results as cancellation. This distinction also matters when editing an
        existing post and deciding whether to restore its backup.
        """
        self.say("Body text: enter one line at a time; type a single . when finished.")
        if current:
            self.say(f"Current body: {current.replace(chr(10), ' / ')}")
        collected: list[str] = []
        while True:
            answer = self.raw_input("body line (.)")
            if answer == ".":
                return "\n".join(collected)[:BODY_LIMIT]
            if answer.startswith(":"):
                if answer[1:].strip().lower() == "cancel":
                    return None
                if self.handle_inline_command(answer):
                    continue
            collected.append(answer)
            if sum(len(line) + 1 for line in collected) >= BODY_LIMIT:
                self.say("Body limit reached.")
                return "\n".join(collected)[:BODY_LIMIT]

    def fill_section(self, section: Section) -> bool:
        wants_image = self.ask("Attach an image? [y/N]", "y" if section.image_path or section.image_data_url else "n")
        if wants_image is None:
            return False
        if wants_image.lower() in {"y", "yes"}:
            selected = self.choose_image(section.image_path)
            if selected:
                section.image_path = selected[:PATH_LIMIT]
                alt = self.ask("What alt text should the image have?", section.image_alt or "Image")
                if alt is None:
                    return False
                section.image_alt = alt
            else:
                self.say("No image selected; continuing without changing the image.")

        heading = self.ask("What is the post title?", section.heading)
        if heading is None:
            return False
        section.heading = heading

        body = self.ask_body(section.body)
        if body is None:
            return False
        section.body = body

        return True

    def add_post(self, parent_id: str = "") -> bool:
        # A blank parent_id creates a top-level post.  A parent ID creates a
        # comment/reply while using the same three-question post flow.
        section = new_section("Post")
        section.parent_id = parent_id
        if self.fill_section(section):
            self.page.sections.append(section)
            self.say(f"Added {'comment' if parent_id else 'post'} {len(self.page.sections)}.")
            return True
        self.say("Post cancelled.")
        return False

    def add_section(self) -> None:
        while self.add_post():
            next_post = self.ask("Create another post? [Y/n]", "y")
            if next_post is None or next_post.lower() not in {"y", "yes", ""}:
                break

    def add_comment(self, token: str) -> None:
        index = self.section_number(token)
        if index is None:
            return
        parent_id = self.page.sections[index].post_id
        if not parent_id:
            self.say("That post has no thread id; regenerate it first.")
            return
        while self.add_post(parent_id):
            again = self.ask("Add another comment to this post? [y/N]", "n")
            if again is None or again.lower() not in {"y", "yes"}:
                break

    def new_thread(self) -> None:
        self.page = Page()
        self.has_saved_file = False
        self.setup_page()
        self.add_section()

    def section_number(self, token: str) -> int | None:
        try:
            index = int(token) - 1
        except ValueError:
            self.say("Use a section number, such as 1.")
            return None
        if index < 0 or index >= len(self.page.sections):
            self.say("That section number does not exist.")
            return None
        return index

    def edit_section(self, token: str) -> None:
        index = self.section_number(token)
        if index is None:
            return
        source = self.page.sections[index]
        backup = Section(source.kind, source.heading, source.body, source.button_label, source.button_url, source.image_path, source.image_alt, source.label, source.post_id, source.parent_id, source.image_data_url)
        if self.fill_section(source):
            self.say(f"Updated section {index + 1}.")
        else:
            self.page.sections[index] = backup
            self.say("Edit cancelled; the old section was kept.")

    def delete_section(self, token: str) -> None:
        # Parent IDs can point across non-adjacent rows. Expand the descendant
        # set to a fixed point before filtering; deleting only the selected row
        # would leave invisible orphan replies in the persistent JSON model.
        index = self.section_number(token)
        if index is None:
            return
        removed = self.page.sections[index]
        removed_ids = {removed.post_id}
        changed = True
        while changed:
            changed = False
            for section in self.page.sections:
                if section.parent_id in removed_ids and section.post_id not in removed_ids:
                    removed_ids.add(section.post_id)
                    changed = True
        self.page.sections = [section for section in self.page.sections if section.post_id not in removed_ids]
        self.say(f"Deleted post {index + 1} and its comments.")

    def move_section(self, token: str, direction: str) -> None:
        index = self.section_number(token)
        if index is None:
            return
        target = index - 1 if direction.lower() == "up" else index + 1 if direction.lower() == "down" else -1
        if target < 0 or target >= len(self.page.sections):
            self.say("That move is not possible.")
            return
        self.page.sections[index], self.page.sections[target] = self.page.sections[target], self.page.sections[index]
        self.say(f"Moved section {index + 1} {direction.lower()}.")

    def import_text(self, token: str) -> None:
        index = self.section_number(token)
        if index is None:
            return
        root = None
        try:
            root = tk.Tk()
            root.withdraw()
            root.attributes("-topmost", True)
            selected = filedialog.askopenfilename(
                parent=root,
                title="Choose text file",
                filetypes=[("Text files", ("*.txt", "*.md", "*.csv")), ("All files", "*.*")],
            )
            if selected:
                self.page.sections[index].body = Path(selected).read_text(encoding="utf-8", errors="replace")[:BODY_LIMIT]
                self.say(f"Imported text into section {index + 1}.")
        except OSError as error:
            self.say(f"Could not import text: {error}")
        finally:
            if root is not None:
                root.destroy()

    def open_page(self) -> None:
        # Opening a legacy file immediately rewrites it with thread metadata
        # and the browser comment form, so the user does not need a migration
        # command before interacting with it.
        root = None
        try:
            root = tk.Tk()
            root.withdraw()
            root.attributes("-topmost", True)
            selected = filedialog.askopenfilename(
                parent=root,
                title="Open existing index.html",
                filetypes=[("HTML files", "*.html"), ("All files", "*.*")],
            )
            if not selected:
                self.say("Open cancelled.")
                return
            self.page = load_page(selected)
            # Upgrade older files so they receive the embedded thread data and webpage comment form.
            render_html(self.page, selected)
            self.has_saved_file = True
            webbrowser.open(Path(selected).resolve().as_uri())
            self.say(f"Loaded and opened {selected}.")
        except (OSError, ValueError) as error:
            self.say(f"Could not open webpage: {error}")
        finally:
            if root is not None:
                root.destroy()

    def view_page(self) -> None:
        if not self.has_saved_file or not Path(self.page.output_path).exists():
            self.say("No generated webpage is loaded yet. Use open or gen first.")
            return
        webbrowser.open(Path(self.page.output_path).resolve().as_uri())
        self.say(f"Opened {self.page.output_path} in the browser.")

    def generate(self) -> None:
        # Loaded pages update in place.  New pages use Save As once, then later
        # generations can update that chosen file directly.
        if self.has_saved_file and Path(self.page.output_path).exists():
            try:
                destination = render_html(self.page, self.page.output_path)
                webbrowser.open(Path(destination).resolve().as_uri(), new=0)
                self.say(f"Updated existing index.html at {destination}")
            except (OSError, ValueError) as error:
                self.say(f"Generation failed: {error}")
            return

        root = None
        try:
            root = tk.Tk()
            root.withdraw()
            root.attributes("-topmost", True)
            selected = filedialog.asksaveasfilename(
                parent=root,
                title="Save webpage as index.html",
                initialfile="index.html",
                defaultextension=".html",
                filetypes=[("HTML files", "*.html"), ("All files", "*.*")],
            )
            if not selected:
                self.say("Save cancelled; no file was written.")
                return
            self.page.output_path = index_path_from_selection(selected)
            destination = render_html(self.page, self.page.output_path)
            self.has_saved_file = True
            webbrowser.open(Path(destination).resolve().as_uri(), new=0)
            self.say(f"Generated index.html at {destination}")
        except (OSError, ValueError) as error:
            self.say(f"Generation failed: {error}")
        finally:
            if root is not None:
                root.destroy()

    def dispatch(self, answer: str) -> bool:
        try:
            parts = shlex.split(answer)
        except ValueError as error:
            self.say(f"Command error: {error}")
            return True
        if not parts:
            return True
        command = parts[0].lower()
        args = parts[1:]
        if command in {"help", "?"}:
            self.show_help()
        elif command == "add":
            self.add_section()
        elif command == "new":
            self.new_thread()
        elif command in {"list", "ls"}:
            self.list_sections()
        elif command == "edit" and args:
            self.edit_section(args[0])
        elif command == "delete" and args:
            self.delete_section(args[0])
        elif command == "comment":
            self.say("Comments now happen directly in the generated webpage form.")
        elif command == "open":
            self.open_page()
        elif command == "view":
            self.view_page()
        elif command == "page":
            self.setup_page()
        elif command in {"gen", "generate", "save"}:
            self.generate()
        elif command == "clear":
            self.lines.clear()
            self.stdscr.clear()
            self.stdscr.touchwin()
            self.redraw()
        elif command in {"quit", "q", "exit"}:
            raise QuitRequested
        else:
            self.say("Unknown command. Type help for the command list.")
        return True

    def run(self) -> None:
        self.say("Welcome. Each post asks only for an image, a title, and body text.")
        self.say("Start a new thread or open an existing index.html.")
        while True:
            start = self.raw_input("start [new/open/help]").lower()
            if start in {"help", "?"}:
                self.show_help()
                continue
            if start in {"open", "load"}:
                self.open_page()
                break
            if start in {"new", "", "add"}:
                self.new_thread()
                break
            self.say("Type new, open, or help.")
        while True:
            answer = self.raw_input("command [help]")
            self.dispatch(answer)


def run_curses() -> None:
    def application(stdscr: curses.window) -> None:
        curses.cbreak()
        curses.noecho()
        stdscr.keypad(True)
        try:
            curses.start_color()
            curses.init_pair(1, curses.COLOR_BLACK, curses.COLOR_GREEN)
        except curses.error:
            pass
        try:
            PromptTerminal(stdscr).run()
        except QuitRequested:
            return

    curses.wrapper(application)


def main() -> int:
    if len(sys.argv) == 2 and sys.argv[1] == "--self-test":
        self_test()
        return 0
    if sys.platform == "win32":
        # Name the console; Windows Terminal may still show its host icon.
        # The executable and installed shortcuts carry the supplied artwork.
        ctypes.windll.kernel32.SetConsoleTitleW("dysociate")
        ctypes.windll.shell32.SetCurrentProcessExplicitAppUserModelID("LunaSoft.dysociate")
    run_curses()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
