"""Legacy curses pagebuilder interface retained as open-source reference code.

Copyright (c) 2026 Luna Love ~ LunaSoft

The current launcher uses pagebuilder_prompt.py.  This earlier interface is
kept in the source bundle so the evolution of the project remains visible and
available to anyone who wants to reuse its field-oriented curses editor.

See LICENSE for the GPLv3-or-later terms.
"""

from __future__ import annotations

import base64
import curses
import html
import mimetypes
import sys
import tempfile
from dataclasses import dataclass, replace
from pathlib import Path


SECTION_TYPES = ("Hero", "Text", "Image", "Button", "Divider")
BODY_LIMIT = 8192
PATH_LIMIT = 4096


@dataclass
class Section:
    kind: str
    heading: str = ""
    body: str = ""
    button_label: str = ""
    button_url: str = ""
    image_path: str = ""
    image_alt: str = ""


@dataclass
class Page:
    title: str = "My Static Page"
    output_path: str = "index.html"
    terminal_banner: str = ""
    sections: list[Section] | None = None

    def __post_init__(self) -> None:
        if self.sections is None:
            self.sections = []


def new_section(kind: str) -> Section:
    defaults = {
        "Hero": Section("Hero", "Welcome", "Introduce your page here."),
        "Text": Section("Text", "Section heading", "Write your content here."),
        "Image": Section("Image", "Image", image_alt="Page image"),
        "Button": Section(
            "Button",
            "Call to action",
            "Invite visitors to continue.",
            "Learn more",
            "https://example.com",
        ),
        "Divider": Section("Divider"),
    }
    return replace(defaults.get(kind, Section("Text")))


def clipped(value: str, limit: int) -> str:
    if len(value) <= limit:
        return value
    return value[: max(0, limit - 1)] + "…"


def add_text(stdscr: curses.window, y: int, x: int, text: str, width: int, attr: int = 0) -> None:
    if width <= 0 or y < 0:
        return
    try:
        stdscr.addnstr(y, x, clipped(text, width), width, attr)
    except curses.error:
        pass


def set_cursor(visible: bool) -> None:
    try:
        curses.curs_set(1 if visible else 0)
    except curses.error:
        pass


def prompt_line(stdscr: curses.window, label: str, current: str = "") -> str:
    height, width = stdscr.getmaxyx()
    stdscr.erase()
    add_text(stdscr, 1, 2, "INPUT", width - 4, curses.A_BOLD)
    add_text(stdscr, 3, 2, label, width - 4)
    if current:
        add_text(stdscr, 4, 2, f"Current: {current}", width - 4, curses.A_DIM)
    add_text(stdscr, 6, 2, "> ", width - 4)
    stdscr.refresh()
    curses.echo()
    set_cursor(True)
    try:
        stdscr.nodelay(False)
        raw = stdscr.getstr(6, 4, max(1, width - 6))
    except curses.error:
        raw = b""
    finally:
        stdscr.nodelay(True)
        curses.noecho()
        set_cursor(False)
    _ = height
    return raw.decode("utf-8", errors="replace")


def wait_for_key(stdscr: curses.window, message: str) -> None:
    height, width = stdscr.getmaxyx()
    add_text(stdscr, max(0, height - 1), 2, message, width - 4)
    stdscr.refresh()
    stdscr.nodelay(False)
    stdscr.getch()
    stdscr.nodelay(True)


def confirm(stdscr: curses.window, message: str) -> bool:
    height, width = stdscr.getmaxyx()
    stdscr.erase()
    add_text(stdscr, 2, 2, message, width - 4)
    add_text(stdscr, 4, 2, "Press Y to confirm or any other key to cancel.", width - 4)
    stdscr.refresh()
    stdscr.nodelay(False)
    result = stdscr.getch() in (ord("y"), ord("Y"))
    stdscr.nodelay(True)
    _ = height
    return result


def draw_header(stdscr: curses.window, page: Page) -> None:
    height, width = stdscr.getmaxyx()
    try:
        stdscr.attron(curses.color_pair(1) | curses.A_BOLD)
        stdscr.addnstr(0, 0, " NCURSES PAGEBUILDER - PYTHON / POWERSHELL ", max(1, width - 1))
        stdscr.attroff(curses.color_pair(1) | curses.A_BOLD)
    except curses.error:
        pass
    add_text(stdscr, 1, 2, "Native Windows terminal editor | no WSL", width - 4)
    add_text(stdscr, 2, 2, f"Page: {page.title}", width - 4)
    if height > 3:
        try:
            stdscr.hline(3, 0, curses.ACS_HLINE, width)
        except curses.error:
            pass


def draw_sections(stdscr: curses.window, page: Page, selected: int) -> None:
    height, width = stdscr.getmaxyx()
    list_width = min(34, max(20, width // 3))
    add_text(stdscr, 4, 2, "SECTIONS", list_width - 3, curses.A_BOLD)
    if not page.sections:
        add_text(stdscr, 6, 2, "No sections yet.", list_width - 3)
        add_text(stdscr, 7, 2, "Press A to add one.", list_width - 3)
    else:
        for index, section in enumerate(page.sections):
            y = 5 + index
            if y >= height - 4:
                break
            heading = section.heading or "(untitled)"
            line = f"{'>' if index == selected else ' '} {index + 1}. {section.kind:<8} {heading}"
            attr = curses.A_REVERSE if index == selected else 0
            add_text(stdscr, y, 1, line, list_width - 2, attr)
    try:
        stdscr.vline(4, list_width, curses.ACS_VLINE, max(1, height - 7))
    except curses.error:
        pass


def draw_editor(stdscr: curses.window, page: Page, selected: int) -> None:
    height, width = stdscr.getmaxyx()
    x = min(37, max(4, width // 3 + 3))
    if not page.sections:
        add_text(stdscr, 5, x, "Press A to add the first section.", width - x - 2)
        return
    section = page.sections[selected]
    add_text(stdscr, 4, x, f"EDITOR | {section.kind}", width - x - 2, curses.A_BOLD)
    values = (
        ("Heading", section.heading),
        ("Body", section.body.replace("\n", " ↵ ")),
        ("Image file", section.image_path or "(click I to choose)"),
        ("Image alt", section.image_alt or "(empty)"),
        ("Button text", section.button_label or "(empty)"),
        ("Button URL", section.button_url or "(empty)"),
    )
    for offset, (label, value) in enumerate(values):
        add_text(stdscr, 6 + offset, x, f"{label}: {value or '(empty)'}", width - x - 2)
    if height > 14:
        add_text(stdscr, 13, x, "Enter/E: edit fields", width - x - 2)
        add_text(stdscr, 14, x, "I: attach image   O: import text", width - x - 2)
        add_text(stdscr, 15, x, "D: delete   arrows: select section", width - x - 2)


def draw_footer(stdscr: curses.window, page: Page) -> None:
    height, width = stdscr.getmaxyx()
    if height < 8:
        return
    try:
        stdscr.hline(height - 4, 0, curses.ACS_HLINE, width)
    except curses.error:
        pass
    add_text(
        stdscr,
        height - 3,
        2,
        "[A] Add  [E] Edit  [I] Image  [O] Import  [G] Generate  [P] Page  [Q] Quit",
        width - 4,
        curses.A_BOLD,
    )
    add_text(stdscr, height - 2, 2, f"Output: {page.output_path}", width - 4)


def choose_image_path(stdscr: curses.window, current_path: str) -> str:
    try:
        import tkinter as tk
        from tkinter import filedialog

        root = tk.Tk()
        root.withdraw()
        root.attributes("-topmost", True)
        root.update_idletasks()
        current = Path(current_path).expanduser()
        initial_directory = str(current.parent if str(current.parent) != "." else Path.cwd())
        selected = filedialog.askopenfilename(
            parent=root,
            title="Choose image for webpage",
            initialdir=initial_directory,
            initialfile=current.name if current_path else "",
            filetypes=[
                ("Image files", ("*.png", "*.jpg", "*.jpeg", "*.gif", "*.webp", "*.svg", "*.bmp")),
                ("All files", "*.*"),
            ],
        )
        root.destroy()
        return selected
    except Exception:
        wait_for_key(stdscr, "The native image browser is unavailable; no image was changed.")
        return current_path


def field_edit(stdscr: curses.window, section: Section, field: int) -> None:
    if field == 0:
        section.heading = prompt_line(stdscr, "Heading:", section.heading)
    elif field == 1:
        section.body = prompt_line(stdscr, "Body (use O/import for multi-line text):", section.body)[:BODY_LIMIT]
    elif field == 2:
        selected_image = choose_image_path(stdscr, section.image_path)
        if selected_image:
            section.image_path = selected_image[:PATH_LIMIT]
    elif field == 3:
        section.image_alt = prompt_line(stdscr, "Image alt text:", section.image_alt)
    elif field == 4:
        section.button_label = prompt_line(stdscr, "Button label:", section.button_label)
    elif field == 5:
        section.button_url = prompt_line(stdscr, "Button URL:", section.button_url)


def edit_section(stdscr: curses.window, section: Section) -> bool:
    """Edit the original object in place, restoring its fields if Esc cancels.

    A backup is enough here because this older Section contains scalar fields.
    The modern GUI's image-embedding save path needs a deeper model rollback;
    this reference implementation is not its save/concurrency contract.
    """
    backup = replace(section)
    selected_field = 0
    labels = ("Heading", "Body", "Image file", "Image alt", "Button label", "Button URL")
    while True:
        height, width = stdscr.getmaxyx()
        stdscr.erase()
        add_text(stdscr, 1, 2, "EDIT SECTION", width - 4, curses.A_BOLD)
        add_text(stdscr, 2, 2, f"Type: {section.kind}", width - 4)
        values = (section.heading, section.body, section.image_path, section.image_alt, section.button_label, section.button_url)
        for index, label in enumerate(labels):
            attr = curses.A_REVERSE if index == selected_field else 0
            value = values[index].replace("\n", " ↵ ") or "(empty)"
            add_text(stdscr, 4 + index, 3, f"{label}: {value}", width - 6, attr)
        add_text(stdscr, height - 2, 2, "Up/Down select | Enter edit | F2 save | Esc cancel | I image", width - 4)
        stdscr.refresh()
        key = stdscr.getch()
        if key == 27:
            section.__dict__.update(backup.__dict__)
            return False
        if key == curses.KEY_UP:
            selected_field = (selected_field - 1) % len(labels)
        elif key in (curses.KEY_DOWN, ord("\t")):
            selected_field = (selected_field + 1) % len(labels)
        elif key in (curses.KEY_F2, ord("s"), ord("S")):
            return True
        elif key in (ord("i"), ord("I")):
            field_edit(stdscr, section, 2)
        elif key in (ord("\n"), curses.KEY_ENTER):
            field_edit(stdscr, section, selected_field)
        elif key == curses.KEY_MOUSE:
            try:
                _, mouse_x, mouse_y, _, button_state = curses.getmouse()
                clicked = getattr(curses, "BUTTON1_CLICKED", 0x2)
                if button_state & clicked and 4 <= mouse_y < 10:
                    selected_field = mouse_y - 4
                    field_edit(stdscr, section, selected_field)
                _ = mouse_x
            except curses.error:
                pass


def choose_type(stdscr: curses.window) -> str | None:
    selected = 0
    while True:
        height, width = stdscr.getmaxyx()
        stdscr.erase()
        add_text(stdscr, 1, 2, "ADD SECTION", width - 4, curses.A_BOLD)
        add_text(stdscr, 2, 2, "Choose a section type:", width - 4)
        for index, kind in enumerate(SECTION_TYPES):
            attr = curses.A_REVERSE if index == selected else 0
            add_text(stdscr, 4 + index, 4, f"{index + 1}. {kind}", width - 8, attr)
        add_text(stdscr, height - 2, 2, "Up/Down select | Enter choose | Esc cancel | click a type", width - 4)
        stdscr.refresh()
        key = stdscr.getch()
        if key == 27:
            return None
        if key == curses.KEY_UP:
            selected = (selected - 1) % len(SECTION_TYPES)
        elif key == curses.KEY_DOWN:
            selected = (selected + 1) % len(SECTION_TYPES)
        elif ord("1") <= key <= ord("5"):
            return SECTION_TYPES[key - ord("1")]
        elif key in (ord("\n"), curses.KEY_ENTER):
            return SECTION_TYPES[selected]
        elif key == curses.KEY_MOUSE:
            try:
                _, _, mouse_y, _, button_state = curses.getmouse()
                clicked = getattr(curses, "BUTTON1_CLICKED", 0x2)
                if button_state & clicked and 4 <= mouse_y <= 8:
                    return SECTION_TYPES[mouse_y - 4]
            except curses.error:
                pass


def add_section(stdscr: curses.window, page: Page, selected: int) -> int:
    kind = choose_type(stdscr)
    if kind is None:
        return selected
    page.sections.append(new_section(kind))
    new_index = len(page.sections) - 1
    if not edit_section(stdscr, page.sections[new_index]):
        page.sections.pop()
        return min(selected, max(0, len(page.sections) - 1))
    return new_index


def attach_image(stdscr: curses.window, page: Page, selected: int) -> None:
    if not page.sections:
        wait_for_key(stdscr, "Add a section before attaching an image.")
        return
    section = page.sections[selected]
    selected_image = choose_image_path(stdscr, section.image_path)
    if selected_image:
        section.image_path = selected_image[:PATH_LIMIT]
        section.image_alt = prompt_line(stdscr, "Alt text for the image:", section.image_alt)


def import_text(stdscr: curses.window, page: Page, selected: int) -> None:
    if not page.sections:
        wait_for_key(stdscr, "Add a section before importing text.")
        return
    path_text = prompt_line(stdscr, "Text file path to import into the selected section body:")
    if not path_text:
        return
    try:
        page.sections[selected].body = Path(path_text).read_text(encoding="utf-8", errors="replace")[:BODY_LIMIT]
    except OSError as error:
        wait_for_key(stdscr, f"Could not import text: {error}")


def image_html(section: Section) -> str:
    if not section.image_path:
        return ""
    image_path = Path(section.image_path).expanduser()
    payload = base64.b64encode(image_path.read_bytes()).decode("ascii")
    mime_type = mimetypes.guess_type(image_path.name)[0] or "application/octet-stream"
    alt = html.escape(section.image_alt or "Image", quote=True)
    return f'<div class="section-image"><img src="data:{mime_type};base64,{payload}" alt="{alt}"></div>\n'


def body_html(value: str) -> str:
    return html.escape(value or "", quote=False).replace("\n", "<br>\n")


def render_section(section: Section) -> str:
    image = image_html(section)
    if section.kind == "Hero":
        return f'<section class="hero">\n<h1>{html.escape(section.heading)}</h1>\n<p>{body_html(section.body)}</p>\n{image}</section>\n'
    if section.kind == "Text":
        return f'<section class="text-section">\n<h2>{html.escape(section.heading)}</h2>\n<p>{body_html(section.body)}</p>\n{image}</section>\n'
    if section.kind == "Image":
        heading = f'<h2>{html.escape(section.heading)}</h2>\n' if section.heading else ""
        return f'<section class="image-section">\n{heading}{image}</section>\n'
    if section.kind == "Button":
        return (
            f'<section class="button-section">\n<h2>{html.escape(section.heading)}</h2>\n'
            f'<p>{body_html(section.body)}</p>\n'
            f'<a class="button" href="{html.escape(section.button_url, quote=True)}">'
            f'{html.escape(section.button_label)}</a>\n{image}</section>\n'
        )
    if section.kind == "Divider":
        return "<hr>\n"
    raise ValueError(f"Unknown section type: {section.kind}")


def render_html(page: Page, output_path: str) -> Path:
    destination = Path(output_path).expanduser()
    sections = "".join(render_section(section) for section in page.sections)
    css = """
* { box-sizing: border-box; }
:root {
    --terminal-black: #020402;
    --terminal-panel: #071007;
    --phosphor: #a8ff60;
    --phosphor-dim: #5e9a3d;
    --amber: #ffb000;
    --line: #42742f;
}
html { min-height: 100%; background: var(--terminal-black); }
body {
    min-height: 100vh;
    margin: 0;
    color: var(--phosphor);
    background:
        radial-gradient(ellipse at center, #102010 0%, #030603 78%),
        var(--terminal-black);
    font-family: "Courier New", "Lucida Console", monospace;
    line-height: 1.55;
    text-shadow: 0 0 5px #8dff4c99;
}
body::before {
    position: fixed;
    z-index: 10;
    inset: 0;
    pointer-events: none;
    content: "";
    opacity: .16;
    background: repeating-linear-gradient(0deg, transparent 0, transparent 3px, #baff7a22 4px, transparent 5px);
    mix-blend-mode: screen;
}
body::after {
    position: fixed;
    z-index: 11;
    inset: 0;
    pointer-events: none;
    content: "";
    box-shadow: inset 0 0 10rem #000, inset 0 0 2rem #9cff5722;
}
main {
    position: relative;
    max-width: 1000px;
    margin: 0 auto;
    padding: 2rem 1.25rem 4rem;
}
.terminal-banner {
    margin-bottom: 1.5rem;
    color: var(--amber);
    overflow-x: auto;
    white-space: pre;
    text-shadow: 0 0 6px #ffb00099;
}
.terminal-banner div { min-width: 62ch; }
h1, h2 {
    margin-top: 0;
    color: var(--phosphor);
    font-family: inherit;
    font-weight: 700;
    letter-spacing: .08em;
    text-transform: uppercase;
}
h1 { font-size: clamp(2rem, 7vw, 4.8rem); line-height: 1.05; }
h1::before { color: var(--amber); content: "> "; }
h1::after { color: var(--amber); content: " _"; }
h2 { font-size: 1.2rem; }
p { max-width: 72ch; }
a { color: var(--amber); }
.hero, .text-section, .image-section, .button-section {
    position: relative;
    margin: 1.5rem 0;
    padding: 2rem;
    background: #030803dd;
    border: 1px solid var(--line);
    box-shadow: 0 0 1.25rem #68ff3b22, inset 0 0 2rem #68ff3b0d;
}
.hero {
    padding: clamp(2rem, 7vw, 5rem) 2rem;
    border: 2px solid var(--phosphor-dim);
    box-shadow: 0 0 1.8rem #68ff3b44, inset 0 0 2rem #68ff3b18;
}
.hero::before, .text-section::before, .image-section::before, .button-section::before {
    position: absolute;
    top: -1px;
    left: 1rem;
    padding: 0 .5rem;
    color: var(--amber);
    background: var(--terminal-black);
    font-size: .8rem;
    letter-spacing: .12em;
}
.hero::before { content: "[ HERO ]"; }
.text-section::before { content: "[ TEXT ]"; }
.image-section::before { content: "[ IMAGE ]"; }
.button-section::before { content: "[ ACTION ]"; }
.section-image { margin-top: 1.5rem; }
.section-image img {
    display: block;
    max-width: 100%;
    height: auto;
    border: 1px solid var(--phosphor-dim);
    filter: saturate(.8) contrast(1.12) sepia(.18);
    box-shadow: 0 0 1.5rem #68ff3b33;
}
.button {
    display: inline-block;
    padding: .65rem 1rem;
    color: var(--terminal-black);
    background: var(--phosphor);
    border: 1px solid var(--phosphor);
    border-radius: 0;
    box-shadow: 0 0 1rem #a8ff6066;
    font-weight: 700;
    text-decoration: none;
    text-shadow: none;
    text-transform: uppercase;
}
.button::before { content: "[ "; }
.button::after { content: " ]"; }
.button:hover, .button:focus {
    color: var(--terminal-black);
    background: var(--amber);
    border-color: var(--amber);
}
hr {
    margin: 2rem 0;
    border: 0;
    border-top: 1px dashed var(--line);
}
.footer {
    margin-top: 3rem;
    padding-top: 1rem;
    color: var(--phosphor-dim);
    border-top: 1px dashed var(--line);
    font-size: .9rem;
}
"""
    document = f'''<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>{html.escape(page.title)}</title>
<style>
{css}
</style>
</head>
<body>
<main>
<div class="terminal-banner" role="banner">
<div>┌──────────────────────────────────────────────────────────────┐</div>
<div>│  {html.escape(page.terminal_banner.replace(chr(10), " ").replace(chr(13), " "))[:58]:<58}│</div>
<div>└──────────────────────────────────────────────────────────────┘</div>
</div>
{sections}<div class="footer">Generated by the ~luna_luv_bug_website_maker_thingy_NOT_AI_rawR_XD~</div>
</main>
</body>
</html>
'''
    destination.write_text(document, encoding="utf-8", newline="\n")
    return destination


def index_path_from_selection(selection: str) -> str:
    selected_path = Path(selection).expanduser()
    if selected_path.suffix.lower() == ".html":
        return str(selected_path.with_name("index.html"))
    return str(selected_path / "index.html")


def choose_index_path(stdscr: curses.window, current_path: str) -> str:
    try:
        import tkinter as tk
        from tkinter import filedialog

        root = tk.Tk()
        root.withdraw()
        root.attributes("-topmost", True)
        root.update_idletasks()
        current = Path(current_path).expanduser()
        initial_directory = str(current.parent if str(current.parent) != "." else Path.cwd())
        selected = filedialog.asksaveasfilename(
            parent=root,
            title="Save webpage as index.html",
            initialdir=initial_directory,
            initialfile="index.html",
            defaultextension=".html",
            filetypes=[("HTML files", "*.html"), ("All files", "*.*")],
        )
        root.destroy()
        if not selected:
            return ""
        return index_path_from_selection(selected)
    except Exception:
        # Keep the app usable on Python installations without tkinter.
        fallback = prompt_line(
            stdscr,
            "Native Save As is unavailable. Enter a folder or file path; output will be index.html:",
            current_path,
        )
        return index_path_from_selection(fallback) if fallback else ""


def generate(stdscr: curses.window, page: Page) -> None:
    page.output_path = choose_index_path(stdscr, page.output_path)[:PATH_LIMIT]
    if not page.output_path:
        wait_for_key(stdscr, "Save cancelled. No index.html was written.")
        return
    try:
        destination = render_html(page, page.output_path)
        wait_for_key(stdscr, f"Generated index.html at {destination}")
    except (OSError, ValueError) as error:
        wait_for_key(stdscr, f"HTML export failed: {error}")


def page_settings(stdscr: curses.window, page: Page) -> None:
    page.title = prompt_line(stdscr, "HTML page title:", page.title)
    page.terminal_banner = prompt_line(
        stdscr,
        "Terminal banner text for the webpage (this appears inside the ASCII frame):",
        page.terminal_banner,
    )


def delete_section(stdscr: curses.window, page: Page, selected: int) -> int:
    if page.sections and confirm(stdscr, "Delete the selected section?"):
        page.sections.pop(selected)
        return min(selected, max(0, len(page.sections) - 1))
    return selected


def footer_action(page: Page, selected: int, key: str, stdscr: curses.window) -> int:
    if key == "a":
        return add_section(stdscr, page, selected)
    if key == "e" and page.sections:
        edit_section(stdscr, page.sections[selected])
    elif key == "i":
        attach_image(stdscr, page, selected)
    elif key == "o":
        import_text(stdscr, page, selected)
    elif key == "g":
        generate(stdscr, page)
    elif key == "p":
        page_settings(stdscr, page)
    elif key == "d":
        return delete_section(stdscr, page, selected)
    return selected


def mouse_action(stdscr: curses.window, page: Page, selected: int) -> int:
    """Translate terminal cell positions into the same actions as key presses.

    Coordinates are character cells, not pixels. These fixed footer hit ranges
    must move with draw_footer() labels; a visual spacing change alone would
    otherwise make a mouse click invoke the wrong action.
    """
    try:
        _, mouse_x, mouse_y, _, button_state = curses.getmouse()
        clicked = getattr(curses, "BUTTON1_CLICKED", 0x2)
        if not button_state & clicked:
            return selected
        height, width = stdscr.getmaxyx()
        list_width = min(34, max(20, width // 3))
        if mouse_x < list_width and 5 <= mouse_y < 5 + len(page.sections):
            return mouse_y - 5
        if mouse_y == height - 3:
            # The footer starts at x=2. These ranges mirror its labels.
            if 1 <= mouse_x < 10:
                return footer_action(page, selected, "a", stdscr)
            if 10 <= mouse_x < 20:
                return footer_action(page, selected, "e", stdscr)
            if 20 <= mouse_x < 30:
                return footer_action(page, selected, "i", stdscr)
            if 30 <= mouse_x < 42:
                return footer_action(page, selected, "o", stdscr)
            if 42 <= mouse_x < 54:
                return footer_action(page, selected, "g", stdscr)
            if 54 <= mouse_x < 66:
                return footer_action(page, selected, "p", stdscr)
    except curses.error:
        pass
    return selected


def run_ui(page: Page) -> None:
    """Keep curses terminal setup/cleanup inside wrapper(), including on errors."""
    def application(stdscr: curses.window) -> None:
        selected = 0
        curses.cbreak()
        curses.noecho()
        stdscr.keypad(True)
        stdscr.nodelay(False)
        set_cursor(False)
        if curses.has_colors():
            curses.start_color()
            curses.init_pair(1, curses.COLOR_BLACK, curses.COLOR_CYAN)
        try:
            curses.mousemask(curses.ALL_MOUSE_EVENTS)
        except curses.error:
            pass
        while True:
            height, width = stdscr.getmaxyx()
            if page.sections:
                selected = max(0, min(selected, len(page.sections) - 1))
            else:
                selected = 0
            stdscr.erase()
            draw_header(stdscr, page)
            draw_sections(stdscr, page, selected)
            draw_editor(stdscr, page, selected)
            draw_footer(stdscr, page)
            stdscr.refresh()
            key = stdscr.getch()
            if key == curses.KEY_RESIZE:
                continue
            if key == curses.KEY_MOUSE:
                selected = mouse_action(stdscr, page, selected)
            elif key == curses.KEY_UP and page.sections:
                selected = (selected - 1) % len(page.sections)
            elif key == curses.KEY_DOWN and page.sections:
                selected = (selected + 1) % len(page.sections)
            elif key in (ord("a"), ord("A")):
                selected = footer_action(page, selected, "a", stdscr)
            elif key in (ord("e"), ord("E"), ord("\n"), curses.KEY_ENTER):
                selected = footer_action(page, selected, "e", stdscr)
            elif key in (ord("i"), ord("I")):
                selected = footer_action(page, selected, "i", stdscr)
            elif key in (ord("o"), ord("O")):
                selected = footer_action(page, selected, "o", stdscr)
            elif key in (ord("g"), ord("G")):
                selected = footer_action(page, selected, "g", stdscr)
            elif key in (ord("p"), ord("P")):
                selected = footer_action(page, selected, "p", stdscr)
            elif key in (ord("d"), ord("D")):
                selected = footer_action(page, selected, "d", stdscr)
            elif key in (ord("q"), ord("Q"), 3):
                if key == 3 or confirm(stdscr, "Quit pagebuilder?"):
                    return

    curses.wrapper(application)


def self_test() -> None:
    with tempfile.TemporaryDirectory(prefix="python_pagebuilder_") as folder:
        root = Path(folder)
        fixture = root / "fixture.png"
        output = root / "index.html"
        fixture.write_bytes(bytes((0x89, 0x50, 0x4E, 0x47, 0, 1, 2, 3)))
        page = Page(title="A <safe> page", terminal_banner="MY TEST BANNER")
        page.sections.append(
            Section(
                "Hero",
                "A <safe> heading",
                "line one\nline two",
                image_path=str(fixture),
                image_alt="fixture",
            )
        )
        render_html(page, str(output))
        result = output.read_text(encoding="utf-8")
        assert "A &lt;safe&gt; heading" in result
        assert "line one<br>\nline two" in result
        assert "data:image/png;base64,iVBORwABAgM=" in result
        assert "--phosphor: #a8ff60" in result
        assert "repeating-linear-gradient" in result
        assert 'content: "[ HERO ]"' in result
        assert "MY TEST BANNER" in result
        assert "UNIX WEB TERMINAL :: ONLINE" not in result
        assert "Generated by the ~luna_luv_bug_website_maker_thingy_NOT_AI_rawR_XD~" in result
    print("self-test: PASS")


def main() -> int:
    if len(sys.argv) == 2 and sys.argv[1] == "--self-test":
        self_test()
        return 0
    run_ui(Page())
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
