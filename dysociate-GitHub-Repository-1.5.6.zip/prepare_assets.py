"""Convert the supplied dysociate artwork to a Windows icon, without redrawing it.

Copyright (c) 2026 Luna Love ~ LunaSoft
SPDX-License-Identifier: GPL-3.0-or-later. See LICENSE.

The original PNG stays intact as the release artwork. An ICO container holds
several resolutions so Windows can choose an appropriate size for each view.
"""

from __future__ import annotations

import argparse
import shutil
from pathlib import Path

from PIL import Image


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('artwork', type=Path)
    args = parser.parse_args()
    assets = Path(__file__).resolve().parent / 'assets'
    assets.mkdir(parents=True, exist_ok=True)
    png = assets / 'dysociate.png'
    if args.artwork.resolve() != png.resolve():
        shutil.copy2(args.artwork, png)
    with Image.open(png) as artwork:
        # ICO is a container of independent size variants. Saving a renamed PNG
        # as '*.ico' would not create Windows icon directory entries/resources.
        # RGBA retains any original alpha channel; the artwork is not redrawn.
        artwork.convert('RGBA').save(
            assets / 'dysociate.ico', format='ICO',
            sizes=[(size, size) for size in (16, 24, 32, 48, 64, 128, 256)],
        )
    print(assets / 'dysociate.ico')


if __name__ == '__main__':
    main()
