"""Portable button states and short, optional feedback for the desktop UI.

Copyright (c) 2026 Luna Love ~ LunaSoft
SPDX-License-Identifier: GPL-3.0-or-later. See LICENSE.

The clam renderer draws both label and background consistently on Windows.
Every state specifies BOTH colors; relying on a native theme's inherited active
foreground can turn a highlighted button into an apparently blank rectangle.
Animations run only after interaction, stop within 140 ms, and respect Windows'
client-area animation preference. There is no idle animation timer.
"""

from __future__ import annotations

import ctypes
import itertools
import os
import sys
import time
import tkinter as tk
from tkinter import ttk

BLACK = '#040704'
PANEL = '#0b130a'
FIELD = '#050b04'
BAR = '#152411'
GREEN = '#adff64'
MUTED = '#a7bba1'
LINE = '#486744'
SELECT = '#294720'
AMBER = '#ffc76c'
CYAN = '#78efd0'
TEXT = '#efffe9'
DANGER = '#ff9eac'
FONT = 'Consolas'
_styles = itertools.count()


def configure_scrollbar(style: ttk.Style) -> None:
    """Use a flat draggable thumb on a recessed track in the clam theme."""
    name = 'Terminal.Vertical.TScrollbar'
    style.layout(name, [('Vertical.Scrollbar.trough', {'sticky': 'ns', 'children': [
        ('Vertical.Scrollbar.thumb', {'sticky': 'nswe'}),
    ]})])
    style.configure(name, width=11, background=LINE, troughcolor=BLACK,
                    bordercolor=BLACK, lightcolor=LINE, darkcolor=LINE,
                    relief='flat', borderwidth=0)
    style.map(name, background=[('pressed', GREEN), ('active', CYAN)],
              lightcolor=[('pressed', GREEN), ('active', CYAN)],
              darkcolor=[('pressed', GREEN), ('active', CYAN)])


def motion_allowed() -> bool:
    """Read the system preference; never change a Windows accessibility setting."""
    if os.environ.get('DYSOCIATE_REDUCED_MOTION') == '1':
        return False
    if sys.platform == 'win32':
        enabled = ctypes.c_int()
        if ctypes.windll.user32.SystemParametersInfoW(0x1042, 0, ctypes.byref(enabled), 0):
            return bool(enabled.value)  # SPI_GETCLIENTAREAANIMATION
    return True


def blend(first: str, second: str, amount: float) -> str:
    amount = min(1.0, max(0.0, amount))
    return '#' + ''.join(f'{round(int(first[i:i+2], 16) * (1-amount) + int(second[i:i+2], 16) * amount):02x}'
                         for i in (1, 3, 5))


class NeonButton(ttk.Button):
    """A normal accessible ttk button with complete color maps and finite hover.

    Keep ttk's keyboard, focus, command, and disabled-state behavior. A unique
    style isolates an animation from every other button. Disabled wins over
    pressed, which wins over hover; none of those states inherits an OS color.
    """
    def __init__(self, parent, text, command, *, primary=False, subtle=False, danger=False):
        self._style_name = f'Dysociate{next(_styles)}.TButton'
        self._style = ttk.Style(parent)
        self._normal = GREEN if primary else (FIELD if subtle else BAR)
        self._hover = '#ceffa9' if primary else '#253b20'
        self._pressed = '#80cb4c' if primary else SELECT
        self._ink = BLACK if primary else (DANGER if danger else TEXT)
        self._current = self._normal
        self._job = None
        self._motion = motion_allowed()
        # Keep ttk's interaction model and draw just the frame and its label.
        # The focus border replaces clam's dotted inset rectangle.
        self._style.layout(self._style_name, [('Button.border', {'sticky': 'nswe',
            'children': [('Button.padding', {'sticky': 'nswe',
                'children': [('Button.label', {'sticky': 'nswe'})]})]})])
        border = GREEN if primary else LINE
        self._style.configure(self._style_name, font=(FONT, 11, 'bold'), width=0,
                              padding=(11, 7), background=self._normal,
                              foreground=self._ink, bordercolor=border,
                              lightcolor=border, darkcolor=border,
                              relief='solid', borderwidth=1, anchor='center')
        self._paint(self._normal)
        super().__init__(parent, text=text, command=command, style=self._style_name,
                         cursor='hand2', takefocus=True)
        self.bind('<Enter>', lambda event: self._animate(self._hover), add='+')
        self.bind('<Leave>', lambda event: self._animate(self._normal), add='+')
        self.bind('<Destroy>', self._stop, add='+')

    def _paint(self, hover):
        # Map foreground even for active+pressed and active+disabled. This is
        # the important fix for labels disappearing under highlight states.
        borders = [('disabled', LINE), ('focus', CYAN), ('pressed', AMBER), ('active', GREEN)]
        self._style.map(self._style_name,
            background=[('disabled', PANEL), ('pressed', self._pressed), ('active', hover)],
            foreground=[('disabled', MUTED), ('pressed', self._ink), ('active', self._ink)],
            bordercolor=borders, lightcolor=borders, darkcolor=borders)

    def _animate(self, target):
        self._stop()
        if not self._motion:
            self._current = target
            self._paint(target)
            return
        start, began = self._current, time.monotonic()

        def tick():
            self._job = None
            if not self.winfo_exists():
                return
            progress = min(1.0, (time.monotonic() - began) / .14)
            eased = 1 - (1 - progress) ** 3
            self._current = blend(start, target, eased)
            self._paint(self._current)
            if progress < 1:
                self._job = self.after(16, tick)
        tick()

    def _stop(self, event=None):
        if event is not None and event.widget is not self:
            return
        if self._job is not None:
            try:
                self.after_cancel(self._job)
            except tk.TclError:
                pass
            self._job = None
