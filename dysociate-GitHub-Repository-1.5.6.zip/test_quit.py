"""Check Esc/quit choices and real save outcomes without sending messages.

Copyright (c) 2026 Luna Love ~ LunaSoft
SPDX-License-Identifier: GPL-3.0-or-later. See LICENSE.
"""

from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

from dysociate_gui import DysociateApp
from pagebuilder_gui import Page, Section, load_page, render_html


class QuitTests(unittest.TestCase):
    def setUp(self):
        self.folder = tempfile.TemporaryDirectory(prefix='dysociate-quit-', dir=Path.cwd())
        self.path = Path(self.folder.name) / 'index.html'
        self.app = DysociateApp()
        self.app.withdraw()
        self.app.update_idletasks()
        # Unexpected failures must fail the test, not open an unattended native
        # error box. The explicit failure test overrides this guard locally.
        error_guard = patch('dysociate_gui.messagebox.showerror',
                            side_effect=lambda *args, **kwargs: self.fail(f'Unexpected error: {args}'))
        error_guard.start()
        self.addCleanup(error_guard.stop)
        self.app.post_title.set('Keep this post')
        self.app.body_text.insert('1.0', 'Text that must survive a canceled or failed save.')

    def tearDown(self):
        self.app.update_idletasks()
        self.app.destroy()
        self.folder.cleanup()

    def test_cancel_keeps_draft_and_fullscreen(self):
        before = self.app._signature()
        with patch('dysociate_gui.messagebox.askyesnocancel', return_value=None) as prompt, \
             patch.object(self.app, 'destroy') as destroy, \
             patch.object(self.app, 'save_page') as save:
            self.assertEqual(self.app.close(), 'break')
            self.assertEqual(prompt.call_args.kwargs['default'], 'cancel')
            destroy.assert_not_called()
            save.assert_not_called()
        self.assertEqual(self.app._signature(), before)
        self.assertFalse(self.app._quit_prompt_open)

    def test_save_and_quit_writes_current_draft(self):
        with patch('dysociate_gui.messagebox.askyesnocancel', return_value=True), \
             patch('dysociate_gui.filedialog.asksaveasfilename', return_value=str(self.path)), \
             patch.object(self.app, 'destroy') as destroy:
            self.app.close()
            destroy.assert_called_once()
        saved = load_page(str(self.path))
        self.assertEqual(saved.sections[0].heading, 'Keep this post')
        self.assertIn('must survive', saved.sections[0].body)

    def test_save_picker_cancel_does_not_quit(self):
        before = self.app._signature()
        with patch('dysociate_gui.messagebox.askyesnocancel', return_value=True), \
             patch('dysociate_gui.filedialog.asksaveasfilename', return_value=''), \
             patch.object(self.app, 'destroy') as destroy:
            self.app.close()
            destroy.assert_not_called()
        self.assertFalse(self.path.exists())
        self.assertEqual(self.app._signature(), before)

    def test_save_failure_does_not_quit(self):
        before = self.app._signature()
        with patch('dysociate_gui.messagebox.askyesnocancel', return_value=True), \
             patch('dysociate_gui.filedialog.asksaveasfilename', return_value=str(self.path)), \
             patch.object(self.app.doc, 'save', side_effect=OSError('Test write failure')), \
             patch('dysociate_gui.messagebox.showerror') as error, \
             patch.object(self.app, 'destroy') as destroy:
            self.app.close()
            destroy.assert_not_called()
            error.assert_called_once()
        self.assertFalse(self.path.exists())
        self.assertEqual(self.app._signature(), before)

    def test_quit_without_save_keeps_existing_file(self):
        page = Page(title='Saved thread', sections=[Section('Post', 'Original', 'Keep original.', post_id='p1')])
        render_html(page, str(self.path))
        self.app.doc.open(self.path)
        original = self.path.read_bytes()
        with patch('dysociate_gui.messagebox.askyesnocancel', return_value=False), \
             patch.object(self.app, 'save_page') as save, \
             patch.object(self.app, 'destroy') as destroy:
            self.app.close()
            destroy.assert_called_once()
            save.assert_not_called()
        self.assertEqual(self.path.read_bytes(), original)

    def test_saved_clean_page_still_asks_before_quitting(self):
        self.app._reset_editor()
        page = Page(title='Saved thread', sections=[Section('Post', 'Original', 'Already saved.', post_id='p1')])
        render_html(page, str(self.path))
        self.app.doc.open(self.path)
        self.app.page_title.set(self.app.doc.page.title)
        self.app.banner.set(self.app.doc.page.terminal_banner)
        with patch('dysociate_gui.messagebox.askyesnocancel', return_value=None) as prompt, \
             patch.object(self.app, 'destroy') as destroy:
            # Switching documents keeps its original clean-page fast path.
            self.assertTrue(self.app._leave_document())
            prompt.assert_not_called()
            self.app.close()
            prompt.assert_called_once()
            destroy.assert_not_called()

    def test_repeated_close_does_not_stack_prompts(self):
        def cancel_after_repeat(*args, **kwargs):
            self.assertEqual(self.app.close(), 'break')
            return None
        with patch('dysociate_gui.messagebox.askyesnocancel', side_effect=cancel_after_repeat) as prompt, \
             patch.object(self.app, 'destroy') as destroy:
            self.app.close()
            prompt.assert_called_once()
            destroy.assert_not_called()
        self.assertFalse(self.app._quit_prompt_open)


if __name__ == '__main__':
    unittest.main()
