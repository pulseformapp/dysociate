# dysociate - build the app, installer, complete source bundle, and data ISO
# Copyright (c) 2026 Luna Love ~ LunaSoft
# SPDX-License-Identifier: GPL-3.0-or-later. See LICENSE.
[CmdletBinding()]
param(
    [Parameter(Mandatory=$true)][string]$InnoCompiler,
    [string]$Python,
    [string]$ReleaseRoot
)

$ErrorActionPreference = 'Stop'
if (-not $Python) { $Python = Join-Path $PSScriptRoot '.venv\Scripts\python.exe' }
if (-not $ReleaseRoot) { $ReleaseRoot = Join-Path $PSScriptRoot 'release' }
$package = Join-Path $ReleaseRoot 'dysociate'
$sourceBundle = Join-Path $package 'Source'
$licenses = Join-Path $package 'Licenses'
$documentation = Join-Path $package 'Documentation'
$sourceDocs = Join-Path $sourceBundle 'docs'
New-Item -ItemType Directory -Path $package,$sourceBundle,$licenses,$documentation,$sourceDocs -Force | Out-Null

# The browser edition is the same single-file editor, ready for static hosting.
& $Python (Join-Path $PSScriptRoot 'build_browser.py') (Join-Path $package 'Browser')
if ($LASTEXITCODE -ne 0) { throw 'Browser edition build failed.' }

# Manuals are reviewed build inputs. Do not silently regenerate a DOCX during
# packaging: its rendered layout needs human inspection after content changes.
foreach ($file in @('User_Manual.docx','User_Manual.html','User_Manual.md','DEVELOPER_GUIDE.md','PRIVACY.md','manual_content.json')) {
    $from = Join-Path $PSScriptRoot ('docs\' + $file)
    if (-not (Test-Path -LiteralPath $from)) { throw ('Missing documentation: ' + $from) }
    Copy-Item -LiteralPath $from -Destination (Join-Path $documentation $file) -Force
    $to = Join-Path $sourceDocs $file
    if ([IO.Path]::GetFullPath($from) -ne [IO.Path]::GetFullPath($to)) {
        Copy-Item -LiteralPath $from -Destination $to -Force
    }
}

& (Join-Path $PSScriptRoot 'build_release.ps1') -Python $Python -OutputDir $package
if ($LASTEXITCODE -ne 0) { throw 'Application build failed.' }

# Explicit lists keep virtual environments and intermediate builds out of
# the release. Every editable product and packaging script is included.
$sourceFiles = @('dysociate_gui.py','ui_theme.py','app_resources.py','thread_document.py','browser_preview.py','email_draft.py','test_saving.py','test_help.py','test_fullscreen.py','test_quit.py','test_product_ui.py','test_imports.py','test_sharing.py','windows_share.py','pagebuilder_prompt.py','pagebuilder_gui.py','pagebuilder.py',
    'run_dysociate.ps1','run_pagebuilder.ps1','build_release.ps1',
    'build_distribution.ps1','build_browser.py','browser_runtime.js','email_size.py','test_browser.cjs','package.json','build_iso.py','build_store_bundle.py','prepare_assets.py','build_manual.py','freeze_release.py','dysociate.iss',
    'version_info.txt','requirements.txt','requirements-build.txt','requirements-docs.txt','README.md',
    'LICENSE','LICENSE_HISTORY.md','THIRD_PARTY_NOTICES.md','autorun.inf')
foreach ($file in $sourceFiles) {
    $from = Join-Path $PSScriptRoot $file
    $to = Join-Path $sourceBundle $file
    if ([IO.Path]::GetFullPath($from) -ne [IO.Path]::GetFullPath($to)) {
        Copy-Item -LiteralPath $from -Destination $to -Force
    }
}
$sourceAssets = Join-Path $sourceBundle 'assets'
New-Item -ItemType Directory -Path $sourceAssets -Force | Out-Null
foreach ($file in @('dysociate.ico','dysociate.png')) {
    $from = Join-Path $PSScriptRoot ('assets\' + $file)
    Copy-Item -LiteralPath $from -Destination (Join-Path $package $file) -Force
    if ([IO.Path]::GetFullPath($from) -ne [IO.Path]::GetFullPath((Join-Path $sourceAssets $file))) {
        Copy-Item -LiteralPath $from -Destination (Join-Path $sourceAssets $file) -Force
    }
}
foreach ($file in @('README.md','LICENSE','LICENSE_HISTORY.md','THIRD_PARTY_NOTICES.md','autorun.inf')) {
    Copy-Item -LiteralPath (Join-Path $PSScriptRoot $file) -Destination (Join-Path $package $file) -Force
}
$pythonLicense = & $Python -c "import sys; from pathlib import Path; print(Path(sys.base_prefix) / 'LICENSE.txt')"
Copy-Item -LiteralPath $pythonLicense -Destination (Join-Path $licenses 'Python-LICENSE.txt') -Force
$tkLicense = & $Python -c "import sys; from pathlib import Path; print(Path(sys.base_prefix) / 'tcl' / 'tk8.6' / 'license.terms')"
Copy-Item -LiteralPath $tkLicense -Destination (Join-Path $licenses 'Tk-LICENSE.txt') -Force
Copy-Item -LiteralPath (Join-Path $PSScriptRoot 'upstream-notices\Tcl-LICENSE.txt') -Destination (Join-Path $licenses 'Tcl-LICENSE.txt') -Force
$bootloaderLicense = & $Python -c "from importlib.metadata import distribution; d=distribution('pyinstaller'); print(next(d.locate_file(f) for f in d.files if str(f).endswith('licenses/COPYING.txt')))"
Copy-Item -LiteralPath $bootloaderLicense -Destination (Join-Path $licenses 'PyInstaller-COPYING.txt') -Force
# Keep the downloaded upstream Tcl notice as a rebuild input too.
$noticeBundle = Join-Path $sourceBundle 'upstream-notices'
New-Item -ItemType Directory -Path $noticeBundle -Force | Out-Null
Copy-Item -LiteralPath (Join-Path $PSScriptRoot 'upstream-notices\Tcl-LICENSE.txt') -Destination (Join-Path $noticeBundle 'Tcl-LICENSE.txt') -Force
$cursesLicense = & $Python -c "from importlib.metadata import distribution; d=distribution('windows-curses'); print(next(d.locate_file(f) for f in d.files if str(f).endswith('dist-info/LICENSE')))"
Copy-Item -LiteralPath $cursesLicense -Destination (Join-Path $licenses 'windows-curses-LICENSE.txt') -Force
foreach ($dependency in @('pillow')) {
    $notice = & $Python -c "from importlib.metadata import distribution; d=distribution('$dependency'); print(next(d.locate_file(f) for f in d.files if str(f).endswith('licenses/LICENSE')))"
    Copy-Item -LiteralPath $notice -Destination (Join-Path $licenses ($dependency + '-LICENSE.txt')) -Force
}

& $InnoCompiler "/DPackageDir=$package" "/DOutputDir=$package" (Join-Path $PSScriptRoot 'dysociate.iss')
if ($LASTEXITCODE -ne 0) { throw 'Installer compilation failed.' }
& $Python (Join-Path $PSScriptRoot 'build_iso.py') $package (Join-Path $ReleaseRoot 'dysociate.iso')
if ($LASTEXITCODE -ne 0) { throw 'ISO creation or readback verification failed.' }
& $Python (Join-Path $PSScriptRoot 'build_store_bundle.py') $ReleaseRoot
if ($LASTEXITCODE -ne 0) { throw 'Buyer-download preparation failed.' }
Write-Output ('Release: ' + $package)
