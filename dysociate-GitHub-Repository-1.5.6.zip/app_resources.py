"""Locate the offline manual and terms in source and packaged app layouts.

Copyright (c) 2026 Luna Love ~ LunaSoft
SPDX-License-Identifier: GPL-3.0-or-later. See LICENSE.

PyInstaller extracts embedded data under sys._MEIPASS. That temporary folder
is not the folder containing dysociate.exe and disappears after the app exits.
Prefer a persistent manual shipped beside the EXE; fall back to the embedded
copy when somebody carries only the standalone executable to another folder.
"""

from pathlib import Path
import sys


KARMIC_LAW = (
    'If the app is used for nefarious purposes, the user acknowledges, agrees to, '
    'and believes in the karmic repercussions that will be bestowed upon them.'
)
KARMIC_SIGNOFF = '~ as above so below ~'


def license_text() -> str:
    """Read the project disclaimer and GPL from the packaged license."""
    resource_root = Path(getattr(sys, '_MEIPASS', Path(__file__).resolve().parent))
    return (resource_root / 'LICENSE').read_text(encoding='utf-8')


def help_manual_path() -> Path:
    """Return an existing offline guide without depending on the working directory."""
    candidates = []
    if getattr(sys, 'frozen', False):
        candidates.append(Path(sys.executable).resolve().parent / 'Documentation' / 'User_Manual.html')
    resource_root = Path(getattr(sys, '_MEIPASS', Path(__file__).resolve().parent))
    candidates.append(resource_root / 'docs' / 'User_Manual.html')
    for path in candidates:
        if path.is_file():
            return path.resolve()
    raise FileNotFoundError('The offline manual is missing. Restore the complete application package.')
