"""Windows file clipboard only; intentionally never invokes the OS share sheet.

Copyright (c) 2026 Luna Love ~ LunaSoft
SPDX-License-Identifier: GPL-3.0-or-later. See LICENSE.
"""
import ctypes
from pathlib import Path


def copy_file_to_clipboard(path: Path, hwnd: int = 0) -> None:
    """Copy an actual file for paste into attachment-capable apps, not its path."""
    from ctypes import wintypes
    user = ctypes.WinDLL('user32', use_last_error=True)
    kernel = ctypes.WinDLL('kernel32', use_last_error=True)
    kernel.GlobalAlloc.argtypes = (wintypes.UINT, ctypes.c_size_t)
    kernel.GlobalAlloc.restype = ctypes.c_void_p
    kernel.GlobalLock.argtypes = (ctypes.c_void_p,)
    kernel.GlobalLock.restype = ctypes.c_void_p
    kernel.GlobalUnlock.argtypes = (ctypes.c_void_p,)
    kernel.GlobalFree.argtypes = (ctypes.c_void_p,)
    user.OpenClipboard.argtypes = (wintypes.HWND,)
    user.SetClipboardData.argtypes = (wintypes.UINT, ctypes.c_void_p)
    user.SetClipboardData.restype = ctypes.c_void_p
    # CF_HDROP is a binary file-list format, not Unicode text on the clipboard.
    # Its 20-byte DROPFILES header is offset, POINT(x,y), fNC, fWide. fWide=1
    # means UTF-16 paths; two NUL code units end the final path AND the list.
    import struct
    payload = struct.pack('<IiiII', 20, 0, 0, 0, 1) + (str(path.resolve()) + '\0\0').encode('utf-16-le')
    # 0x42 combines GMEM_MOVEABLE and GMEM_ZEROINIT. Clipboard APIs require a
    # movable global-memory HANDLE, not an arbitrary Python buffer address.
    memory = kernel.GlobalAlloc(0x0042, len(payload))
    if not memory:
        raise OSError('Could not allocate the file clipboard entry.')
    locked = kernel.GlobalLock(memory)
    if not locked:
        kernel.GlobalFree(memory)
        raise OSError('Could not prepare the clipboard.')
    ctypes.memmove(locked, payload, len(payload))
    kernel.GlobalUnlock(memory)
    transferred = False
    try:
        if not user.OpenClipboard(hwnd):
            raise OSError('Clipboard is busy. Try again.')
        try:
            user.EmptyClipboard()
            transferred = bool(user.SetClipboardData(15, memory))  # CF_HDROP
            # Success transfers ownership of this handle to Windows. Freeing it
            # afterward would leave the clipboard pointing at released memory.
            if not transferred:
                raise OSError('Could not copy the file.')
        finally:
            user.CloseClipboard()
    finally:
        if not transferred:
            kernel.GlobalFree(memory)
