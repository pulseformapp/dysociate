"""Build the install-free browser edition from the SAME portable renderer.

Copyright (c) 2026 Luna Love ~ LunaSoft
SPDX-License-Identifier: GPL-3.0-or-later. See LICENSE.

No second frontend, API server or CDN exists here. The empty starter and every
exported thread contain identical runtime logic. Hosting this folder gives
phones a full browser entry point when an attachment viewer disables scripts.
Open HTML reads only the selected file on the device; it does not upload it.
"""
import argparse
from pathlib import Path
from pagebuilder_gui import Page, render_document


def build(destination):
    destination.mkdir(parents=True, exist_ok=True)
    (destination / 'index.html').write_text(render_document(Page(title='Untitled thread')), encoding='utf-8')
    (destination / 'README.txt').write_text(
        'dλsociate 1.5.6 — browser edition\n'
        'created by luna love, lunasoft λ 2026\n\n'
        'Open index.html in a full browser. No Python or desktop app is needed.\n'
        'Write a post, choose an image, reply, edit, then Save HTML or Email.\n'
        'Every exported HTML contains the editor, posts, images and GPL license.\n\n'
        'PHONES: Publish index.html on an ordinary static HTTPS host (for example\n'
        'GitHub Pages) and share that URL as your browser editor. Recipients can\n'
        'open it in Safari/Chrome, tap Open HTML and choose a received thread.\n'
        'The chosen file is read locally; the editor does not upload it.\n'
        'Set Browser editor link in Thread details after hosting; the address\n'
        'travels in HTML and email invitations. Hosted exports add their URL too.\n'
        'A phone mail/file preview may display HTML without running its buttons.\n'
        'A real browser or the hosted edition is required in that case.\n\n'
        'Save HTML downloads a new copy on browsers without direct file writing.\n'
        'Check Downloads / Save to Files; a new copy does not replace the original.\n'
        'Email downloads an .eml message with the current HTML already attached.\n'
        'Oversized email copies optimize images toward an 8 MB MIME budget.\n'
        'Original pictures stay unchanged; provider limits can be lower.\n'
        'A copy that still cannot fit is blocked before creating the email.\n'
        'Open it in a compatible mail app; use Forward/Edit as new if needed.\n'
        'Nothing sends automatically. Mail/attachment support varies by device.\n\n'
        'Separate copies do not synchronize. A hosted URL shows its published\n'
        'copy; posting locally does not update that hosted file or other users.\n'
        'Send the newest saved HTML to continue the thread. Save before closing.\n'
        'The browser never needs a desktop listener for its standalone functions.\n\n'
        'GPL-3.0-or-later. The full readable runtime and license are inside HTML.\n'
        'Matching Python renderer/build source accompanies this product release.\n', encoding='utf-8')
    print('Built standalone browser edition: ' + str(destination))


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('destination', type=Path)
    build(parser.parse_args().destination)
