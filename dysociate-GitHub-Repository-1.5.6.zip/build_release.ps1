# dysociate - standalone Windows application build
# Copyright (c) 2026 Luna Love ~ LunaSoft
# SPDX-License-Identifier: GPL-3.0-or-later. See LICENSE.

[CmdletBinding()]
param(
    [string]$Python,
    [string]$OutputDir
)

$ErrorActionPreference = "Stop"
$scriptDir = $PSScriptRoot
if (-not $Python) { $Python = Join-Path $scriptDir '.venv\Scripts\python.exe' }
if (-not $OutputDir) { $OutputDir = Join-Path $scriptDir 'frozen\dist' }

# Reuse an existing environment, or create a private one for a source rebuild.
if (-not (Test-Path -LiteralPath $Python)) {
    $launcher = Get-Command py -ErrorAction SilentlyContinue
    if ($launcher) { & $launcher.Source -3 -m venv (Join-Path $scriptDir '.venv') }
    else { & python -m venv (Join-Path $scriptDir '.venv') }
    if ($LASTEXITCODE -ne 0) { throw 'Could not create the build environment.' }
}
& $Python -c 'import PyInstaller, PIL, pycdlib' 2>$null
if ($LASTEXITCODE -ne 0) {
    & $Python -m pip install -r (Join-Path $scriptDir 'requirements-build.txt')
    if ($LASTEXITCODE -ne 0) { throw 'Build dependency installation failed.' }
}

# One-file mode extracts resources to a temporary folder. Embed the whole docs
# directory so Help (and its Word-manual link) works even if only the EXE is
# copied elsewhere. Installed builds prefer the persistent Documentation copy.
# Email uses only the standard library; do not bundle native sharing bindings.
& $Python -m PyInstaller --noconfirm --clean --onefile --windowed `
    --name dysociate `
    --icon (Join-Path $scriptDir 'assets\dysociate.ico') `
    --version-file (Join-Path $scriptDir 'version_info.txt') `
    --add-data "$(Join-Path $scriptDir 'assets');assets" `
    --add-data "$(Join-Path $scriptDir 'docs');docs" `
    --add-data "$(Join-Path $scriptDir 'LICENSE');." `
    --add-data "$(Join-Path $scriptDir 'browser_runtime.js');." `
    --distpath $OutputDir `
    --workpath (Join-Path $scriptDir 'frozen\build') `
    --specpath (Join-Path $scriptDir 'frozen') `
    (Join-Path $scriptDir "dysociate_gui.py")
if ($LASTEXITCODE -ne 0) { throw 'dysociate executable build failed.' }

$test = Start-Process -FilePath (Join-Path $OutputDir 'dysociate.exe') -ArgumentList '--self-test' -WindowStyle Hidden -Wait -PassThru
if ($test.ExitCode -ne 0) { throw 'The built executable did not pass its self-test.' }
Write-Output (Join-Path $OutputDir 'dysociate.exe')
